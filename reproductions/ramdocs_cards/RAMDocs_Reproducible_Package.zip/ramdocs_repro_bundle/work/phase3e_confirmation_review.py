"""Fixed-primary confirmation review; no candidate reselection on test."""
import json,random,collections,hashlib
from real_runtime import ROOT,write_json
from phase3e.method import BIND
def clustered(rows,left,right,metric,impossible=None):
 rows=[r for r in rows if impossible is None or r['impossible']==impossible]
 a={r['question_id']:r for r in rows if r['variant']==left};b={r['question_id']:r for r in rows if r['variant']==right}
 groups=collections.defaultdict(list)
 for q in a:groups[a[q]['group']].append(float(a[q][metric])-float(b[q][metric]))
 rng=random.Random(576);keys=list(groups);draw=[]
 for _ in range(5000):
  selected=rng.choices(keys,k=len(keys));draw.append(sum(sum(groups[k]) for k in selected)/sum(len(groups[k]) for k in selected))
 draw.sort()
 return {'delta':sum(map(sum,groups.values()))/len(a),'cluster_bootstrap95':[draw[124],draw[4874]],'n':len(a),'groups':len(groups)}
def main():
 protocol=json.loads((ROOT/'planning/phase3e/check_freeze_v2.json').read_text());p=ROOT/protocol['analysis'];s=json.loads((p/'summary.json').read_text());records=json.loads((p/'per_question.json').read_text());v=s['variants'];a=v['E_blind'];b=v['quote_fix'];d=v['direct_json'];errors=[];checked=0;offsets=0
 for case in json.loads((p/'casebook.json').read_text()):
  keys={};docs={x['doc_id']:x['text'] for x in case['input']['documents']}
  for m in ['E_blind','E_seen','E_quote']:
   x=case['outputs'][m]
   for c in x.get('cards',[]):
    offsets+=1
    if docs[c['doc_id']][c['span_start']:c['span_end']]!=c['quote']:errors.append([case['input']['question_id'],m,'offset'])
   for r in x.get('requests',[]):
    raw=json.loads((ROOT/protocol['cache']/(r['key']+'.json')).read_text());prompt=raw['request']['messages'][0]['content']
    if prompt.startswith(BIND):
     visible=json.loads(prompt.split('\nInput: ',1)[1]);checked+=1;keys[m]=r['key'];expected={'question','candidates','document'} if m=='E_seen' else {'question','candidates'}
     if set(visible)!=expected or any(set(c)!= {'card_id','answer'} for c in visible['candidates']):errors.append([case['input']['question_id'],m,'binding_not_isolated'])
  if keys.get('E_blind')!=keys.get('E_quote'):errors.append([case['input']['question_id'],'binding_request_not_shared'])
 hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h for f,h in protocol['hashes'].items()}
 ci={f'{m}-{ref}/{metric}/{subset}':clustered(records,m,ref,metric,subset) for m in ['E_blind','E_seen','E_quote'] for ref in ['quote_fix','direct_json'] for metric,subset in [('em',None),('em',False),('false_answer',True)]}
 primary=ci['E_blind-quote_fix/em/None'];safety=ci['E_blind-quote_fix/false_answer/True']
 gate={'em_gain_ge10pp':primary['delta']>=.1,'em_CI_lower_positive':primary['cluster_bootstrap95'][0]>0,'answerable_gain_ge10pp':(a['answerable_em']-b['answerable_em'])/a['answerable_n']>=.1,'unanswerable_NI_upper_le5pp':safety['cluster_bootstrap95'][1]<=.05,'errors_not_increased':a['errors']<=b['errors'],'source_binding_hash_audit':not errors and s['audit']['passed'] and all(hashes.values()),'logical_tokens_le2x':a['tokens']<=2*b['tokens'],'strong_direct_boundary':(a['em']-d['em'])/a['n']>=-.05 or (d['false_answers']-a['false_answers'])/a['unanswerable_n']>=.04}
 out={'primary':'E_blind','passed':all(gate.values()),'gates':gate,'contrasts':ci,'binding_requests_audited':checked,'card_offsets_audited':offsets,'audit_errors':errors,'frozen_hashes':hashes,'scope':'single-document component; no reselection on reserved outcomes'}
 write_json(p/'decision.json',out);print(json.dumps(out,indent=2))
if __name__=='__main__':main()
