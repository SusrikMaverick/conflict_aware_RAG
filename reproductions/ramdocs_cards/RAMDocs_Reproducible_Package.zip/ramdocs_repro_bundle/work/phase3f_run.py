import json,time,hashlib,collections,traceback,argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from real_runtime import ROOT,Client,write_json,parse_json
from pipeline import Verifier,norm
from phase3f import Transfer
ap=argparse.ArgumentParser();ap.add_argument('protocol');ap.add_argument('--pilot',action='store_true');args=ap.parse_args()
p=json.loads((ROOT/args.protocol).read_text())
for f,h in p['hashes'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
c=Client();c.cache=ROOT/p['cache'];c.cache.mkdir(exist_ok=True);v=Verifier();v.cache=ROOT/p['verifier_cache'];v.cache.mkdir(exist_ok=True)
pipes={'F_C1':Transfer(c,v,False),'F_E':Transfer(c,v,True)};base=(ROOT/'materials/datasets/confrag/generateResult/TestPrompt.txt').read_text();run=ROOT/p['run'];run.mkdir(exist_ok=True)
if not (run/'manifest.json').exists():write_json(run/'manifest.json',{'protocol':p,'started_epoch':time.time()})
def one(dataset,row,m):
 pipe=pipes[m];trace=[];pipe.local.trace=trace;start=time.time();context=[]
 try:
  if dataset!='confrag':out=pipe.run(row,'full');out['method']=m
  else:
   inputs={'question_id':row['question_id'],'question':row['question'],'documents':[]}
   for d in row['documents']:
    with c.lock:tokens=c.tokenizer.encode(d['text'],add_special_tokens=False);text=c.tokenizer.decode(tokens[:4000],skip_special_tokens=False) if len(tokens)>4000 else d['text']
    inputs['documents'].append({'doc_id':'web-'+str(d['index']),'text':text});context.append({'index':d['index'],'original_tokens':len(tokens),'retained_tokens':min(len(tokens),4000),'truncated':len(tokens)>4000})
   cards,issues=pipe.extract(inputs,trace);groups=collections.defaultdict(list)
   for card in cards:
    if card['support_status']=='verified':groups[(norm(card.get('entity') or '?'),norm(card.get('sense_version') or '?'),norm(card.get('valid_time') or '?'))].append(card)
   representation={'all_webpage_indices':[d['index'] for d in row['documents']],'evidence_map':[{'scope_key':list(k),'cards':val} for k,val in groups.items()],'uncertain_cards':[x for x in cards if x['support_status']!='verified']}
   text=base.replace('[CLUSTERING NUMBER]',str(row['oracle_cluster_count']))+'\nThe webpage contents below are represented by fact cards. A doc_id web-N denotes webpage index N. A verified card is textually supported, not certified true. Uncertain cards cannot settle truth. Counts do not imply independent sources. Include all original webpage indexes, even when no useful card was extracted.\nQuestion: '+row['question']+'\nEvidence: '+json.dumps(representation,ensure_ascii=False)
   raw=c.chat(text,1536,True);trace.append({k:raw[k] for k in ('key','usage','latency_seconds','finish_reason','cache_hit')});pred=parse_json(raw['text']);assert isinstance(pred.get('answers'),list)
   for g in pred['answers']:assert isinstance(g['index'],list) and isinstance(g['answer'],str) and isinstance(g['reason'],list)
   out={'question_id':row['question_id'],'method':m,'status':'ok' if raw['finish_reason']!='length' else 'output_limit','prediction':pred,'cards':cards,'extraction_issues':issues,'requests':trace,'context_audit':context}
 except Exception as e:out={'question_id':row['question_id'],'method':m,'status':'error','error':str(e),'error_kind':'context_overflow' if str(e).startswith('context_overflow') else 'model_output','traceback':traceback.format_exc(),'requests':getattr(pipe.local,'trace',trace),'context_audit':context}
 out['wall_seconds']=time.time()-start;out['dataset']=dataset;write_json(run/dataset/m/(row['question_id']+'.json'),out);return out
jobs=[]
for dataset,info in p['datasets'].items():
 rows=list(map(json.loads,(ROOT/info['input']).read_text().splitlines()));assert len(rows)==info['n'];rows=rows[:3] if args.pilot else rows
 write_json(run/dataset/'manifest.json',{'methods':p['methods'],'protocol':args.protocol})
 jobs.extend((dataset,row,m) for row in rows for m in p['methods'] if not (run/dataset/m/(row['question_id']+'.json')).exists())
start=time.time();errors=0
with ThreadPoolExecutor(max_workers=p['workers']) as pool:
 fs=[pool.submit(one,*job) for job in jobs]
 for n,f in enumerate(as_completed(fs),1):
  x=f.result();errors+=x['status'] in ['error','output_limit'];progress={'completed_this_pass':n,'planned_this_pass':len(fs),'all_outputs':len(list(run.glob('*/*/*.json'))),'total_planned':sum(d['n'] for d in p['datasets'].values())*len(p['methods']),'errors_this_pass':errors,'elapsed_seconds':time.time()-start,'pass_finished':n==len(fs),'pilot':args.pilot};write_json(run/'progress.json',progress)
  if n%50==0 or x['status']=='error':print(json.dumps(progress|{'last':x['question_id'],'dataset':x['dataset'],'method':x['method'],'error':x.get('error')}),flush=True)
