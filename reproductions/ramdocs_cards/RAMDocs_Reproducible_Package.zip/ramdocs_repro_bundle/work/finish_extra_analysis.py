import json,subprocess,time
from pathlib import Path
from real_runtime import ROOT,write_json
while not (ROOT/'planning/automatic_finalization_finished.json').exists():time.sleep(30)
for args in [['work/analyze_confrag_comparison.py'],['work/postprocess_diagnostics.py'],['work/build_casebook.py'],['work/compile_run_ledger.py']]:subprocess.run([str(ROOT/'.venv/bin/python'),*args],cwd=ROOT,check=True)
subprocess.run([str(ROOT/'.analysis-venv/bin/python'),'work/plot_results.py'],cwd=ROOT,check=True)
subprocess.run([str(ROOT/'.venv/bin/python'),'work/make_phase_report.py'],cwd=ROOT,check=True)
write_json(ROOT/'planning/extra_analysis_finished.json',{'finished':True,'epoch':time.time(),'note':'Agent must review results, update worksheet, verify readback and release owned runtime before final delivery.'})
