"""Recover missing raw-ConfRAG error trace links by exact request-key reconstruction.
No inference, no retry, no output/score mutation. Only existing cache files are read.
"""
import argparse,hashlib,json,time
from pathlib import Path
from real_runtime import ROOT,Client,write_json
from run_confrag import prompt
class CacheOnly(Client):
 def _request(self,path,key,payload,n):
  if not path.exists():raise FileNotFoundError('Exact request absent from cache: '+key)
  r=json.loads(path.read_text());assert r['key']==key and r['request']==payload and r['preflight_tokens']==n
  return r
ap=argparse.ArgumentParser();ap.add_argument('run',type=Path);a=ap.parse_args();rows={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/confrag_official_v1/inputs.jsonl').open())};client=CacheOnly();links=[];unrecovered=[]
for method in ('oracle_K','unknown_K'):
 for path in sorted((a.run/method).glob('*.json')):
  r=json.loads(path.read_text())
  if r.get('status')!='error' or r.get('request') or r.get('requests'):continue
  original=rows[r['question_id']];row=dict(original);row['documents']=[]
  for d in original['documents']:
   tokens=client.tokenizer.encode(d['text'],add_special_tokens=False)
   row['documents'].append(dict(d,text=client.tokenizer.decode(tokens[:4000],skip_special_tokens=False) if len(tokens)>4000 else d['text']))
  try:
   raw=client.chat(prompt(row,method=='oracle_K'),1536,True)
   links.append({'method':method,'question_id':r['question_id'],'output_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'request':{k:raw[k] for k in ['key','usage','latency_seconds','finish_reason','attempts']},'recovery':'exact frozen request payload/hash and token preflight match; existing cache only'})
  except Exception as e:unrecovered.append({'method':method,'question_id':r['question_id'],'error':type(e).__name__+':'+str(e)})
write_json(a.run/'recovered_request_links.json',{'epoch':time.time(),'links':links,'unrecovered':unrecovered,'primary_outputs_unchanged':True,'inference_calls':0,'reason':'Original raw-ConfRAG adapter assigns request metadata only after successful JSON parsing; recover links for parser failures without changing their failure status or score.'})
print('Recovered',len(links),'unrecovered',len(unrecovered),'new inference0')
