import json,time,hashlib,traceback,argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from real_runtime import ROOT,Client,write_json
from pipeline import Pipeline,Verifier
from phase2.pipeline import Phase2Pipeline
from phase3.context import ContextPipeline
from phase3b.method_v2 import QuestionSupport
p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');args=p.parse_args()
protocol=json.loads((ROOT/'planning/phase3b/freeze_v2.json').read_text())
for f,h in protocol['hashes'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
rows=[json.loads(l) for l in (ROOT/protocol['input']).read_text().splitlines()];assert len(rows)==100
if args.pilot:rows=rows[:10]
run=ROOT/protocol['run'];run.mkdir(exist_ok=True)
if not (run/'manifest.json').exists():write_json(run/'manifest.json',{'protocol':protocol,'started_epoch':time.time(),'workers':6})
c=Client();c.cache=ROOT/'runs/request_cache/phase3b_v1';c.cache.mkdir(exist_ok=True)
v=Verifier();v.cache=ROOT/'runs/verifier_cache/phase3b_v1';v.cache.mkdir(exist_ok=True)
pipes={'plain':Pipeline(c),'quote_fix':Phase2Pipeline(c,v,'quote_fix'),'context_envelope':ContextPipeline(c,v),'B':QuestionSupport(c,v),'AB':QuestionSupport(c,v,True),'generic':QuestionSupport(c,v,False,False),'A_generic':QuestionSupport(c,v,True,False)}
def one(r,m):
 pipe=pipes[m];start=time.time();pipe.local.trace=[]
 try:x=pipe.run(r,m)
 except Exception as e:x={'question_id':r['question_id'],'method':m,'status':'error','error':str(e),'error_type':type(e).__name__,'traceback':traceback.format_exc(),'requests':getattr(pipe.local,'trace',[])}
 x['wall_seconds']=time.time()-start;write_json(run/m/(r['question_id']+'.json'),x);return x
jobs=[(r,m) for r in rows for m in protocol['methods'] if not (run/m/(r['question_id']+'.json')).exists()]
start=time.time();error=0
with ThreadPoolExecutor(max_workers=6) as pool:
 fs=[pool.submit(one,r,m) for r,m in jobs]
 for n,f in enumerate(as_completed(fs),1):
  x=f.result();error+=x['status'] in ['error','parse_error']
  d={'completed_this_pass':n,'planned_this_pass':len(fs),'all_outputs':len(list(run.glob('*/*.json'))),'total_planned':700,'errors_this_pass':error,'elapsed_seconds':time.time()-start,'pilot':args.pilot,'pass_finished':n==len(fs)};write_json(run/'progress.json',d)
  if n%25==0 or x['status'] in ['error','parse_error']:print(json.dumps(d|{'last':x['question_id'],'method':x['method'],'error':x.get('error')}),flush=True)
