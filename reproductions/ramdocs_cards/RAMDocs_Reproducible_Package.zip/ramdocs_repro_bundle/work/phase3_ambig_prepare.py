"""New synthetic-question/Wikipedia scope validation; do not call it human conflict gold."""
import json,re,random,hashlib,collections,urllib.parse
from pathlib import Path
from real_runtime import ROOT,write_json
def norm(s):return ' '.join(re.sub(r'[^\w\s]',' ',s.lower().replace('_',' ')).split())
def sha(s):return hashlib.sha256(norm(s).encode()).hexdigest()
oldq=set();olddoc=set();oldtitle=set();oldname=set()
for p in (ROOT/'materials/prepared').rglob('*.inputs.jsonl'):
 if 'phase3_ambig' in str(p):continue
 for l in p.open():
  r=json.loads(l);oldq.add(norm(r['question']));olddoc.update(sha(d['text']) for d in r['documents'])
for p in (ROOT/'materials/prepared').rglob('*.eval.jsonl'):
 if 'phase3_ambig' in str(p):continue
 for l in p.open():
  r=json.loads(l)
  if r.get('title_group'):oldtitle.add(norm(r['title_group']))
for l in (ROOT/'materials/datasets/ramdocs/RAMDocs_test.jsonl').open():
 r=json.loads(l);oldtitle.update(norm(t) for t in r['disambig_entity'] if isinstance(t,str));oldname.add(norm(r.get('ambiguous_entity','')))
for l in (ROOT/'materials/datasets/conflicts/conflicts.jsonl').open():
 r=json.loads(l)
 for d in r['search_results']:
  if 'wikipedia.org/wiki/' in d.get('url',''):oldtitle.add(norm(urllib.parse.unquote(d['url'].split('/wiki/',1)[1].split('#')[0])))
  if d.get('title','').endswith(' - Wikipedia'):oldtitle.add(norm(d['title'][:-12]))
for l in (ROOT/'materials/datasets/confrag/ConfRAGsuggested.jsonl').open():
 for d in json.loads(l)['websites']:
  for u in re.findall(r'https?://[^\s)\]]*wikipedia\.org/wiki/[^\s)\]]+',d.get('content','')):oldtitle.add(norm(urllib.parse.unquote(u.split('/wiki/',1)[1].split('#')[0])))
parent={}
def find(a):
 parent.setdefault(a,a)
 if parent[a]!=a:parent[a]=find(parent[a])
 return parent[a]
def union(a,b):parent[find(a)]=find(b)
allrows={s:json.loads((ROOT/f'materials/datasets/ambigdocs/{s}.json').read_text()) for s in ['dev','test']}
for rows in allrows.values():
 for r in rows:
  root='name:'+norm(r['ambiguous_entity'])
  for d in r['documents']:
   for k in ['pid:'+str(d['pid']),'title:'+norm(d['title']),'text:'+sha(d['text'])]:union(root,k)
blocked=set()
for rows in allrows.values():
 for r in rows:
  if norm(r['question']) in oldq or norm(r['ambiguous_entity']) in oldname or any(norm(d['title']) in oldtitle or sha(d['text']) in olddoc for d in r['documents']):blocked.add(find('name:'+norm(r['ambiguous_entity'])))
used=set(blocked);rng=random.Random(32576);summary={};base=ROOT/'materials/prepared/phase3_ambig_v1';base.mkdir(exist_ok=True)
for split,n in [('dev',100),('test',200)]:
 pool=allrows[split][:];rng.shuffle(pool);selected=[];seen_questions=set()
 for r in pool:
  g=find('name:'+norm(r['ambiguous_entity']))
  if g in used or norm(r['question']) in seen_questions:continue
  if not 2<=len(r['documents'])<=6 or sum(len(d['text']) for d in r['documents'])>14000:continue
  if any(not isinstance(d.get('answer'),str) or not d['answer'].strip() for d in r['documents']):continue
  selected.append((g,r));used.add(g);seen_questions.add(norm(r['question']))
  if len(selected)==n:break
 assert len(selected)==n
 inputs=[];refs=[]
 for g,r in selected:
  q='ambig-'+str(r['qid']);inputs.append({'question_id':q,'question':r['question'],'documents':[{'doc_id':f'd{i+1}','text':d['text']} for i,d in enumerate(r['documents'])]})
  refs.append({'question_id':q,'group':sha(g),'ambiguous_entity':r['ambiguous_entity'],'pairs':[{'doc_id':f'd{i+1}','title':d['title'],'answer':d['answer'],'pid':d['pid']} for i,d in enumerate(r['documents'])],'source_split':split,'annotation_origin':'author released synthetic QA; Wikipedia-derived documents','human_relation_gold':False})
 for suffix,rs in [('inputs',inputs),('eval',refs)]:
  p=base/f'{split}.{suffix}.jsonl';assert not p.exists();p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rs))
 summary[split]={'n':n,'independent_connected_source_groups':n,'documents':sum(len(x['documents']) for x in inputs)}
write_json(ROOT/'planning/phase3b/ambig_admission.json',{'splits':summary,'grouping':'connected components of ambiguous name, Wikipedia pid/title and exact normalized passage across both source splits','blocked_prior_groups':len(blocked),'prior_overlap_checked':True,'source_dev_n':len(allrows['dev']),'source_test_n':len(allrows['test']),'generation_run':False,'limits':['Synthetic questions and author-generated answers, not new human conflict gold','Different entities, not all8relations or true/fake adjudication','Semantic alias overlaps and pretraining exposure unknown']})
print(json.dumps(summary))
