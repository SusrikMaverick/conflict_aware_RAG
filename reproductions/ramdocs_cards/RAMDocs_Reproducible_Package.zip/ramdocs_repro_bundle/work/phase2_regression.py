"""Known failure replay: cached original extraction, fresh repaired decision."""
import json,shutil,time,hashlib
from real_runtime import ROOT,Client,write_json
from pipeline import Verifier
from phase2.pipeline import Phase2Pipeline
row=json.loads((ROOT/'materials/prepared/reproduction_smoke_v1.inputs.jsonl').read_text())
old=json.loads((ROOT/'runs/phase1-reproduction-smoke-v1/full'/f"{row['question_id']}.json").read_text())
run=ROOT/'runs/phase2-known-regression-v1';run.mkdir(parents=True,exist_ok=True);assert not (run/'result.json').exists()
c=Client();c.cache=run/'request_cache';c.cache.mkdir(exist_ok=True)
for r in old['requests']:
 source=ROOT/'runs/request_cache/v1'/f"{r['key']}.json";shutil.copyfile(source,c.cache/source.name)
v=Verifier();v.cache=ROOT/'runs/verifier_cache/phase2_v1'
p=Phase2Pipeline(c,v,'quote_fix');out=p.run(row);write_json(run/'result.json',out)
write_json(run/'review.json',{'type':'known failure regression, not independent test','original_outcome':old['status'],'new_outcome':out['status'],'expected_answer':'WILLOW-731','correct':out.get('accepted_answers')==['WILLOW-731'],'repairs':out['quote_repairs'],'same_original_extraction':out['requests'][0]['key']==old['requests'][0]['key'],'new_request_keys':[r['key'] for r in out['requests'] if r['key'] not in {t['key'] for t in old['requests']}],'original_files_unchanged':True})
print(json.dumps(json.loads((run/'review.json').read_text()),indent=2))
