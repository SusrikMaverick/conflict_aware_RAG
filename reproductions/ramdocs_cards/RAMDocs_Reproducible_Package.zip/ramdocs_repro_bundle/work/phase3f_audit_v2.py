import json,hashlib,collections,argparse,time
from real_runtime import ROOT,write_json,Client
from phase3e.method import BIND
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');a=ap.parse_args();p=json.loads((ROOT/'planning/phase3f/freeze_v2.json').read_text());run=ROOT/p['run'];errors=[];n=0;offsets=0;binds=0;cache={};status=collections.Counter();qcheck=collections.Counter();client=Client();outputs={}
 for dataset,info in p['datasets'].items():
  rows=list(map(json.loads,(ROOT/info['input']).read_text().splitlines()));rows=rows[:3] if a.pilot else rows
  for row in rows:
   if dataset=='confrag':
    docs={}
    for d in row['documents']:
     tokens=client.tokenizer.encode(d['text'],add_special_tokens=False);docs['web-'+str(d['index'])]=client.tokenizer.decode(tokens[:4000],skip_special_tokens=False) if len(tokens)>4000 else d['text']
   else:docs={d['doc_id']:d['text'] for d in row['documents']}
   for m in p['methods']:
    file=run/dataset/m/(row['question_id']+'.json');x=json.loads(file.read_text());n+=1;status[dataset+'/'+m+'/'+x['status']]+=1;outputs[str(file.relative_to(ROOT))]=hashlib.sha256(file.read_bytes()).hexdigest()
    for c in x.get('cards',[]):
     offsets+=1
     if docs[c['doc_id']][c['span_start']:c['span_end']]!=c['quote']:errors.append([dataset,row['question_id'],m,'offset'])
     if m=='F_E':
      binding=c.get('question_binding');qcheck[binding['verification']['status'] if binding else 'not_source_verified']+=1
      if c['support_status']=='verified' and (not binding or binding['verification']['status']!='verified'):errors.append([dataset,row['question_id'],m,'unbound_card_accepted'])
    for cite in x.get('citations',[]):
     if cite.get('doc_id') not in docs or not cite.get('quote') or cite['quote'] not in docs[cite['doc_id']]:errors.append([dataset,row['question_id'],m,'citation'])
    for r in x.get('requests',[]):
     key=r['key'];file=ROOT/p['cache']/(key+'.json')
     if not file.exists():errors.append([dataset,row['question_id'],m,'cache_missing']);continue
     if key not in cache:
      raw=json.loads(file.read_text());cache[key]=raw.get('usage',{}).get('total_tokens',0);prompt=raw['request']['messages'][0]['content']
      if prompt.startswith(BIND):
       binds+=1;visible=json.loads(prompt.split('\nInput: ',1)[1])
       if set(visible)!={'question','candidates'} or any(set(c)!={'card_id','answer'} for c in visible['candidates']):errors.append([dataset,row['question_id'],m,'binding_input'])
 hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h for f,h in p['hashes'].items()};expected=18 if a.pilot else p['outputs']
 out={'epoch':time.time(),'n':n,'expected':expected,'passed':n==expected and not errors and all(hashes.values()),'audit_errors':errors,'offsets':offsets,'unique_binding_requests':binds,'binding_verdict_counts':dict(qcheck),'status_counts':dict(status),'unique_requests':len(cache),'unique_request_tokens':sum(cache.values()),'hashes':hashes,'limitation':'Audit validates trace and structure, not semantic truth. ConfRAG final answer generation lacks deterministic card membership enforcement, as in frozen old adapter.'}
 dest=ROOT/'planning/phase3f' if a.pilot else ROOT/'analysis/phase3f';write_json(dest/('pilot_audit.json' if a.pilot else 'audit.json'),out);write_json(dest/('pilot_output_hashes.json' if a.pilot else 'output_hashes.json'),outputs);print(json.dumps(out,indent=2));assert out['passed']
if __name__=='__main__':main()
