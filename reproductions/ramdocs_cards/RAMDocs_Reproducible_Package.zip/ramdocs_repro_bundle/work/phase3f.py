"""Exploratory transfer: frozen C1/E cards, unchanged old collection policy."""
import copy
from pipeline import Pipeline
from phase3c.method import SourceCards
from phase3e.method_v2 import BoundQuestion
class Transfer(Pipeline):
 def __init__(self,client,verifier,bound=False):
  super().__init__(client,verifier);self.bound=bound
  self.source=BoundQuestion(client,verifier,'blind') if bound else SourceCards(client,verifier,True)
 def extract(self,row,trace):
  cards=[];issues=[]
  for doc in row['documents']:
   one={'question_id':row['question_id'],'question':row['question'],'documents':[doc]}
   try:out=self.source.run(one,'E_blind' if self.bound else 'C1')
   except Exception:
    trace.extend(getattr(self.source.local,'trace',[]));raise
   trace.extend(out['requests']);checks={b['card_id']:b for b in out.get('binding_checks',[])}
   for raw in out['cards']:
    card=copy.deepcopy(raw)
    if self.bound:
     card['question_binding']=checks.get(card['card_id']);card['source_support_status']=card['support_status']
     if card['support_status']=='verified' and (card['question_binding'] is None or card['question_binding']['verification']['status']!='verified'):card['support_status']='uncertain_question_binding'
    # No fabricated version/time slots or field evidence. Old grouping sees null slots.
    cards.append(card)
   issues.extend({'doc_id':doc['doc_id'],**x} for x in out.get('extraction_issues',[]))
  return cards,issues
