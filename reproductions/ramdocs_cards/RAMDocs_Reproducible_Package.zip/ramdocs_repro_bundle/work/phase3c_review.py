import json,hashlib,collections
from real_runtime import ROOT,write_json,parse_json
from phase3c.method import segments,source_span
p=ROOT/'analysis/phase3c/v1';s=json.loads((p/'summary.json').read_text());v=s['variants'];b=v['quote_fix'];direct=v['direct_json'];cases=json.loads((p/'casebook.json').read_text());errors=[];checks=0
for case in cases:
 row=case['input'];doc=row['documents'][0];parts=segments(doc['text']);keys=[]
 for m in ['C0','C1','C2','CG']:
  x=case['outputs'][m]
  if x.get('requests'):keys.append(x['requests'][0]['key'])
  for card in x.get('cards',[]):
   expected=source_span(card['source_ids'],parts,doc['text']);checks+=1
   if any(expected[k]!=card[k] for k in ['quote','span_start','span_end']):errors.append([row['question_id'],m,'source_replay'])
   raw=parse_json(json.loads((ROOT/'runs/request_cache/phase3c_v1'/(x['requests'][0]['key']+'.json')).read_text())['text'])
   orig=raw['cards'][int(card['card_id'].split(':c')[-1])]
   if any(card[k]!=orig[k] for k in ['answer','entity','scope','claim','source_ids']):errors.append([row['question_id'],m,'semantic_field_mutation'])
 if len(set(keys))>1:errors.append([row['question_id'],'shared_extract'])
gate={}
for m in ['C0','C1','C2','CG']:
 a=v[m];gate[m]={'all_em_gain_ge10pp':(a['em']-b['em'])/100>=.1,'answerable_gain_ge10pp':(a['answerable_em']-b['answerable_em'])/50>=.1,'false_answer_increase_le2pp':(a['false_answers']-b['false_answers'])/50<=.02,'errors_not_increased':a['errors']<=b['errors'],'logical_tokens_le2x':a['tokens']<=2*b['tokens'],'source_audit':not errors and s['audit']['passed'],'strong_baseline_boundary':(a['em']-direct['em'])/100>=-.05 or (direct['false_answers']-a['false_answers'])/50>=.04}
eligible=[m for m in gate if all(gate[m].values())];chosen=sorted(eligible,key=lambda m:(-v[m]['em'],v[m]['false_answers'],v[m]['tokens']))[0] if eligible else None
out={'gates':gate,'eligible':eligible,'selected_for_independent_confirmation':chosen,'source_records_replayed':checks,'source_audit_errors':errors,'selection_is_development_only':True,'condition_mechanism_claim_requires_C2_vs_C1_and_CG':True};write_json(p/'decision.json',out);print(json.dumps(out,indent=2));assert not errors
