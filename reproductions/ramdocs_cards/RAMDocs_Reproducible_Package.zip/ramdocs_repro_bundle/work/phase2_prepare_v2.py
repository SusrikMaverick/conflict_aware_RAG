"""Remove accidental class-bearing identifiers; immutable v1 retained."""
import json,random,hashlib,time
from real_runtime import ROOT,write_json
rng=random.Random(210576);base=ROOT/'materials/prepared/phase2_v2';base.mkdir(parents=True,exist_ok=True)
seen=set();all_literals=set();inputtexts=[]
for split,prefix in [('dev','Cedar'),('check','Maple')]:
 oldrows=list(map(json.loads,(ROOT/f'materials/prepared/phase2_v1/{split}.inputs.jsonl').read_text().splitlines()));oldrefs=list(map(json.loads,(ROOT/f'materials/prepared/phase2_v1/{split}.eval.jsonl').read_text().splitlines()));rows=[];refs=[]
 for row,ref in zip(oldrows,oldrefs):
  ident=prefix+'-'+str(rng.randrange(10000000,99999999));assert ident not in seen;seen.add(ident)
  codes=['K'+str(rng.randrange(10000000,99999999)) for _ in ref['candidate_literals']]
  assert not all_literals.intersection(codes);all_literals.update(codes)
  replace=dict(zip(ref['candidate_literals'],codes))|{row['question_id']:ident}
  def rewrite(s):
   for a,b in replace.items():s=s.replace(a,b)
   return s
  row=json.loads(rewrite(json.dumps(row)));ref=json.loads(rewrite(json.dumps(ref)))
  text=row['question']+' '+ ' '.join(d['text'] for d in row['documents'])
  for label in ['singleton','agreement','entity','version','time','complementary','contradiction','unclear','opinion']:
   assert label not in ident.lower()
  rows.append(row);refs.append(ref);inputtexts.append(text)
 # random order prevents position/family association in a generated batch
 pairs=list(zip(rows,refs));rng.shuffle(pairs);rows,refs=zip(*pairs)
 for suffix,data in [('inputs',rows),('eval',refs)]:
  p=base/f'{split}.{suffix}.jsonl';assert not p.exists();p.write_text(''.join(json.dumps(r)+'\n' for r in data))
# Check identifier and answer reuse against every earlier prepared JSONL, not only new split.
oldfiles=[p for p in (ROOT/'materials/prepared').rglob('*.jsonl') if base not in p.parents]
hits=[]
for p in oldfiles:
 text=p.read_text()
 for token in seen|all_literals:
  if token in text:hits.append([str(p.relative_to(ROOT)),token])
assert not hits
write_json(ROOT/'planning/phase2_v2_data_review.json',{'n_per_split':36,'new_ids':len(seen),'new_literals':len(all_literals),'prior_jsonl_files_checked':len(oldfiles),'prior_exact_token_collisions':hits,'no_class_tokens_in_identifiers':True,'no_reference_fields_in_model_input':True,'ordering':'seeded shuffle independently within split','limitations':['Same-agent constructed references, not human gold','Related templates across splits','Exact string checks do not exclude semantic similarity'],'v1_deviation':'Class names accidentally embedded in entity identifiers; v1 dev aborted and excluded; v1 check never run. No pipeline/prompt change.'})
oldrun=ROOT/'runs/phase2-v1-dev';outputs=list(oldrun.glob('*/*.json'))
write_json(oldrun/'ABORTED_INVALID_DATA.json',{'epoch':time.time(),'reason':'Class-bearing identifiers in model-facing question/documents','outputs_retained':len(outputs),'hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs},'exclude_from_efficacy_analysis':True,'check_not_started':not (ROOT/'runs/phase2-v1-check').exists()})
print('v2 created;',len(outputs),'invalid v1 outputs retained;',len(oldfiles),'prior files checked')
