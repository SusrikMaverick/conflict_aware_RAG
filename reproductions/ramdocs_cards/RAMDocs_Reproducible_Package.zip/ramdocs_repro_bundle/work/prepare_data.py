"""Freeze available evaluation/development inputs with label separation.

Does not run models, tune prompts, or manufacture human annotations.
Future training/annotation data require a new checked manifest before use.
"""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urlsplit, urlunsplit

ROOT=Path(__file__).resolve().parents[1]


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def normalized(text):
    return ' '.join(text.casefold().split())


def raw_example(qid,question,docs):
    if not isinstance(question,str) or not question.strip():raise ValueError('empty question')
    if len({d['doc_id'] for d in docs})!=len(docs):raise ValueError('duplicate document id')
    for d in docs:
        if set(d)-{'doc_id','text','metadata'}:raise ValueError('unexpected document fields')
        if not isinstance(d['text'],str):raise ValueError('invalid text')
        if d.get('metadata') and set(d['metadata'])-{'url','title','date'}:raise ValueError('annotation metadata cannot enter model input')
    return {'question_id':qid,'question':question,'documents':docs}


def adapt_ramdocs(row,index):
    from audit_ramdocs import question_id
    qid=question_id(index,row)
    docs=[{'doc_id':f'{qid}:d{j:02d}','text':d['text'],'metadata':None} for j,d in enumerate(row['documents'])]
    return raw_example(qid,row['question'],docs)


def adapt_conflicts(row,index):
    qid=f'conflicts-{index:04d}-'+digest(row['question'])[:12]
    docs=[{'doc_id':f'{qid}:d{j:02d}','text':d['short_text'],'metadata':{k:d[k] for k in ['url','title','date']}} for j,d in enumerate(row['search_results'])]
    return raw_example(qid,row['question'],docs)


def adapt_confrag(row,index):
    qid=f'confrag-{index:04d}-'+digest(row['question'])[:12]
    docs=[{'doc_id':f'{qid}:d{j:02d}','text':d['content'],'metadata':{'url':d['website']}} for j,d in enumerate(row['websites'])]
    return raw_example(qid,row['question'],docs)


def save_json(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')


def main():
    dest=ROOT/'materials/prepared/v1';dest.mkdir(parents=True,exist_ok=True)
    records=[]; output_files=[]; summaries={}
    sources=[('ramdocs','RAMDocs_test.jsonl',adapt_ramdocs),('conflicts','conflicts.jsonl',adapt_conflicts),('confrag','ConfRAGsuggested.jsonl',adapt_confrag)]
    for dataset,filename,adapter in sources:
        source=ROOT/'materials/datasets'/dataset/filename
        manifest_name='data_source_manifest.json' if dataset=='confrag' else 'source_manifest.json'
        source_manifest=json.loads((source.parent/manifest_name).read_text())
        expected=next(x['sha256'] for x in source_manifest['files'] if x['name']==filename)
        if hashlib.sha256(source.read_bytes()).hexdigest()!=expected:
            raise ValueError(f'Source hash changed for {dataset}; create a new reviewed version')
        inpath=dest/f'{dataset}.inputs.jsonl';evalpath=dest/f'{dataset}.evaluation.jsonl'
        labels=Counter();doc_count=0;empty_docs=0;max_chars=0
        with source.open() as f,inpath.open('w') as inp,evalpath.open('w') as ev:
            for i,line in enumerate(f):
                row=json.loads(line);ex=adapter(row,i);qid=ex['question_id']
                inp.write(json.dumps(ex,ensure_ascii=False)+'\n')
                if dataset=='ramdocs':
                    evaluation={'question_id':qid,'gold_answers':row['gold_answers'],'wrong_answers':row['wrong_answers'],'disambig_entity':row['disambig_entity'],'document_annotations':[{'doc_id':d['doc_id'],'type':r['type'],'answer':r['answer']} for d,r in zip(ex['documents'],row['documents'])]}
                    entities=[normalized(e) for e in row['disambig_entity']]
                elif dataset=='conflicts':
                    evaluation={'question_id':qid,'conflict_type':row['conflict_type'],'correct_answer':row['correct_answer'],'source':row['source']}
                    entities=[];labels[row['conflict_type']]+=1
                else:
                    evaluation={'question_id':qid,'official_id':row['id'],'answers':row['answers'],'contradicts':row['contradicts'],'from':row['from'],'website_annotations':[{'doc_id':d['doc_id'],**{k:v for k,v in r.items() if k not in {'website','content'}}} for d,r in zip(ex['documents'],row['websites'])]}
                    entities=[];labels[str(row['contradicts'])]+=1
                ev.write(json.dumps(evaluation,ensure_ascii=False)+'\n')
                keys=['question:'+digest(normalized(ex['question']))]
                keys+=['text:'+digest(normalized(d['text'])) for d in ex['documents'] if d['text'].strip()]
                for d in ex['documents']:
                    u=(d.get('metadata') or {}).get('url')
                    if u:
                        parts=urlsplit(u);keys.append('url:'+urlunsplit((parts.scheme.lower(),parts.netloc.lower(),parts.path,parts.query,'')))
                keys+=['entity:'+e for e in entities if e]
                records.append({'question_id':qid,'dataset':dataset,'split':'evaluation_only','keys':keys,'row_index':i})
                doc_count+=len(ex['documents']);empty_docs+=sum(not d['text'].strip() for d in ex['documents']);max_chars=max(max_chars,sum(len(d['text']) for d in ex['documents']))
        summaries[dataset]={'questions':i+1,'documents':doc_count,'empty_document_texts':empty_docs,'max_collection_characters':max_chars,'labels':dict(labels)}
        for path in [source,inpath,evalpath]:output_files.append({'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    fixtures=json.loads((ROOT/'planning/design_review/counterexamples_v1_1.json').read_text())
    with (dest/'synthetic_design_dev.inputs.jsonl').open('w') as f:
        for case in fixtures:
            qid='design-'+case['id'];ex=raw_example(qid,case['question'],[{**d,'metadata':None} for d in case['documents']]);f.write(json.dumps(ex)+'\n')
            # Same generated seed family cannot later be split across train/dev/test.
            seed={'C01':'rowan','C04':'rowan','C02':'ibis','C03':'ibis','C05':'vault','C06':'vault'}.get(case['id'],case['id'])
            keys=['question:'+digest(normalized(ex['question'])),'synthetic_seed:'+seed,'design_parent:'+case['id']]
            keys+=['text:'+digest(normalized(d['text'])) for d in ex['documents']]
            records.append({'question_id':qid,'dataset':'synthetic_design','split':'development_only','keys':keys,'annotation_status':'agent_authored_not_human_gold'})
    pilot_path=ROOT/'annotations/pilot30_agent_references.jsonl'
    if pilot_path.exists():
        with (dest/'synthetic_pilot_dev.inputs.jsonl').open('w') as f:
            for line in pilot_path.open():
                case=json.loads(line);qid=case['sample_id']
                docs=[case['doc_a'],case['doc_b'],*case['additional_documents']]
                ex=raw_example(qid,case['question'],[{**d,'metadata':None} for d in docs])
                f.write(json.dumps(ex)+'\n')
                keys=['question:'+digest(normalized(ex['question'])),'design_parent:'+case['parent_question_id'].removeprefix('design-')]
                keys+=['text:'+digest(normalized(d['text'])) for d in docs]
                records.append({'question_id':qid,'dataset':'synthetic_pilot','split':'development_only','keys':keys,'annotation_status':'agent_authored_not_human_gold'})
    for path in sorted(dest.glob('synthetic_*.inputs.jsonl')):
        output_files.append({'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    # Transitive connected components across exact question, source, known entity and seed keys.
    parent=list(range(len(records)))
    def find(x):
        while x!=parent[x]:parent[x]=parent[parent[x]];x=parent[x]
        return x
    def union(a,b):parent[find(b)]=find(a)
    owner={}
    for i,r in enumerate(records):
        for key in r['keys']:
            if key in owner:union(i,owner[key])
            else:owner[key]=i
    groups=defaultdict(list)
    for i,r in enumerate(records):groups[find(i)].append(i)
    collisions=[];cross_benchmark=[]
    for members in groups.values():
        ids=sorted(records[i]['question_id'] for i in members);gid='group-'+digest('\n'.join(ids))[:16]
        splits={records[i]['split'] for i in members};datasets={records[i]['dataset'] for i in members}
        for i in members:records[i]['group_id']=gid
        if len(splits)>1:collisions.append(ids)
        if len(datasets)>1:cross_benchmark.append({'group_id':gid,'datasets':sorted(datasets),'question_ids':ids,'evaluation_only':splits=={'evaluation_only'}})
    leakage={'exact_key_cross_split_collisions':collisions,'cross_dataset_components':cross_benchmark,'group_count':len(groups),'train_examples':0,
             'status':'pass_for_current_inputs' if not collisions else 'failed',
             'limits':['Exact normalized text/URL/known-entity checks do not prove absence of semantic paraphrases or unseen aliases.','CONFLICTS and ConfRAG lack complete entity/seed annotations; unknown mapping remains explicit.','No ECON/AmbigDocs training/dev examples admitted. Future additions must rerun this audit before use.','Synthetic design examples are development-only and cannot measure natural-data generalization.','Human relation test/dev annotations not yet made; they must inherit parent question group and split.']}
    save_json(dest/'leakage_report.json',leakage)
    manifest={'version':'available-data-v1','policy':'All official benchmark items evaluation-only; no benchmark prompt tuning; no training data admitted.',
              'conflicts_split':'Released file has no split field; all458 reserved evaluation, not claiming a provided train/test partition.',
              'confrag_variant':'official recommended improved annotations (1098), not original paper1814',
              'human_annotation_allocation':'External dev only; benchmark-derived pair annotations test only; target80dev/160test remains unfilled.',
              'summaries':summaries,'files':output_files,'records':[{k:v for k,v in r.items() if k!='keys'} for r in records]}
    save_json(dest/'split_manifest.json',manifest)
    if collisions:raise RuntimeError('Cross-split collision; inspect leakage_report.json before use')
    print(json.dumps({'summaries':summaries,'groups':len(groups),'cross_split_collisions':len(collisions),'cross_benchmark_components':sum(g['evaluation_only'] for g in cross_benchmark),'cross_development_components':sum(not g['evaluation_only'] for g in cross_benchmark)},indent=2))


if __name__=='__main__':main()
