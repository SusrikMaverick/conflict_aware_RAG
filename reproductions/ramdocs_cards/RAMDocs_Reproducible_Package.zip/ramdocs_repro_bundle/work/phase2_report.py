"""Readable stage report from audited results; all values sourced from artifacts."""
import json,html,collections
from pathlib import Path
from real_runtime import ROOT,write_json
out=ROOT/'analysis/phase2';s=json.loads((out/'summary.json').read_text());a=json.loads((out/'audit.json').read_text());d=json.loads((out/'decisions.json').read_text());rr=json.loads((out/'per_question.json').read_text());reg=json.loads((ROOT/'runs/phase2-known-regression-v1/review.json').read_text())
lines=['第二阶段：受控修订与机制诊断','运行日期：2026-11-03 America/Phoenix','', '范围：36题开发组＋36题预先固定检查组，每题原版/引用修复/引用修复＋逐对可比性，共216个输出。全部由agent构造，9个家族各4题；两个split概念和模板相关，不是自然数据，也不是人工gold。','模型：Qwen2.5-7B-Instruct BF16；MiniCheck float32阈值0.5。原提取/判定1024 token不变，新增scope1536 token；seed576，4worker，共享完全相同请求缓存以隔离后处理影响。','方法及输入在首次推理前固定。开发与检查之间无方法修改；评价脚本按预注册指标在dev运行期间写好，先于check执行。','', '结果（所有失败保留在分母）']
for split,ss in s.items():
 lines.append(split+':')
 for m,v in ss['variants'].items():lines.append(f"  {m}: 字面兼容正确{v['literal_correct']}/36；严格答案集合{v['strict_correct']}/36；relation宏F1={v['relation_macro_f1']:.4f}（32题）；错误{v['errors']}；误报矛盾{v['false_contradiction']}；非空接受{v['any_accepted']}/36；错误候选接受{v['wrong_candidate_accepted']}；quote修复{v['quote_repairs']}；scope可用{v['scope_available']}/36。")
 for pair,v in ss['paired_comparisons'].items():lines.append(f"  {pair}: 字面正确率差{v['literal_accuracy_difference']*100:.2f}pp，9家族配对bootstrap区间{[round(x*100,2) for x in v['family_bootstrap_95_interval']]}pp。仅描述小型构造集，不能外推自然数据。")
lines+=['','评分解释：字面兼容评分允许答案中的附加解释，只要求全部目标代码出现且无其他候选代码；严格集合评分不允许额外文本。无答案目标必须真正abstain，错误输出一律失败。仅代码正确不能证明实体/时间归属正确。relation用8类宏F1，单文档不设relation目标；未知身份归insufficient。','', '采用判断：',json.dumps(d,ensure_ascii=False,indent=2),'引用修复仅删除生成引文首尾ASCII空白，要求余下文本在源文档恰好出现一次（含重叠匹配检查）；不改大小写、标点、内部空白或否定词。保留raw、规范引文和原始字符offset。20项测试通过。','Scope输出仅为额外模型分析，引用存在校验不能证明scope语义正确；没有强制改关系或选真答案。只覆盖2–4张已验证卡片；其他数量显式记录not_applicable。','', '已知失败回归（不算新held-out结果）：',json.dumps(reg,ensure_ascii=False,indent=2),'', '审计：',json.dumps(a,ensure_ascii=False,indent=2),'逻辑token按每个方法完整执行所需累计，共享缓存命中也计入；实际推理token只对唯一请求计一次。服务启动、MiniCheck成本不包含在LLM token内，端到端wall time受并发和缓存影响，不能直接当公平方法延迟比较。']
for split,ss in s.items():
 for m,v in ss['variants'].items():lines.append(f"{split}/{m}: 逻辑请求{v['logical_requests']}，输入token{v['total_prompt_tokens_logical']}，输出token{v['total_completion_tokens_logical']}；各家族正确数（分母4）{v['family_correct']}")
lines+=['','复盘与下一阶段：','1. 已完成：失败定位、两个可隔离改动、反例检查、20测试、冻结、两组全部生成、审计、配对分析、采用/拒绝记录。修复成功与方法有效性分开陈述。','2. 不在本轮改动：第一阶段已发现的非contradiction分支E1策略缺口、E2语义证明、完整多关系图、自然样本标注与人工IAA。保留为下一阶段任务，避免混入本次两个对照。','3. 下一轮首先从本轮失败中分开记录抽取丢失、MiniCheck误拒、scope误判、最终关系/策略不一致。新的策略修复只在新的开发数据选择，另留未观察的检查组。','4. 自然数据先做盲标包：明确同实体/事件/时间、支持关系、答案归属、引用正确性和应否弃答；人工列保持空白，agent建议不能冒充gold。用户指定的人工评审资源与72B资源继续记录未知，不中途追问。','5. 冻结可交付范围后做方法/基线公平成本对照，再开展报告、poster、PPT和复现检查。已有RAMDocs等测试已被观察，任何后续使用必须标成探索性；不能继续声称全新独立测试。','6. 本轮仅在独立server工作；不修改已有conda，不向同学GitHub写入。']
(out/'report.txt').write_text('\n'.join(lines)+'\n')
# Show every failed or changed check example with source, expectation and complete final decision.
cases=[]
inputs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/phase2_v1/check.inputs.jsonl').read_text().splitlines())}
refs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/phase2_v1/check.eval.jsonl').read_text().splitlines())}
for q in inputs:
 r=[r for r in rr if r['split']=='check' and r['question_id']==q]
 if not all(x['literal_correct'] and (x['relation_correct'] in (1,None)) for x in r):
  outputs={m:json.loads((ROOT/f'runs/phase2-v1-check/{m}/{q}.json').read_text()) for m in ['frozen','quote_fix','scope_guided']}
  cases.append({'input':inputs[q],'reference':refs[q],'scores':r,'outputs':outputs})
write_json(out/'failure_casebook.json',cases)
body='<h1>第二阶段：受控修订与机制诊断</h1><pre>'+html.escape('\n'.join(lines[1:]))+'</pre><h2>检查组失败与变化案例</h2>'
for c in cases:body+='<details><summary>'+html.escape(c['input']['question_id'])+'</summary><pre>'+html.escape(json.dumps(c,ensure_ascii=False,indent=2))+'</pre></details>'
(out/'report.html').write_text('<!doctype html><meta charset="utf-8"><title>NLP576 Phase2</title><style>body{max-width:1100px;margin:40px auto;font:16px/1.6 sans-serif;padding:0 20px;color:#172330}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.65 monospace}details{border-top:1px solid #ccd;padding:12px}</style>'+body)
print('Report and',len(cases),'check failure cases written')
