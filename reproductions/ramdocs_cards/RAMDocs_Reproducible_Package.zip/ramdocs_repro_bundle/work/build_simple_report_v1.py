"""Generate a concise English PDF from measured RAMDocs results only."""
import hashlib
import json
import re
import textwrap
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.font_manager import FontProperties

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'deliverables'
OUT.mkdir(exist_ok=True)
PDF = OUT/'Conflict_Aware_RAG_Simple_Report.pdf'
S = json.loads((ROOT/'analysis/plain_plus_cards_v1/summary.json').read_text())
assert S['plain']['official_compatible']==.152
assert S['plus_cards']['official_compatible']==.248
matplotlib.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42})
transcript=[]
figures=[]

class Page:
    def __init__(self, number, subtitle):
        self.fig=plt.figure(figsize=(8.27,11.69),facecolor='white')
        self.ax=self.fig.add_axes([0,0,1,1]);self.ax.axis('off')
        self.y=.942
        self.text('CONFLICT-AWARE QUESTION ANSWERING',9,weight='bold',color='#3b5a73',gap=.012)
        self.text(subtitle,20,weight='bold',gap=.019)
        self.ax.text(.08,.035,'NLP 576 | Preliminary results | November 3, 2026',fontsize=8,color='#666666')
        self.ax.text(.92,.035,str(number),ha='right',fontsize=8,color='#666666')
    def text(self,content,size=10,weight='normal',color='#202b34',gap=.008,width=99):
        lines=[]
        renderer=self.fig.canvas.get_renderer()
        font=FontProperties(family='DejaVu Sans',size=size,weight=weight)
        max_width=.835*self.fig.bbox.width
        for para in content.split('\n'):
            line=''
            for word in para.split():
                candidate=(line+' '+word).strip()
                if line and renderer.get_text_width_height_descent(candidate,font,False)[0]>max_width:
                    lines.append(line);line=word
                else:line=candidate
            lines.append(line)
        step=size*1.28/(11.69*72)
        for line in lines:
            self.ax.text(.08,self.y,line,va='top',fontsize=size,fontweight=weight,color=color)
            self.y-=step
        self.y-=gap
        transcript.append(content)
        assert self.y>.070, ('page overflow',self.y,content)
    def heading(self,content):
        self.y-=.004
        self.text(content,12,weight='bold',gap=.009,width=85)
    def table(self,headers,rows,widths):
        height=.037*(len(rows)+1)
        table=self.ax.table(cellText=rows,colLabels=headers,colWidths=widths,cellLoc='left',colLoc='left',bbox=[.08,self.y-height,.84,height])
        table.auto_set_font_size(False);table.set_fontsize(9.1)
        for (r,c),cell in table.get_celld().items():
            cell.set_edgecolor('#d5dce2');cell.set_linewidth(.5)
            cell.PAD=.055
            if r==0:
                cell.set_facecolor('#eaf0f5');cell.set_text_props(weight='bold')
            elif r%2==0:cell.set_facecolor('#f7f9fb')
        self.y-=height+.018
        transcript.extend([' | '.join(headers)]+[' | '.join(r) for r in rows])
        assert self.y>.070
    def finish(self):
        self.fig.canvas.draw()
        renderer=self.fig.canvas.get_renderer()
        bounds=self.fig.bbox
        for text in self.fig.findobj(matplotlib.text.Text):
            if not text.get_text() or not text.get_visible():continue
            b=text.get_window_extent(renderer)
            assert b.x0>=0 and b.x1<=bounds.width+1 and b.y0>=0 and b.y1<=bounds.height+1, text.get_text()
        figures.append(self.fig)

p=Page(1,'Methods, baseline and main results')
p.text('Finding: adding extracted evidence to the original documents improved the measured answer score, but also increased acceptance of labeled wrong answers.',11,weight='bold',width=91,gap=.014)
p.heading('1. Task and dataset')
p.text('We study question answering over multiple documents that may contain ambiguity, conflicting claims, or misinformation. RAMDocs provides 500 questions, each with its own document collection; 243 questions include fake documents. The model receives only that question and its associated documents. No new retrieval is performed. Not every question represents a genuine contradiction.')
p.heading('2. Baseline and proposed input augmentation')
p.text('Plain RAG baseline: concatenate all documents supplied for a question and ask the model to list all correct answers with an explanation. We reuse the prompt from the teammate repository snapshot and the saved local 7B baseline outputs. These scores are our local results, not the teammate\'s 72B results.')
p.text('Original documents + extracted evidence: keep the same Plain RAG prompt and append evidence cards extracted separately from each document. A card contains a candidate answer, claim, entity/scope, source-document reference, and an exact source passage. Extraction selects source-segment IDs; code reconstructs the passage from the original text. The final model sees both the complete original documents and the cards.')
p.text('This experiment uses all 1,908 saved C1 cards without filtering by verification score. Verification scores, question-binding checks, relation decisions, majority voting, and forced abstention are not passed to the final answering step. Twenty questions have no saved cards, including four earlier failed cases; all 500 remain in the denominator.')
p.heading('3. Experimental settings and results')
p.text('Both conditions use Qwen2.5-7B-Instruct in BF16, greedy decoding, seed 576, repetition penalty 1.05, and a 128-token output limit. Only the augmented condition is newly generated; the baseline is reused from the earlier run.',gap=.013)
p.table(['RAMDocs: all 500 questions','Plain RAG','Docs + cards'],[
    ['Official-compatible score','76/500 (15.2%)','124/500 (24.8%)'],
    ['Strict answer-set match','65/500 (13.0%)','88/500 (17.6%)'],
    ['Labeled wrong answer accepted','91/500 (18.2%)','134/500 (26.8%)'],
], [.49,.255,.255])
p.text('Official-score change: +9.6 percentage points, with 64 gains and 16 losses. Strict answer-set match improves by +4.6 points. Wrong-answer acceptance increases by +8.6 points. The same question can contain both correct and incorrect candidates.',9.6,width=105,gap=.006)
p.finish()

p=Page(2,'Interpretation and limitations')
p.heading('4. What the metrics mean')
p.text('The official-compatible score checks whether the answer-list text contains all gold answers and avoids the labeled wrong-answer strings. It is not a full semantic correctness judgment: extra unlisted errors or aliases can escape detection. Strict answer-set match instead requires the normalized parsed answer set to equal the gold set. Wrong-answer acceptance is a separate string-based diagnostic, not a complete hallucination rate.')
p.text('For example, changing the wrong answer "sumo wrestling" to "sumo" gained official credit while retaining the wrong interpretation. Thus, 24.8% is not a rate of semantically perfect answers.')
p.heading('5. Relation to our earlier conflict-aware prototype')
p.text('The earlier prototype verified cards, grouped them by scope, predicted document relationships, and applied decision/citation checks that could force abstention. It performed poorly. The new experiment removes this decision machinery.')
p.table(['Earlier pipeline (context only)','RAMDocs score'],[
    ['Original structured decision pipeline','18/500 (3.6%)'],
    ['Updated source-card decision pipeline','36/500 (7.2%)'],
    ['Updated pipeline + question-binding checks','31/500 (6.2%)'],
], [.76,.24])
p.text('These historical pipelines use different prompts and output budgets, so their differences cannot be attributed to a single module. Page 1 isolates the appended-evidence input change.',9.6,width=105)
p.heading('6. Validity and cost')
p.text('RAMDocs has already been inspected during development, so the new results are exploratory, not independent confirmation. The question-level paired bootstrap interval for the official-score gain is +6.2 to +13.0 points, but it assumes independent questions and may miss shared entities/documents. Baseline and new outputs also come from different execution batches.')
p.text('Output-limit hits increase from 230 to 283 questions; parse failures increase from 16 to 20. No new request failures or context overflows occurred. Final-answering token usage rises from 811,974 to 1,169,962 (about 44%); these totals exclude the cost of the reused extraction stage. This is not an equal-total-budget comparison.')
p.heading('7. Conclusion and next experiment')
p.text('Evidence augmentation improves measured answering performance, but does not yet establish reliable conflict resolution. More correct answers come with more accepted false candidates. Next, separate genuine contradictions from entity/time ambiguity and non-conflict questions, then test which groups benefit. A future experiment should compare both inputs under the same larger output budget and separately ablate evidence filtering, followed by fresh held-out validation.')
p.text('Evidence: analysis/plain_plus_cards_v1/{summary.json, report.txt}; planning/plain_plus_cards_v1/{protocol.json, audit.json}; analysis/phase3f/ramdocs_retrospective.txt. Teammate snapshot: SusrikMaverick/conflict_aware_RAG, commit 5d70279.',8.1,color='#596674',width=124,gap=.002)
p.finish()

now=datetime.now(ZoneInfo('America/Phoenix'))
with PdfPages(PDF,metadata={'Title':'Conflict-Aware RAG: Methods, Baseline and Preliminary Results','Author':'NLP 576 Project','Subject':'RAMDocs 500-question experiments; exploratory results','CreationDate':now}) as pdf:
    for i,fig in enumerate(figures,1):
        pdf.savefig(fig)
        fig.savefig(OUT/f'Conflict_Aware_RAG_Simple_Report_page{i}.png',dpi=110)
        plt.close(fig)
(OUT/'Conflict_Aware_RAG_Simple_Report.txt').write_text('\n\n'.join(transcript)+'\n')
data=PDF.read_bytes()
assert data.startswith(b'%PDF-') and data.rstrip().endswith(b'%%EOF')
assert len(re.findall(rb'/Type\s*/Page\b',data))==2
manifest={'pdf':str(PDF.relative_to(ROOT)),'pages':2,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
    'language':'English','scope':'RAMDocs only; single-source diagnostic omitted at user request',
    'sources':['analysis/plain_plus_cards_v1/summary.json','analysis/phase3f/ramdocs_retrospective.txt'],
    'checks':{'metric_assertions':True,'pdf_header_eof':True,'page_count':2,'figure_text_bounds':True},
    'created_phoenix':now.isoformat()}
(OUT/'Conflict_Aware_RAG_Simple_Report_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
