import copy,json
from real_runtime import ROOT,write_json
cases=json.loads((ROOT/'planning/design_review/counterexamples_v1_1.json').read_text());rows=[];refs=[]
for case in cases:
 for variant in ('original','reverse','duplicate_first_x5'):
  docs=copy.deepcopy(case['documents'])
  if variant=='reverse':docs.reverse()
  if variant=='duplicate_first_x5':docs+=[dict(docs[0],doc_id=docs[0]['doc_id']+f'-copy{i}') for i in range(4)]
  qid='stress-'+case['id']+'-'+variant
  rows.append({'question_id':qid,'question':case['question'],'documents':docs});refs.append({'question_id':qid,'group_id':case['id'],'variant':variant,'expected':case['expected'],'source':'constructed synthetic diagnostic, not human review'})
base=next(x for x in cases if x['id']=='C11')
for variant in ('remove_constraint','conflicting_constraint','flipped_constraint'):
 docs=copy.deepcopy(base['documents'])
 if variant=='remove_constraint':docs=docs[:2]
 if variant=='conflicting_constraint':docs.append({'doc_id':'C11-d3','text':'Ivo lived from 1980 to 2050.'})
 if variant=='flipped_constraint':docs[2]['text']=docs[2]['text'].replace('1880 to 1950','1980 to 2050')
 qid='stress-C11-'+variant
 rows.append({'question_id':qid,'question':base['question'],'documents':docs});refs.append({'question_id':qid,'group_id':'C11','variant':variant,'expected':{'relation':'contradiction','accepted_answers':['2001'] if variant=='flipped_constraint' else [],'action':'constraint_conditional' if variant=='flipped_constraint' else 'abstain'},'source':'constructed; flipped premise demonstrates conditionality, not world truth'})
out=ROOT/'materials/prepared/stress_dev_v1';out.mkdir(parents=True,exist_ok=True)
for name,data in [('inputs',rows),('references',refs)]:
 (out/(name+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in data))
write_json(out/'manifest.json',{'n':len(rows),'split':'synthetic_development','grouping':'all variants retain corresponding design-Cxx group from v1 split manifest; no benchmark content added','variants':['original','reverse','duplicate_first_x5','remove_constraint','conflicting_constraint','flipped_constraint']})
print(len(rows))
