import unittest
from metrics import score,official
class Scores(unittest.TestCase):
    def test_explanation_excluded(self):self.assertTrue(official('All Correct Answers: [1963]. Explanation: not 1998.',['1963'],['1998']))
    def test_wrong_overlap_gold(self):self.assertTrue(official('All Correct Answers: [American football]',['American football'],['football','American football']))
    def test_missing_one_gold(self):self.assertFalse(official('All Correct Answers: [1]',['1','2'],[]))
    def test_substring_differs_strict(self):
        r=score({'status':'answered','accepted_answers':['in 1963']},['1963'],[]);self.assertEqual(r['official_compatible'],1);self.assertEqual(r['strict_set_exact'],0)
    def test_uncertain_candidates_not_answers(self):
        r=score({'status':'abstain','accepted_answers':[],'competing_candidates':['1963']},['1963'],[]);self.assertEqual(r['official_compatible'],0)
    def test_numeric_atoms(self):
        from real_runtime import plain_parse
        self.assertEqual(plain_parse('All Correct Answers: [1901, 2001]. Explanation: ...'),['1901','2001'])
    def test_wrong_answer_with_modifier(self):
        r=score({'status':'answered','accepted_answers':['around 2001']},['1901'],['2001']);self.assertEqual(r['wrong_only_accepted'],1);self.assertEqual(r['wrong_only_exact_accepted'],0)
if __name__=='__main__':unittest.main()
