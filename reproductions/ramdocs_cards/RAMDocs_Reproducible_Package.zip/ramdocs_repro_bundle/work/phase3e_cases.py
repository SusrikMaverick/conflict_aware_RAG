import json,collections
from real_runtime import ROOT,write_json
p=ROOT/'analysis/phase3e/check_v2';records=json.loads((p/'per_question.json').read_text());lookup={(r['question_id'],r['variant']):r for r in records};groups=collections.defaultdict(list)
for case in json.loads((p/'casebook.json').read_text()):
 q=case['input']['question_id'];a=lookup[q,'E_blind'];b=lookup[q,'quote_fix'];d=lookup[q,'direct_json'];kind='gain_vs_old' if a['em']>b['em'] else 'loss_vs_old' if a['em']<b['em'] else 'tie_vs_old'
 record={'question_id':q,'question':case['input']['question'],'document':case['input']['documents'][0]['text'],'gold':[x['text'] for x in case['reference']['answers']],'impossible':a['impossible'],'group':a['group'],'E':case['outputs']['E_blind'],'old':case['outputs']['quote_fix'],'direct':case['outputs']['direct_json'],'em':{'E':a['em'],'old':b['em'],'direct':d['em']}}
 groups[kind].append(record)
 if a['false_answer']:groups['E_false_answer'].append(record)
 if a['em']<d['em']:groups['loss_vs_direct'].append(record)
write_json(p/'changed_cases.json',dict(groups));print({k:len(v) for k,v in groups.items()})
for k in ['loss_vs_old','E_false_answer']:
 for c in groups[k]:print(json.dumps({'kind':k,'id':c['question_id'],'q':c['question'],'gold':c['gold'],'E':c['E'].get('accepted_answers'),'old':c['old'].get('accepted_answers'),'binding':c['E'].get('binding_checks')},ensure_ascii=False))
