"""Predeclared development metrics; reserved check outcomes are never read/generated."""
import json,re,string,collections,random,hashlib,csv
from real_runtime import ROOT,write_json,parse_json
from pipeline import EXTRACT
from phase3.context import envelope

def norm(s):
 s=''.join(c for c in s.lower() if c not in string.punctuation)
 return ' '.join(re.sub(r'\b(a|an|the)\b',' ',s).split())
def f1(a,b):
 x=norm(a).split();y=norm(b).split()
 if not x or not y:return float(x==y)
 n=sum((collections.Counter(x)&collections.Counter(y)).values());return 2*n/(len(x)+len(y))
base=ROOT/'materials/prepared/phase3_grounding_v1';outdir=ROOT/'analysis/phase3';outdir.mkdir(exist_ok=True)
refs={r['question_id']:r for r in map(json.loads,(base/'dev.eval.jsonl').read_text().splitlines())}
inputs={r['question_id']:r for r in map(json.loads,(base/'dev.inputs.jsonl').read_text().splitlines())}
methods=['plain','quote_fix','context_envelope'];records=[];audit={k:[] for k in ['missing_cache','citation_errors','context_errors','shared_extract_errors']};cache={};examples=[]
for q,row in inputs.items():
 ref=refs[q];docs={d['doc_id']:d['text'] for d in row['documents']};gold=[a['text'] for a in ref['answers']] or [''];exkeys={};outputs={}
 for m in methods:
  x=json.loads((ROOT/f'runs/phase3-grounding-dev-v1/{m}/{q}.json').read_text());outputs[m]=x
  answers=x.get('accepted_answers',[]);pred=' '.join(answers);ok=x['status'] not in ['error','parse_error'];em=int(ok and max(norm(pred)==norm(g) for g in gold));score=max(f1(pred,g) for g in gold) if ok else 0
  if ref['is_impossible'] and x['status']!='abstain':em=0;score=0
  pt=ct=0;ek=[]
  for r in x.get('requests',[]):
   k=r['key'];p=ROOT/f'runs/request_cache/phase3_dev_v1/{k}.json'
   if not p.exists():audit['missing_cache'].append(k);continue
   if k not in cache:cache[k]=json.loads(p.read_text())
   raw=cache[k]
   if raw['request']['messages'][0]['content'].startswith(EXTRACT):ek.append(k)
   pt+=r.get('usage',{}).get('prompt_tokens',0);ct+=r.get('usage',{}).get('completion_tokens',0)
  exkeys[m]=ek
  for c in x.get('citations',[]):
   if c.get('doc_id') not in docs or not c.get('quote') or c['quote'] not in docs[c['doc_id']]:audit['citation_errors'].append([q,m,c])
  for c in x.get('context_records',[]):
   if c['status'] in ['expanded','unchanged']:
    doc=docs[c['doc_id']]
    if doc[c['span_start']:c['span_end']]!=c['quote'] or doc[c['original_span_start']:c['original_span_end']]!=c['raw_quote']:audit['context_errors'].append([q,c])
  cards=x.get('cards',[]);verified=[c for c in cards if c['support_status']=='verified'];alias={norm(g) for g in gold}
  rec={'question_id':q,'title_group':ref['title_group'],'variant':m,'is_impossible':ref['is_impossible'],'status':x['status'],'error':x.get('error'),'exact_match':em,'token_f1':score,'accepted':int(bool(answers)),'wrong_accept':int(bool(answers) and not em),'unanswerable_false_answer':int(ref['is_impossible'] and bool(answers)),'cards':len(cards),'verified_cards':len(verified),'correct_answer_verified':int(not ref['is_impossible'] and any(norm(c['answer']) in alias for c in verified)),'expanded_cards':sum(c['status']=='expanded' for c in x.get('context_records',[])),'skip_reasons':dict(collections.Counter(c['reason'] for c in x.get('context_records',[]) if c['status']=='skipped')),'prompt_tokens':pt,'completion_tokens':ct,'logical_requests':len(x.get('requests',[])),'enforcement_reasons':x.get('enforcement_reasons',[]),'accepted_answers':answers}
  records.append(rec)
 if exkeys['quote_fix']!=exkeys['context_envelope']:audit['shared_extract_errors'].append(q)
 examples.append({'input':row,'reference':ref,'outputs':outputs})
summary={}
for m in methods:
 rr=[r for r in records if r['variant']==m];aa=[r for r in rr if not r['is_impossible']];uu=[r for r in rr if r['is_impossible']]
 summary[m]={'n':len(rr),'exact_match_n':sum(r['exact_match'] for r in rr),'token_f1':sum(r['token_f1'] for r in rr)/len(rr),'answerable_em_n':sum(r['exact_match'] for r in aa),'answerable_n':len(aa),'answerable_token_f1':sum(r['token_f1'] for r in aa)/len(aa),'unanswerable_false_answers':sum(r['unanswerable_false_answer'] for r in uu),'unanswerable_n':len(uu),'accepted_n':sum(r['accepted'] for r in rr),'wrong_accept_n':sum(r['wrong_accept'] for r in rr),'errors':sum(r['status'] in ['error','parse_error'] for r in rr),'verified_cards':sum(r['verified_cards'] for r in rr),'answerable_with_correct_verified_card':sum(r['correct_answer_verified'] for r in aa),'expanded_cards':sum(r['expanded_cards'] for r in rr),'expansion_questions':sum(r['expanded_cards']>0 for r in rr),'skip_reasons':dict(sum((collections.Counter(r['skip_reasons']) for r in rr),collections.Counter())),'logical_prompt_tokens':sum(r['prompt_tokens'] for r in rr),'logical_completion_tokens':sum(r['completion_tokens'] for r in rr),'logical_requests':sum(r['logical_requests'] for r in rr)}
 a=summary[m];a['exact_among_accepted']= (a['accepted_n']-a['wrong_accept_n'])/a['accepted_n'] if a['accepted_n'] else None
assert len(records)==300
rng=random.Random(576);contrasts={}
for left,right in [('context_envelope','quote_fix'),('context_envelope','plain')]:
 l={r['question_id']:r for r in records if r['variant']==left};r={r['question_id']:r for r in records if r['variant']==right}
 for metric in ['exact_match','token_f1']:
  diffs=[l[q][metric]-r[q][metric] for q in l];bs=sorted(sum(rng.choices(diffs,k=len(diffs)))/len(diffs) for _ in range(5000))
  contrasts[left+'-minus-'+right+'/'+metric]={'difference':sum(diffs)/len(diffs),'bootstrap95':[bs[124],bs[4874]],'group':'title; each development question has unique title','interpretation':'development descriptive; no confirmation claim'}
for f,h in json.loads((ROOT/'planning/phase3/dev_freeze_v1.json').read_text())['hashes'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
passed=not any(audit.values());audit.update(passed=passed,n_outputs=len(records),unique_requests=len(cache),unique_usage={k:sum(x['usage'].get(k,0) for x in cache.values()) for k in ['prompt_tokens','completion_tokens','total_tokens']},frozen_hashes_match=True,reserved_check_not_run=not (ROOT/'runs/phase3-grounding-check-v1').exists())
a=summary['context_envelope'];b=summary['quote_fix'];ratio=(a['logical_prompt_tokens']+a['logical_completion_tokens'])/(b['logical_prompt_tokens']+b['logical_completion_tokens'])
gates={'answerable_em_gain_ge5pp':(a['answerable_em_n']-b['answerable_em_n'])/50>=.05,'false_answer_increase_le2pp':(a['unanswerable_false_answers']-b['unanswerable_false_answers'])/50<=.02,'no_new_integrity_failure':passed,'error_count_not_increased':a['errors']<=b['errors'],'logical_token_ratio_le1_5':ratio<=1.5}
write_json(outdir/'dev_summary.json',{'variants':summary,'contrasts':contrasts,'continuation_gate':gates,'passes_development_continuation_gate':all(gates.values()),'logical_token_ratio':ratio,'no_final_adoption_claim':True});write_json(outdir/'audit.json',audit);write_json(outdir/'per_question.json',records)
with (outdir/'per_question.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
write_json(outdir/'casebook.json',examples)
print(json.dumps({'summary':summary,'gates':gates,'ratio':ratio,'audit':audit},indent=2))
