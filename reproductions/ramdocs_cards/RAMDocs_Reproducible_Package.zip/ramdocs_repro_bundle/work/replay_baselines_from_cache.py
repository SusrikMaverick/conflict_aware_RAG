"""Verify archived baseline parsing from immutable model responses; no generation."""
import hashlib,importlib.util,json,time
from pathlib import Path
from real_runtime import ROOT,Client,write_json
manifest=json.loads((ROOT/'runs/ramdocs-baselines-v1/manifest.json').read_text());source=ROOT/'work/frozen/pilot_v1_2/pipeline.py';assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source']['pipeline.py']
for name in ['real_runtime.py','decision_schema.py','madam_adapter.py']:
 assert hashlib.sha256((ROOT/'work'/name).read_bytes()).hexdigest()==manifest['source'][name]
spec=importlib.util.spec_from_file_location('archived_baseline_pipeline',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class CacheOnly(Client):
 def _request(self,path,key,payload,n):
  if not path.exists():raise FileNotFoundError('Cache-only replay forbids inference: '+key)
  r=json.loads(path.read_text());assert r['request']==payload and r['preflight_tokens']==n
  return r|{'cache_hit':True}
pipe=module.Pipeline(CacheOnly());mismatches=[];count=0;fields=['question_id','method','status','accepted_answers','raw_output','explicit_memory'];start=time.time()
for row in map(json.loads,(ROOT/manifest['input']).open()):
 for method in manifest['methods']:
  expected=json.loads((ROOT/'runs/ramdocs-baselines-v1'/method/(row['question_id']+'.json')).read_text());actual=pipe.run(row,method)
  if {k:expected.get(k) for k in fields}!={k:actual.get(k) for k in fields}:mismatches.append([row['question_id'],method])
  count+=1
write_json(ROOT/'planning/cache_replay_baselines.json',{'outputs_checked':count,'mismatches':mismatches,'fresh_inference_calls':0,'elapsed_seconds':time.time()-start,'archived_source_sha256':manifest['source']['pipeline.py'],'fields_checked':fields,'note':'Replays archived baseline method against existing exact request cache. Not independent model regeneration; original run manifest and outputs unchanged.'})
assert count==1000 and not mismatches
print('1000 archived baseline outputs reproduced from cache; fresh inference0',flush=True)
