"""Development-only v1 run: held-out data cannot be selected through this CLI."""
import json,time,hashlib,traceback
from concurrent.futures import ThreadPoolExecutor,as_completed
from real_runtime import ROOT,Client,write_json
from pipeline import Pipeline,Verifier
from phase2.pipeline import Phase2Pipeline
from phase3.context import ContextPipeline
protocol=json.loads((ROOT/'planning/phase3/dev_freeze_v1.json').read_text())
for f,h in protocol['hashes'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
rows=list(map(json.loads,(ROOT/'materials/prepared/phase3_grounding_v1/dev.inputs.jsonl').read_text().splitlines()))
assert len(rows)==100
run=ROOT/'runs/phase3-grounding-dev-v1';run.mkdir(parents=True,exist_ok=True);assert not list(run.glob('*/*.json'))
write_json(run/'manifest.json',{'protocol':protocol,'started_epoch':time.time(),'split':'development_only','workers':6})
c=Client();c.cache=ROOT/'runs/request_cache/phase3_dev_v1';c.cache.mkdir(parents=True,exist_ok=True)
v=Verifier();v.cache=ROOT/'runs/verifier_cache/phase3_dev_v1';v.cache.mkdir(parents=True,exist_ok=True)
pipes={'plain':Pipeline(c),'quote_fix':Phase2Pipeline(c,v,'quote_fix'),'context_envelope':ContextPipeline(c,v)}
def one(row,m):
 p=pipes[m];start=time.time()
 try:out=p.run(row,m)
 except Exception as e:out={'question_id':row['question_id'],'method':m,'status':'error','error':str(e),'error_type':type(e).__name__,'traceback':traceback.format_exc(),'requests':getattr(p.local,'trace',[]),'context_records':getattr(p.local,'context_records',[]),'quote_repairs':getattr(p.local,'repairs',[])}
 out['wall_seconds']=time.time()-start;write_json(run/m/(row['question_id']+'.json'),out);return out
start=time.time();errors=0
with ThreadPoolExecutor(max_workers=6) as pool:
 fs=[pool.submit(one,r,m) for r in rows for m in pipes]
 for n,f in enumerate(as_completed(fs),1):
  x=f.result();errors+=x['status'] in ['error','parse_error'];d={'completed':n,'total':len(fs),'errors_or_parse_errors':errors,'elapsed_seconds':time.time()-start,'finished':n==len(fs)};write_json(run/'progress.json',d)
  if n%15==0 or x['status'] in ['error','parse_error']:print(json.dumps(d|{'last':x['question_id'],'method':x['method'],'error':x.get('error')}),flush=True)
