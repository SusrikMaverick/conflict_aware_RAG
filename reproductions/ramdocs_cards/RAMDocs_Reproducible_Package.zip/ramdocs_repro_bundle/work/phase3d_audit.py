import json,hashlib,collections
from real_runtime import ROOT,write_json
from phase3e.method import BIND
p=json.loads((ROOT/'planning/phase3d/bound_dev_freeze_v1.json').read_text());cases=json.loads((ROOT/p['analysis']/'casebook.json').read_text());errors=[];offsets=0;binding_requests=set();pairs=0
for case in cases:
 docs={d['doc_id']:d['text'] for d in case['input']['documents']};q=case['input']['question_id'];sourcekeys={}
 for m,out in case['outputs'].items():
  for c in out.get('cards',[]):
   offsets+=1
   if docs[c['doc_id']][c['span_start']:c['span_end']]!=c['quote']:errors.append([q,m,'offset',c['card_id']])
  if m in ['perdoc_C0','perdoc_C1','graph_C1','D_E'] and out['status']!='error':
   sourcekeys[m]=[d['requests'][0]['key'] for d in out['document_results']]
  for edge in out.get('pair_edges',[]):
   pairs+=1
   if edge['left'] not in {c['card_id'] for c in out['cards']} or edge['right'] not in {c['card_id'] for c in out['cards']}:errors.append([q,m,'edge_card_id'])
  if m=='D_E':
   for doc in out.get('document_results',[]):
    allowed={b['card_id'] for b in doc['binding_checks'] if b['verification']['status']=='verified'}
    for c in doc['cards']:
     if c['support_status']=='verified' and c['card_id'] not in allowed:errors.append([q,m,'binding_selection'])
   for r in out.get('requests',[]):
    raw=json.loads((ROOT/p['cache']/(r['key']+'.json')).read_text());prompt=raw['request']['messages'][0]['content']
    if prompt.startswith(BIND):
     binding_requests.add(r['key']);visible=json.loads(prompt.split('\nInput: ',1)[1])
     if set(visible)!={'question','candidates'} or any(set(c)!={'card_id','answer'} for c in visible['candidates']):errors.append([q,m,'source_blind'])
 if len({tuple(v) for v in sourcekeys.values()})>1:errors.append([q,'shared_extraction_keys'])
checks={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h for f,h in p['hashes'].items()}
result={'passed':not errors and all(checks.values()),'offsets':offsets,'source_blind_binding_requests':len(binding_requests),'edges':pairs,'errors':errors,'hashes':checks,'scope':'structural/source integrity only, no human semantic labels'}
write_json(ROOT/p['analysis']/'replay_audit.json',result);print({k:v for k,v in result.items() if k!='hashes'});assert result['passed']
