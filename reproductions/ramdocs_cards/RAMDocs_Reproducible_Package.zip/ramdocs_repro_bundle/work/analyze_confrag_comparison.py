import collections,csv,json,random
from pathlib import Path
from real_runtime import ROOT,write_json
runs=['confrag-bounded-v1','confrag-cards-v3'];methods={}
for run in runs:
 for r in map(json.loads,(ROOT/'runs'/run/'scored.jsonl').open()):methods.setdefault(r['method'],{})[r['question_id']]=r
orig=list(map(json.loads,(ROOT/'materials/prepared/v1/confrag.inputs.jsonl').open()));groupof={}
def visit(v):
 if isinstance(v,dict):
  if 'question_id' in v and 'group_id' in v:groupof[v['question_id']]=v['group_id']
  for x in v.values():visit(x)
 elif isinstance(v,list):
  for x in v:visit(x)
visit(json.loads((ROOT/'materials/prepared/v1/split_manifest.json').read_text()))
paired={}
for left,right in [('aligned_K','flat_K'),('aligned_K','oracle_K'),('oracle_K','unknown_K')]:
 ids=sorted(set(methods[left])&set(methods[right]));groups=collections.defaultdict(list)
 for q in ids:
  original_qid=orig[int(q.rsplit('-',1)[1])]['question_id'];groups[groupof.get(original_qid,original_qid)].append(q)
 keys=sorted(groups);rng=random.Random(576);draws={k:[] for k in ('NMI','answerScore','reasonScore')}
 for _ in range(2000):
  selected=[q for g in rng.choices(keys,k=len(keys)) for q in groups[g]]
  for metric in draws:draws[metric].append(sum(methods[left][q][metric]-methods[right][q][metric] for q in selected)/len(selected))
 paired[left+'-minus-'+right]={'n_questions':len(ids),'n_groups':len(groups),'metrics':{m:{'mean_delta':sum(methods[left][q][m]-methods[right][q][m] for q in ids)/len(ids),'95pct_paired_group_bootstrap':[sorted(d)[50],sorted(d)[1950]]} for m,d in draws.items()},'replicates':2000,'seed':576}
summary={m:{'n':len(rs),'mean':{metric:sum(r[metric] for r in rs.values())/len(rs) for metric in ('NMI','answerScore','reasonScore')},'status_counts':dict(collections.Counter(r['status'] for r in rs.values()))} for m,rs in methods.items()}
out=ROOT/'analysis/confrag_comparison';out.mkdir(parents=True,exist_ok=True);write_json(out/'comparison.json',{'methods':summary,'paired':paired,'limits':['All conditions share official gold-based subset selection; three receive oracleK','First4000tokens/page, not full raw official replication','Exact keyword answer/reason scoring is not semantic correctness judgement','Primary contrasts aligned-vs-flat and aligned-vs-raw on NMI; other metrics/unknownK contrast diagnostics','Marginal95percent intervals, not family-wise adjusted significance claims']})
with (out/'per_question.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['method','question_id','status','NMI','answerScore','reasonScore'])
 for method,rs in methods.items():
  for q,r in rs.items():w.writerow([method,q,r['status'],r['NMI'],r['answerScore'],r['reasonScore']])
print(json.dumps(summary))
