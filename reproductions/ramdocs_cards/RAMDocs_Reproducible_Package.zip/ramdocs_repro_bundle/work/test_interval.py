import unittest
from interval_diagnostic import interval_decision
class IntervalTests(unittest.TestCase):
 def row(self,name='Rhea',lo=1830,hi=1890):
  q={'question':f'In which year did {name} receive the in-person award?','documents':[{'doc_id':'rule','text':f'The award rules require the recipient to be alive at the in-person ceremony; {name} lived from {lo} to {hi}.'}]}
  c=[{'doc_id':str(y),'entity':name,'answer':str(y),'support_status':'verified','quote':f'{name} received the in-person award in {y}.'} for y in (1850,1950)];return q,c
 def test_conditional_interval(self):
  q,c=self.row();self.assertEqual(interval_decision(q,c)['accepted_answers'],['1850'])
 def test_remove_rule(self):
  q,c=self.row();q['documents']=[];self.assertIsNone(interval_decision(q,c))
 def test_flip_premise(self):
  q,c=self.row(lo=1930,hi=1990);self.assertEqual(interval_decision(q,c)['accepted_answers'],['1950'])
 def test_conflicting_lifespans(self):
  q,c=self.row();q['documents'].append({'doc_id':'other','text':'Rhea lived from 1930 to 1990.'});self.assertEqual(interval_decision(q,c)['status'],'abstain')
 def test_no_implicit_posthumous_assumption(self):
  q,c=self.row();q['documents'][0]['text']='Rhea lived from1830 to1890.';self.assertIsNone(interval_decision(q,c))
 def test_negated_rule(self):
  q,c=self.row();q['documents'][0]['text']=q['documents'][0]['text'].replace('require','do not require');self.assertEqual(interval_decision(q,c)['status'],'abstain')
 def test_requires_verified_candidates(self):
  q,c=self.row();c[1]['support_status']='uncertain';self.assertIsNone(interval_decision(q,c))
 def test_same_entity(self):
  q,c=self.row();c[1]['entity']='Another person';self.assertIsNone(interval_decision(q,c))
if __name__=='__main__':unittest.main()
