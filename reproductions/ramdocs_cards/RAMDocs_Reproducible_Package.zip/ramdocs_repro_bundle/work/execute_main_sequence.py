"""Run declared phases in order; stop on infrastructure/integrity failure, retain artifacts."""
import hashlib,json,subprocess,time
from pathlib import Path
from real_runtime import ROOT,write_json
sources=['work/pipeline.py','work/decision_schema.py','work/real_runtime.py','work/run_experiment.py','work/madam_adapter.py','work/metrics.py']
expected={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in sources}
write_json(ROOT/'planning/protocols/main_freeze_v2.json',{'status':'code and prompts frozen before main benchmark inference; launch conditional on completed synthetic pilot and stress audit','code_hashes':expected,'field_scope':'document','model_revision':'a09a35458c702b33eeacc393d103063234e8bc28','verifier_revision':'96eafd01cee2d16cf81aaa2fb226b14f422a37b3','verifier_threshold':0.5,'selection':'same-document per-field evidence matches proposal; no benchmark predictions used for selection','limitations':'planning/protocols/execution_addendum_20261031.json','budget':'planning/protocols/full_execution_budget.json','frozen_epoch':time.time()})
def command(args,log):
 with (ROOT/log).open('w') as f:subprocess.run([str(ROOT/'.venv/bin/python'),*args],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
def check_code():
 for s,h in expected.items():
  if hashlib.sha256((ROOT/s).read_bytes()).hexdigest()!=h:raise RuntimeError('Frozen code changed: '+s)
def audit(run):
 command(['work/audit_run.py',run],'logs/'+Path(run).name+'-audit.log')
 a=json.loads((ROOT/run/'audit.json').read_text())
 if not a['all_outputs_accounted'] or a['missing_cache'] or a['bad_citations']:raise RuntimeError('Run integrity failure: '+run)
while True:
 p=ROOT/'runs/real-pilot20-v2/progress.json'
 if p.exists() and json.loads(p.read_text()).get('finished'):break
 time.sleep(5)
audit('runs/real-pilot20-v2');check_code()
command(['work/analyze_pilot.py','runs/real-pilot20-v2'],'logs/pilot_v2_analysis.log')
command(['work/run_experiment.py','--input','materials/prepared/stress_dev_v1/inputs.jsonl','--methods','raw,full,majority','--workers','4','--run','runs/stress39-v2'],'logs/stress39-v2.log')
audit('runs/stress39-v2');check_code()
command(['work/analyze_stress.py','runs/stress39-v2'],'logs/stress39-v2-analysis.log')
# Operational audit is the gate; wrong predictions remain measured failures, not prompt-selection targets.
command(['work/run_experiment.py','--input','materials/prepared/v1/ramdocs.inputs.jsonl','--methods','raw,flat,aligned,full,majority','--workers','8','--run','runs/ramdocs-main-v2'],'logs/ramdocs-main-v2.log')
audit('runs/ramdocs-main-v2');check_code()
command(['work/run_experiment.py','--input','materials/prepared/v1/conflicts.inputs.jsonl','--methods','plain,raw,full','--workers','8','--run','runs/conflicts-main-v2'],'logs/conflicts-main-v2.log')
audit('runs/conflicts-main-v2');check_code()
write_json(ROOT/'planning/main_sequence_finished.json',{'finished':True,'epoch':time.time(),'code_hashes':expected})
print('MAIN SEQUENCE FINISHED',flush=True)
