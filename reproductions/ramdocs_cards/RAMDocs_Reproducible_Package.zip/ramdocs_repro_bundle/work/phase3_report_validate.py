"""Validate local report links and numerical provenance; not a browser render."""
import json
from html.parser import HTMLParser
from pathlib import Path
from real_runtime import ROOT,write_json
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.images=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='a' and 'href' in a:self.links.append(a['href'])
  if tag=='img':self.images.append(a['src'])
p=ROOT/'analysis/phase3_complete/report.html';text=p.read_text();parser=Links();parser.feed(text);missing=[]
for url in parser.links+parser.images:
 if '://' not in url and not url.startswith('#') and not (p.parent/url.split('#')[0]).resolve().is_file():missing.append(url)
e=json.loads((ROOT/'analysis/phase3e/check_v2/summary.json').read_text());f=json.loads((ROOT/'analysis/phase3f/audit.json').read_text())
assert e['variants']['E_blind']['em']==134 and e['variants']['quote_fix']['em']==115 and f['n']==4038
required=['134/200','115/200','未通过','功能回归仍失败','200组保留集未开启','完整E1/E2','未生成编译PDF']
absent=[x for x in required if x not in text]
write_json(ROOT/'planning/phase3_complete/report_validation.json',{'local_links':len(parser.links),'images':len(parser.images),'missing_links':missing,'missing_required_disclosures':absent,'passed':not missing and not absent,'visual_evidence':'Three PNG figures inspected separately; HTML links/source validation only, not a browser-rendered layout check.'})
assert not missing and not absent,(missing,absent)
print('Report links, figures and required result/disclosure sentinels verified.')
