import json,hashlib,time,zipfile
from pathlib import Path
from real_runtime import ROOT,write_json
p=ROOT/'deliverables/phase3_review_bundle.zip';paths=set()
# Project scientific sources, frozen plans, analyses, prepared admitted data and raw traces.
for pattern in ['work/phase3*','work/component_metrics.py','work/scope_metrics.py','work/test_phase3_jsonl.py','planning/phase3*','analysis/phase3*','annotations/phase3_diagnostic_review','materials/prepared/phase3*','runs/phase3*','runs/request_cache/phase3*','runs/verifier_cache/phase3*']:
 for item in ROOT.glob(pattern):
  paths.update(f for f in item.rglob('*') if f.is_file() and '__pycache__' not in str(f)) if item.is_dir() else paths.add(item)
for f in ['AGENTS.md','planning/agent_state.json','planning/unknowns.json','planning/worksheet_data.json','materials/proposal_submitted.pdf','work/pipeline.py','work/real_runtime.py','work/metrics.py','work/confrag_metrics.py','work/analyze_confrag.py','work/analyze_benchmark.py','work/decision_schema.py','work/with_runtime.sh','work/phase2/pipeline.py']:
 paths.add(ROOT/f)
for f in (ROOT/'logs').glob('phase3*'):paths.add(f)
for f in (ROOT/'logs/runtime').glob('phase3*'):paths.add(f)
for f in (ROOT/'planning/csv').glob('*.csv'):paths.add(f)
for model in ['Qwen2.5-7B-Instruct','MiniCheck-Flan-T5-Large']:
 for name in ['download_manifest.json','config.json','tokenizer.json','tokenizer_config.json','special_tokens_map.json','vocab.json','merges.txt','spiece.model','added_tokens.json','generation_config.json']:
  f=ROOT/'models'/model/name
  if f.is_file():paths.add(f)
paths.update(f for f in (ROOT/'work').rglob('*') if f.is_file() and '__pycache__' not in str(f))
for f in ['conflict_aware_RAG/src/eval.py','materials/datasets/confrag/generateResult/TestPrompt.txt','materials/datasets/confrag/analysisResult/grade.py','materials/datasets/ambigdocs/source_manifest.json']:
 paths.add(ROOT/f)
for f in ['runs/ramdocs-combined-v3/analysis.json','runs/conflicts-main-v3/analysis.json','runs/confrag-cards-v3/analysis.json','runs/confrag-bounded-v1/analysis.json']:
 paths.add(ROOT/f)
paths.add(ROOT/'analysis/data_audit/data_audit.json')
for folder in (ROOT/'planning').glob('phase3*'):
 for f in folder.glob('*freeze*.json') if folder.is_dir() else []:
  for dependency in json.loads(f.read_text()).get('hashes',{}):paths.add(ROOT/dependency)
for d in ['materials/prepared/v1','materials/prepared/confrag_official_v1']:
 paths.update(p for p in (ROOT/d).glob('*') if p.is_file())
# Avoid including this archive or a mutable temporary/cache file.
paths={f for f in paths if f.is_file() and '.tmp' not in f.name and f!=p and f.name not in ['bundle_file_manifest.json','archive.json']}
manifest={str(f.relative_to(ROOT)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(paths)}
replay_path=ROOT/'planning/phase3_complete/package_replay.json';replay_verified=False
if replay_path.exists():
 replay=json.loads(replay_path.read_text())
 critical={k:v['sha256'] for k,v in manifest.items() if k.startswith(('work/','materials/','models/','runs/','analysis/')) or ('freeze' in k and k.endswith('.json'))}
 assert replay['passed'] and hashlib.sha256(json.dumps(critical,sort_keys=True).encode()).hexdigest()==replay['scientific_payload_fingerprint'],'Scientific payload changed after package replay; revalidate before final archive.'
 replay_verified=True
write_json(ROOT/'planning/phase3_complete/bundle_file_manifest.json',manifest)
with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(paths):z.write(f,str(f.relative_to(ROOT)))
 z.write(ROOT/'planning/phase3_complete/bundle_file_manifest.json','planning/phase3_complete/bundle_file_manifest.json')
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for name,info in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256'],name
write_json(ROOT/'planning/phase3_complete/archive.json',{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(manifest)+1,'crc_passed':True,'all_payload_hashes_verified':True,'replayed_scientific_payload_unchanged':replay_verified,'uploaded':False,'scope':'Local review archive; excludes model weights/full environment. Existing phase2 upload refusal respected.'})
print(p,p.stat().st_size,'bytes',len(manifest)+1,'files')
