"""Independent second-stage revisions; stage-one scientific files remain frozen."""
