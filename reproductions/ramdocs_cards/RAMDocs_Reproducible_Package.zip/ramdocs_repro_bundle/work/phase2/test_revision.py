import unittest
from phase2.pipeline import repair_quote,validate_scope_audit

class QuoteBoundaryTests(unittest.TestCase):
    def test_known_regression(self):
        text='Calibration sample Nera-576 was assigned archive label WILLOW-731.'
        r=repair_quote(' '+text,text);self.assertEqual(text[r['span_start']:r['span_end']],text)
    def test_exact_quote_preserved_even_repeated(self):self.assertIsNone(repair_quote('A B','A B; A B'))
    def test_ascii_boundary(self):self.assertEqual(repair_quote('\t answer here \r\n','X answer here Y')['canonical_quote'],'answer here')
    def test_internal_space_not_rewritten(self):self.assertIsNone(repair_quote(' answer  here ','answer here'))
    def test_case_not_rewritten(self):self.assertIsNone(repair_quote(' Answer ','answer'))
    def test_negation_not_removed(self):self.assertIsNone(repair_quote('not approved','approved'))
    def test_punctuation_not_rewritten(self):self.assertIsNone(repair_quote('"approved"','approved'))
    def test_empty_not_accepted(self):self.assertIsNone(repair_quote(' \n\t','anything'))
    def test_ambiguous_location_not_repaired(self):self.assertIsNone(repair_quote(' A B ','A B; A B'))
    def test_non_string(self):self.assertIsNone(repair_quote(None,'data'))
    def test_unicode_space_not_normalized(self):self.assertIsNone(repair_quote('\u00a0value','value'))
    def test_preserve_source_whitespace(self):self.assertIsNone(repair_quote(' value','a value'))
    def test_offsets(self):
        s='prefix: unique assertion. suffix';r=repair_quote('\tunique assertion.\n',s);self.assertEqual(s[r['span_start']:r['span_end']],r['canonical_quote'])

class OverlapTests(unittest.TestCase):
    def test_overlapping_spans_are_ambiguous(self):
        self.assertIsNone(repair_quote(' aa ', 'aaa'))

class ScopeAuditTests(unittest.TestCase):
    def setUp(self):
        self.cards=[{'card_id':'a'},{'card_id':'b'}];self.docs=[{'doc_id':'d','text':'Two distinct named devices.'}]
        self.pair={'left':'a','right':'b','label':'different_entity','citations':[{'doc_id':'d','quote':'Two distinct named devices.'}],'reason':'explicit distinction'}
    def test_valid(self):self.assertEqual(validate_scope_audit({'pairs':[self.pair]},self.cards,self.docs)['pairs'][0],self.pair)
    def test_missing(self):
        with self.assertRaises(ValueError):validate_scope_audit({'pairs':[]},self.cards,self.docs)
    def test_duplicate(self):
        with self.assertRaises(ValueError):validate_scope_audit({'pairs':[self.pair,self.pair]},self.cards,self.docs)
    def test_invented_span(self):
        self.pair['citations'][0]['quote']='invented'
        with self.assertRaises(ValueError):validate_scope_audit({'pairs':[self.pair]},self.cards,self.docs)
    def test_invented_card(self):
        self.pair['right']='z'
        with self.assertRaises(ValueError):validate_scope_audit({'pairs':[self.pair]},self.cards,self.docs)
    def test_invalid_label(self):
        self.pair['label']='true'
        with self.assertRaises(ValueError):validate_scope_audit({'pairs':[self.pair]},self.cards,self.docs)

if __name__=='__main__':unittest.main()
