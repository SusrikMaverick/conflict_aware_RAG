import json
from real_runtime import ROOT,write_json
s=json.loads((ROOT/'analysis/phase2/summary.json').read_text());reg=json.loads((ROOT/'runs/phase2-known-regression-v1/review.json').read_text());archive=json.loads((ROOT/'planning/phase2_drive_archive.json').read_text());unknown=json.loads((ROOT/'planning/phase2_unknown_row.json').read_text())
url=archive['url'];edits=[]
def add(sheet,row,col,values):edits.append({'sheetId':sheet,'row':row,'col':col,'values':values})
add(846003474,2,1,['第二阶段受控修订已完成：有效v2开发36题＋保留检查36题×3条件=216输出；另有已知失败回归。v1含类别提示的81输出保留但排除。','阶段二报告/逐题/审计见资料索引；人工gold、自然验证、72B及完整proposal实现仍待后续。','2026-11-03 America/Phoenix；第一阶段9618结果保留，非最终课程提交完成'])
c=s['check']['variants'];brief='；'.join(f"{m} {v['literal_correct']}/36，F1={v['relation_macro_f1']:.3f}" for m,v in c.items())
add(57601,33,10,['已完成（第二阶段受控修订与回归）','20边界测试；216有效输出；'+brief+'。已知故障quote恢复但最终仍弃答。analysis/phase2/report.html；planning/phase2_checklist.json。自然验证待后续。'])
for row,split in [(36,'dev'),(37,'check')]:
 ss=s[split]['variants'];result='；'.join(f"{m}字面{v['literal_correct']}/36，F1{v['relation_macro_f1']:.3f}，error{v['errors']}" for m,v in ss.items());cost='；'.join(f"{m} {v['total_prompt_tokens_logical']}/{v['total_completion_tokens_logical']}" for m,v in ss.items())
 add(57605,row,0,['S2-'+split,'原版→只修quote→加scope','phase2-v2-'+split+' / seed576','Qwen7B BF16；MiniCheck0.5；phase2_v2冻结','36构造题×3条件=108；非人类gold','2026-11-03；时间见manifest/progress',result,'逻辑输入/输出token：'+cost,'runs/phase2-v2-'+split,'冻结方法无跨split调整；错误保留；共享请求缓存隔离后处理','已完成（构造机制诊断）'])
add(57605,38,0,['S2-regression','旧失败固定抽取回归','phase2-known-regression-v1','仅ASCII边界quote修复','1个已知toy；非新测试','2026-11-03','精确引文恢复；卡片verified；最终仍abstain','1个新decision请求；旧extract缓存复用','runs/phase2-known-regression-v1','证明局部故障与answerability故障不同；端到端未修好','已完成（负结果保留）'])
add(57605,39,0,['S2-invalid-pilot','v1数据审计纠正','phase2-v1-dev','原pipeline；类别词意外进入站点名','81输出保留排除；v1 check未运行','2026-11-03','不用于效果统计','原始cache/log保留','runs/phase2-v1-dev/ABORTED_INVALID_DATA.json','v2使用随机编号并检查18份旧文件无代码复用；不是按正确率挑模型','已中止（无效数据，已纠正）'])
add(57606,8,3,['v2三条件216输出；引用/Scope作用分开。v1无效数据81输出保留。第一阶段预算诊断等旧记录仍在归档。','按预注册门槛采纳/拒绝；见analysis/phase2/decisions.json',brief+'；已知toy端到端仍失败。','下一轮区分pair关系与answerability；自然pair盲标及人工核验；不在已观察check上调参。','已完成（第二阶段复盘）'])
add(57610,21,0,unknown)
add(57611,128,0,['M128','阶段二分析','受控修订、审计、失败案例与下一阶段计划','2026-11-03 America/Phoenix','216有效输出；20测试；已知回归','全输出/cache/quote offset/源文件hash',url,'analysis/phase2/report.html；planning/phase3_entry_plan.txt','构造集；无人工gold；v1无效pilot排除；端到端toy仍失败'])
add(57611,129,0,['M129','阶段二本地归档包','phase2_review_bundle.zip','2026-11-03 America/Phoenix','代码/输入/逐题/原始请求/报告/协议/回归','本地CRC/SHA已验证；Drive上传被自动审批拒绝',url,'deliverables/phase2_review_bundle.zip','未上传：完整代码/逐题/raw cache载荷的目的地授权需确认；服务器包保留'])
requests=[]
for sheet,src,start,end,width in [(57605,34,36,40,11),(57610,20,21,22,8)]:
 requests.append({'copyPaste':{'source':{'sheetId':sheet,'startRowIndex':src,'endRowIndex':src+1,'startColumnIndex':0,'endColumnIndex':width},'destination':{'sheetId':sheet,'startRowIndex':start,'endRowIndex':end,'startColumnIndex':0,'endColumnIndex':width},'pasteType':'PASTE_FORMAT','pasteOrientation':'NORMAL'}})
for e in edits:
 requests.append({'updateCells':{'range':{'sheetId':e['sheetId'],'startRowIndex':e['row'],'endRowIndex':e['row']+1,'startColumnIndex':e['col'],'endColumnIndex':e['col']+len(e['values'])},'rows':[{'values':[{'userEnteredValue':{'stringValue':str(v)}} for v in e['values']]}],'fields':'userEnteredValue'}})
requests.append({'repeatCell':{'range':{'sheetId':57611,'startRowIndex':128,'endRowIndex':130,'startColumnIndex':0,'endColumnIndex':9},'cell':{'userEnteredFormat':{'wrapStrategy':'WRAP','verticalAlignment':'TOP','textFormat':{'fontFamily':'Arial','fontSize':11}}},'fields':'userEnteredFormat'}})
for sheet,start,end in [(846003474,2,3),(57601,33,34),(57605,36,40),(57606,8,9),(57610,21,22),(57611,128,130)]:requests.append({'autoResizeDimensions':{'dimensions':{'sheetId':sheet,'dimension':'ROWS','startIndex':start,'endIndex':end}}})
write_json(ROOT/'planning/phase2_sheet_edits.json',edits);write_json(ROOT/'planning/phase2_sheet_requests.json',requests)
print(len(edits),'edits',len(requests),'requests')
