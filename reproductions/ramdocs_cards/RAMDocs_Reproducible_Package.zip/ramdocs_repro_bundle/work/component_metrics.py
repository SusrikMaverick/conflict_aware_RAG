"""Shared fixed metrics for component studies; never reads held-out unless configured."""
import json,re,string,collections,random,hashlib,argparse
from pathlib import Path
from real_runtime import ROOT,write_json
def norm(s):
 s=''.join(c for c in s.lower() if c not in string.punctuation)
 return ' '.join(re.sub(r'\b(a|an|the)\b',' ',s).split())
def f1(a,b):
 x=norm(a).split();y=norm(b).split()
 if not x or not y:return float(x==y)
 n=sum((collections.Counter(x)&collections.Counter(y)).values());return 2*n/(len(x)+len(y))
def analyze(protocol):
 inputs=[json.loads(l) for l in (ROOT/protocol['input']).read_text().splitlines()];refs={r['question_id']:r for r in map(json.loads,(ROOT/protocol['eval']).read_text().splitlines())};run=ROOT/protocol['run'];out=ROOT/protocol['analysis'];out.mkdir(exist_ok=True)
 methods=protocol['methods'];records=[];casebook=[];audit={'missing_requests':[],'bad_citations':[]};cache={}
 for row in inputs:
  q=row['question_id'];ref=refs[q];gold=[a['text'] for a in ref['answers']] or [''];outputs={}
  for m in methods:
   x=json.loads((run/m/(q+'.json')).read_text());outputs[m]=x;pred=' '.join(x.get('accepted_answers',[]));ok=x['status'] not in ['error','parse_error'];em=int(ok and max(norm(pred)==norm(g) for g in gold));score=max(f1(pred,g) for g in gold) if ok else 0
   if ref['is_impossible'] and x['status']!='abstain':em=0;score=0
   docs={d['doc_id']:d['text'] for d in row['documents']}
   for cite in x.get('citations',[]):
    if not cite.get('quote') or cite.get('doc_id') not in docs or cite['quote'] not in docs[cite['doc_id']]:audit['bad_citations'].append([q,m,cite])
   for r in x.get('requests',[]):
    k=r['key'];p=ROOT/protocol['cache']/(k+'.json')
    if not p.exists():audit['missing_requests'].append([q,m,k])
    elif k not in cache:cache[k]=json.loads(p.read_text())
   records.append({'question_id':q,'group':ref['title_group'],'variant':m,'impossible':ref['is_impossible'],'status':x['status'],'error':x.get('error'),'em':em,'f1':score,'accepted':bool(x.get('accepted_answers',[])),'false_answer':bool(ref['is_impossible'] and x.get('accepted_answers',[])),'tokens':sum(r.get('usage',{}).get('total_tokens',0) for r in x.get('requests',[])),'calls':len(x.get('requests',[])),'verified_cards':sum(c.get('support_status')=='verified' for c in x.get('cards',[]))})
  casebook.append({'input':row,'reference':ref,'outputs':outputs})
 summary={}
 for m in methods:
  rr=[r for r in records if r['variant']==m];aa=[r for r in rr if not r['impossible']];uu=[r for r in rr if r['impossible']]
  summary[m]={'n':len(rr),'em':sum(r['em'] for r in rr),'f1':sum(r['f1'] for r in rr)/len(rr),'answerable_n':len(aa),'answerable_em':sum(r['em'] for r in aa),'unanswerable_n':len(uu),'false_answers':sum(r['false_answer'] for r in uu),'accepted':sum(r['accepted'] for r in rr),'errors':sum(r['status'] in ['error','parse_error'] for r in rr),'tokens':sum(r['tokens'] for r in rr),'calls':sum(r['calls'] for r in rr),'verified_cards':sum(r['verified_cards'] for r in rr)}
 contrasts={};rng=random.Random(576)
 for left,right in protocol.get('contrasts',[]):
  l={r['question_id']:r for r in records if r['variant']==left};r={r['question_id']:r for r in records if r['variant']==right};groups=collections.defaultdict(list)
  for q in l:groups[l[q]['group']].append((l[q],r[q]))
  keys=list(groups)
  for metric in ['em','f1','false_answer']:
   totals={g:(sum(float(a[metric])-float(b[metric]) for a,b in groups[g]),len(groups[g])) for g in groups}
   bs=[]
   for _ in range(5000):
    sample=rng.choices(keys,k=len(keys));bs.append(sum(totals[g][0] for g in sample)/sum(totals[g][1] for g in sample))
   bs.sort();contrasts[f'{left}-{right}/{metric}']={'delta':sum(x[0] for x in totals.values())/sum(x[1] for x in totals.values()),'cluster_bootstrap95':[bs[124],bs[4874]],'groups':len(keys),'false_answer_denominator':'all questions; see stratified count for unanswerable rate' if metric=='false_answer' else None}
 audit.update(passed=not any(audit.values()),n_outputs=len(records),unique_requests=len(cache),actual_tokens=sum(r.get('usage',{}).get('total_tokens',0) for r in cache.values()))
 result={'variants':summary,'contrasts':contrasts,'audit':audit,'split_role':protocol['split_role']}
 write_json(out/'summary.json',result);write_json(out/'per_question.json',records);write_json(out/'casebook.json',casebook);write_json(out/'output_hashes.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in run.glob('*/*.json')});print(json.dumps(result,indent=2));return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('protocol');a=p.parse_args();analyze(json.loads((ROOT/a.protocol).read_text()))
