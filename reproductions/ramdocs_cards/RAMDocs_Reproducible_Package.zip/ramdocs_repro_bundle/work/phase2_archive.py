"""Create a review archive without models, credentials, or natural benchmark corpora."""
import json,hashlib,zipfile
from pathlib import Path
from real_runtime import ROOT,write_json
paths=set()
for pattern in ['work/phase2*.py','work/phase2_server.sh','work/phase2/*.py','planning/phase2*.json','planning/phase3_entry_plan.txt','planning/protocols/phase2_v*.json','analysis/phase2/*','materials/prepared/phase2_v*/*.jsonl','runs/phase2-v*-*/*/*.json','runs/phase2-v*-*/*.json','runs/phase2-known-regression-v1/*.json','runs/phase2-known-regression-v1/request_cache/*.json','runs/request_cache/phase2_v*/*.json','runs/verifier_cache/phase2_v*/*.json','logs/phase2*.log']:
 paths.update(p for p in ROOT.glob(pattern) if p.is_file())
for rel in ['work/pipeline.py','work/real_runtime.py','work/decision_schema.py','work/metrics.py','work/madam_adapter.py','planning/protocols/main_freeze_v3.json','analysis/phase1/methods_and_deviations.txt','materials/prepared/reproduction_smoke_v1.inputs.jsonl','runs/phase1-reproduction-smoke-v1/full/reproduction-20261101-nera576.json']:paths.add(ROOT/rel)
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
p=ROOT/'deliverables/phase2_review_bundle.zip';assert not p.exists()
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(paths):z.write(f,str(f.relative_to(ROOT)))
 z.writestr('ARCHIVE_HASHES.json',json.dumps(manifest,indent=2))
 z.writestr('README.txt','NLP576 stage2 review archive, 2026-11-03 America/Phoenix.\nStart with analysis/phase2/report.html and known_regression_review.txt.\nValid comparison: phase2-v2 dev/check. v1 dev aborted for class-bearing names: retained, excluded.\nConstructed data, not human gold or natural efficacy evidence. End-to-end known regression still fails.\nNo models/venv/natural corpora included. Local baseline source and new raw request caches included. Model revisions, source hashes, decoding and gates in planning/protocols/phase2_v2.json.\nRead-only analysis command on original workspace: PYTHONPATH=work .venv/bin/python work/phase2_analyze_v2.py\nGeneration runners refuse overwriting completed outputs; regenerate only in an isolated copy with explicitly reviewed new destinations. Runtime launchers use original server paths; cross-machine reproduction has not been verified.\nNo team GitHub writes or existing conda changes.\n')
with zipfile.ZipFile(p) as z:assert z.testzip() is None
write_json(ROOT/'planning/phase2_archive.json',{'path':str(p),'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(paths)+2,'crc_passed':True})
print((ROOT/'planning/phase2_archive.json').read_text())
