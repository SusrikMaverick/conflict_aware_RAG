"""Synthetic construction-card diagnostic. Explicitly NOT human-gold evaluation."""
import collections,json,time,hashlib
from concurrent.futures import ThreadPoolExecutor,as_completed
from real_runtime import ROOT,Client,write_json
from pipeline import Pipeline
spec={
'C01':[('Rowan the ship',None,None,'2012'),('Rowan the astronaut',None,None,'2015')],
'C02':[('Project Ibis','version 1',None,'2010'),('Project Ibis','version 2',None,'2014')],
'C03':[('Project Ibis','first edition',None,'2010'),('Project Ibis','first edition',None,'2014')],
'C04':[(None,None,None,'2012'),(None,None,None,'2015')],
'C05':[('Vault Z',None,None,'114'),('Vault Z',None,None,'225')],
'C06':[('Vault Z',None,None,'114')]+[('Vault Z',None,None,'225')]*3,
'C07':[('Nera',None,None,'enjoyable'),('Nera',None,None,'unpleasant')],
'C08':[("Luma's office",None,'2020 through 2023','Elm'),("Luma's office",None,'2025','Oak')],
'C09':[('Aster',None,None,'10 April 1912'),('Aster',None,None,'April 1912')],
'C10':[('Mira',None,None,'flute'),('Mira',None,None,'drum')],
'C11':[('Ivo','in-person award',None,'1901'),('Ivo','in-person award',None,'2001')],
'C12':[('Tal',None,None,'4'),('Tal',None,None,'7')]}
refs={r['sample_id']:r for r in map(json.loads,(ROOT/'annotations/pilot30_agent_references.jsonl').open())};design={r['id']:r for r in json.loads((ROOT/'planning/design_review/counterexamples_v1_1.json').read_text())}
rows=list(map(json.loads,(ROOT/'materials/prepared/v1/synthetic_pilot_dev.inputs.jsonl').open()))[:20]
class ConstructionOracle(Pipeline):
 def extract(self,row,trace):
  if not row['question_id'].startswith('pilot-'):raise ValueError('Synthetic-only diagnostic; no benchmark oracle inference allowed')
  parent=refs[row['question_id']]['parent_question_id'].replace('design-','');cards=[]
  for i,(entity,sense,time_scope,answer) in enumerate(spec[parent]):
   d=row['documents'][i];q=design[parent]['documents'][i]['text'];pos=d['text'].find(q);assert pos>=0
   card={'card_id':d['doc_id']+':constructed','doc_id':d['doc_id'],'entity':entity,'sense_version':sense,'attribute':row['question'],'answer':answer,'valid_time':time_scope,'quote':q,'claim':q,'span_start':pos,'span_end':pos+len(q),'field_evidence':{'entity':entity,'sense_version':sense,'valid_time':time_scope,'answer':answer},'support_status':'verified','verification':{'status':'construction_oracle_not_human_or_MiniCheck'}};cards.append(card)
  return cards,[]
c=Client();p=ConstructionOracle(c);outdir=ROOT/'runs/constructed-oracle20-v2';outdir.mkdir(parents=True,exist_ok=True)
write_json(outdir/'manifest.json',{'scope':'20 synthetic development items, agent construction cards; bypasses extractor and MiniCheck; not human gold','input':'materials/prepared/v1/synthetic_pilot_dev.inputs.jsonl','selected_ids':[r['question_id'] for r in rows],'methods':['full'],'source_sha256':hashlib.sha256(__import__('pathlib').Path(__file__).read_bytes()).hexdigest()})
def one(row):
 path=outdir/'full'/(row['question_id']+'.json')
 if path.exists():return json.loads(path.read_text())
 try:r=p.run(row,'full');r['diagnostic']='constructed oracle, NOT human annotated'
 except Exception as e:r={'question_id':row['question_id'],'method':'full','status':'error','error':str(e),'requests':getattr(p.local,'trace',[])}
 write_json(path,r);return r
start=time.time();n=0;errors=0
with ThreadPoolExecutor(4) as pool:
 for f in as_completed([pool.submit(one,r) for r in rows]):
  r=f.result();n+=1;errors+=r['status']=='error';write_json(outdir/'progress.json',{'completed':n,'total':len(rows),'errors':errors,'finished':n==len(rows),'elapsed_seconds':time.time()-start})
print('finished',n,'errors',errors)
