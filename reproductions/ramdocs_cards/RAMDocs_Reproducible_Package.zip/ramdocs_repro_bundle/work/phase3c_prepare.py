"""Admit public human-authored QA only for a grounding/abstention component study."""
import json,re,hashlib,random,collections,urllib.parse,time
from pathlib import Path
from real_runtime import ROOT,write_json

def norm(s):return ' '.join(re.sub(r'[^\w\s]',' ',s.lower().replace('_',' ')).split())
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
oldq=set();olddoc=set();titles=set();files=[]
for p in (ROOT/'materials/prepared').rglob('*.inputs.jsonl'):
 if 'phase3c' in str(p):continue
 files.append(str(p.relative_to(ROOT)))
 for l in p.open():
  r=json.loads(l);oldq.add(norm(r['question']))
  for d in r.get('documents',[]):olddoc.add(sha(norm(d['text'])))
for l in (ROOT/'materials/datasets/ramdocs/RAMDocs_test.jsonl').open():
 r=json.loads(l)
 for e in r['disambig_entity']:
  if isinstance(e,str):titles.add(norm(e))
for l in (ROOT/'materials/datasets/conflicts/conflicts.jsonl').open():
 r=json.loads(l)
 for d in r['search_results']:
  u=d.get('url','')
  if 'wikipedia.org/wiki/' in u:titles.add(norm(urllib.parse.unquote(u.split('/wiki/',1)[1].split('#')[0])))
  if d.get('title','').endswith(' - Wikipedia'):titles.add(norm(d['title'][:-12]))
# ConfRAG page metadata: count any explicitly present Wikipedia URL/title.
for l in (ROOT/'materials/datasets/confrag/ConfRAGsuggested.jsonl').open():
 r=json.loads(l)
 for d in r['websites']:
  for u in re.findall(r'https?://[^\s)\]]*wikipedia\.org/wiki/[^\s)\]]+',d.get('content','')):titles.add(norm(urllib.parse.unquote(u.split('/wiki/',1)[1].split('#')[0])))

for p in (ROOT/'materials/prepared').rglob('*.eval.jsonl'):
 if 'phase3c' in str(p):continue
 for l in p.open():
  r=json.loads(l)
  if r.get('title_group'):titles.add(norm(r['title_group']))
  for pair in r.get('pairs',[]):
   if pair.get('title'):titles.add(norm(pair['title']))
data=json.loads((ROOT/'materials/datasets/squad2/train-v2.0.json').read_text());pool={False:[],True:[]}
for article in data['data']:
 title=norm(article['title'])
 if title in titles:continue
 for paragraph in article['paragraphs']:
  text=paragraph['context'];h=sha(norm(text))
  if not 30<=len(text.split())<=350 or len(text)>2500 or h in olddoc:continue
  for q in paragraph['qas']:
   if norm(q['question']) not in oldq:pool[q['is_impossible']].append((title,h,text,q))
rng=random.Random(33576)
for v in pool.values():rng.shuffle(v)
chosen=[];used=set()
for label in (False,True):
 part=[]
 for title,h,text,q in pool[label]:
  if title in used:continue
  part.append((title,h,text,q));used.add(title)
  if len(part)==50:break
 assert len(part)==50
 chosen+=part
rng.shuffle(chosen);base=ROOT/'materials/prepared/phase3c_v1';base.mkdir(exist_ok=True)
inputs=[];refs=[]
for title,h,text,q in chosen:
 for a in q['answers']:assert text[a['answer_start']:a['answer_start']+len(a['text'])]==a['text']
 inputs.append({'question_id':'sq2-'+q['id'],'question':q['question'],'documents':[{'doc_id':'d1','text':text}]})
 refs.append({'question_id':'sq2-'+q['id'],'title_group':title,'context_sha256':h,'is_impossible':q['is_impossible'],'answers':q['answers'],'source_split':'train','relation_gold':None})
for suffix,rows in [('inputs',inputs),('eval',refs)]:
 p=base/f'dev.{suffix}.jsonl';assert not p.exists();p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
write_json(ROOT/'planning/phase3c/data_admission.json',{'n':100,'article_groups':len(used),'answerable':50,'unanswerable':50,'excluded_all_prior_prepared_questions_and_contexts':True,'excluded_prior_benchmark_and_all_phase3_titles':True,'source':'SQuAD2train','purpose':'new component development only','remaining_unused_eligible_titles':len({t[0] for v in pool.values() for t in v}-used),'limits':['Exact grouping does not rule out semantic aliases/pretraining exposure','Published answerability labels; no human relation gold']})
print('Prepared fresh100titles; remaining',len({t[0] for v in pool.values() for t in v}-used))
