"""Exploratory transfer contrasts; no held-out adoption decision."""
import json,csv,collections,random
from real_runtime import ROOT,write_json
def boot(pairs,metric):
 groups=collections.defaultdict(list)
 for a,b,g in pairs:groups[g].append(float(a[metric])-float(b[metric]))
 rng=random.Random(576);keys=sorted(groups);vals={g:(sum(v),len(v)) for g,v in groups.items()};bs=[]
 for _ in range(5000):
  sample=rng.choices(keys,k=len(keys));bs.append(sum(vals[g][0] for g in sample)/sum(vals[g][1] for g in sample))
 bs.sort();return {'delta':sum(v[0] for v in vals.values())/sum(v[1] for v in vals.values()),'cluster_bootstrap95':[bs[124],bs[4874]],'groups':len(keys),'questions':sum(v[1] for v in vals.values()),'role':'exploratory, previously observed benchmarks'}
def main():
 p=json.loads((ROOT/'planning/phase3f/runtime2_freeze.json').read_text());run=ROOT/p['run'];groupof={}
 def visit(v):
  if isinstance(v,dict):
   if 'question_id' in v and 'group_id' in v:groupof[v['question_id']]=v['group_id']
   for x in v.values():visit(x)
  elif isinstance(v,list):
   for x in v:visit(x)
 visit(json.loads((ROOT/'materials/prepared/v1/split_manifest.json').read_text()))
 oldquestions=collections.defaultdict(list)
 for r in map(json.loads,(ROOT/'materials/prepared/v1/confrag.inputs.jsonl').open()):oldquestions[r['question']].append(r['question_id'])
 mapping={}
 for r in map(json.loads,(ROOT/p['datasets']['confrag']['input']).open()):
  ids=oldquestions[r['question']];assert len(ids)==1 and ids[0] in groupof
  groupof[r['question_id']]=groupof[ids[0]];mapping[r['question_id']]={'original_question_id':ids[0],'group_id':groupof[ids[0]],'join':'unique exact original question text'}
 write_json(ROOT/'planning/phase3f/confrag_group_mapping.json',mapping)
 summary={};contrasts={};cost={}
 for dataset in p['datasets']:
  summary[dataset]=json.loads((run/dataset/'analysis.json').read_text())['methods']
  if dataset=='ramdocs':records=list(csv.DictReader((run/dataset/'per_question_metrics.csv').open()));metrics=['official_compatible','strict_set_exact','wrong_only_accepted','any_accepted']
  elif dataset=='confrag':records=list(map(json.loads,(run/dataset/'scored.jsonl').open()));metrics=['NMI','answerScore','reasonScore']
  else:records=[];metrics=[]
  a={r['question_id']:r for r in records if r['method']=='F_E'};b={r['question_id']:r for r in records if r['method']=='F_C1'}
  # ConfRAG adapter IDs join to frozen groups through unique exact question text.
  for metric in metrics:
   value=boot([(a[q],b[q],groupof.get(q,q)) for q in a],metric);value['group_manifest_matches']=sum(q in groupof for q in a);value['grouping']='frozen source groups where mapped, else question-wise';contrasts[dataset+'/'+metric]=value
  for m in p['methods']:
   rows=[json.loads(f.read_text()) for f in (run/dataset/m).glob('*.json')]
   cost[dataset+'/'+m]={'n':len(rows),'tokens':sum(r.get('usage',{}).get('total_tokens',0) for x in rows for r in x.get('requests',[])),'logical_calls':sum(len(x.get('requests',[])) for x in rows),'summed_task_seconds':sum(x['wall_seconds'] for x in rows),'note':'logical cost includes shared cached requests; wall sum is not independent latency benchmark'}
 old={}
 for dataset,path,methods in [('ramdocs','runs/ramdocs-combined-v3/analysis.json',['full','plain','madam']),('confrag','runs/confrag-cards-v3/analysis.json',['aligned_K','flat_K']),('confrag_direct','runs/confrag-bounded-v1/analysis.json',['oracle_K','unknown_K']),('conflicts','runs/conflicts-main-v3/analysis.json',['full'])]:
  v=json.loads((ROOT/path).read_text())['methods'];old[dataset]={m:v[m] for m in methods}
 write_json(ROOT/'analysis/phase3f/summary.json',{'methods':summary,'paired':contrasts,'cost':cost,'old_reference':old,'interpretation':'All exploratory; F_E versus F_C1 isolates binding, comparisons to old full also change card representation. No relation accuracy without human labels.'});print(json.dumps(contrasts,indent=2))
if __name__=='__main__':main()
