import json,collections,hashlib
from real_runtime import ROOT,write_json
p=ROOT/'analysis/phase3b/v2';s=json.loads((p/'summary.json').read_text());v=s['variants'];a=v['B'];b=v['quote_fix'];g=v['generic']
gates={'answerable_gain_ge5pp':(a['answerable_em']-b['answerable_em'])/50>=.05,'all_em_gain_ge5pp':(a['em']-b['em'])/100>=.05,'false_answer_increase_le2pp':(a['false_answers']-b['false_answers'])/50<=.02,'errors_not_increased':a['errors']<=b['errors'],'logical_tokens_le2x':a['tokens']/b['tokens']<=2,'not_worse_than_generic':a['em']>=g['em'],'citations_and_requests_valid':s['audit']['passed']}
cases=json.loads((p/'casebook.json').read_text());mechanism=collections.Counter();examples=[]
for case in cases:
 q=case['input']['question_id'];old=case['outputs']['quote_fix'];new=case['outputs']['B']
 if new['status']=='error':mechanism['B_error_'+str(new.get('error'))]+=1
 if not case['reference']['is_impossible']:
  mechanism['answerable_no_card']+=not old.get('cards');mechanism['answerable_no_verified']+=not any(c['support_status']=='verified' for c in old.get('cards',[]))
 if old.get('accepted_answers')!=new.get('accepted_answers') or new['status']=='error':examples.append({'question_id':q,'question':case['input']['question'],'reference':case['reference'],'old':old,'B':new})
out={'gates':gates,'continue_B':all(gates.values()),'mechanism':dict(mechanism),'interpretation':'development only; explicit condition decomposition requires advantage over generic, not just old prototype'}
write_json(p/'decision.json',out);write_json(p/'changed_cases.json',examples);print(json.dumps(out,indent=2))
