import json,os,time,urllib.request
from pathlib import Path
from real_runtime import Client,ROOT,write_json
c=Client();r=c.chat('Return only the JSON object {"runtime_test":"ok"}.',64,True)
assert json.loads(r['text'])=={'runtime_test':'ok'}
write_json(ROOT/'planning/real_backend_smoke.json',r)
print(json.dumps({k:r[k] for k in ('text','usage','latency_seconds','model_revision')}))
