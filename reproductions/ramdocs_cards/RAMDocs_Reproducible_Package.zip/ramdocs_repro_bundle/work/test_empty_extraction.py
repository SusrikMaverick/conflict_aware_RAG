import unittest
from pipeline import Pipeline
class EmptyReply:
 def chat(self,*args,**kwargs):return {'key':'toy','usage':{},'latency_seconds':0,'cache_hit':False,'attempts':1,'finish_reason':'stop','text':'{}'}
class EmptyContract(unittest.TestCase):
 def test_empty_object_is_a_logged_extraction_miss(self):
  cards,issues=Pipeline(EmptyReply()).extract({'question':'year?','documents':[{'doc_id':'d','text':'No year is given.'}]},[])
  self.assertEqual(cards,[]);self.assertEqual(issues[0]['error'],'empty_object_normalized_to_no_extracted_cards');self.assertEqual(issues[0]['raw_request_key'],'toy')
if __name__=='__main__':unittest.main()
