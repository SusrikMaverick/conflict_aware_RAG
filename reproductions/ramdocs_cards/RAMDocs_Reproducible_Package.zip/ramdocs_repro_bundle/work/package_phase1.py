"""Create a review bundle after explicit final checks; raw caches/models stay on server."""
import hashlib,json,zipfile,time
from pathlib import Path
from real_runtime import ROOT,write_json
check=json.loads((ROOT/'planning/phase1_final_review.json').read_text())
for key in ['completed_all_declared_runs','worksheet_verified','owned_server_stopped','source_integrity_passed','figures_reviewed','budget_diagnostic_finished','fresh_smoke_reviewed']:assert check.get(key),key
assert json.loads((ROOT/'planning/extra_analysis_finished.json').read_text())['finished']
paths=set()
for name in ['analysis/phase1','analysis/figures','analysis/confrag_comparison']:
 paths.update(p for p in (ROOT/name).rglob('*') if p.is_file())
for name in ['work','planning','annotations']:
 paths.update(p for p in (ROOT/name).rglob('*') if p.is_file() and p.suffix in ['.py','.sh','.json','.jsonl','.txt','.csv','.lock'] and '__pycache__' not in p.parts)
for d in (ROOT/'runs').iterdir():
 if d.is_dir():
  paths.update(p for p in (d/'runtime_history').rglob('*') if p.is_file())
  for name in ['manifest.json','progress.json','audit.json','analysis.json','per_question_metrics.csv','scored.jsonl','recovered_request_links.json','ABORTED.json']:
   if (d/name).is_file():paths.add(d/name)
for name in ['analysis/extraction_annotation_proxy.json','analysis/interval_natural_applicability.json','analysis/interval_stress_diagnostic.json','analysis/data_audit/data_audit.json','AGENTS.md','.metadata/github_snapshot.json']:
 p=ROOT/name
 if p.is_file():paths.add(p)
readme='''NLP576 first-stage7B review bundle
Open analysis/phase1/report.html. The paired figures, per-question score tables, method deviations, deterministic casebook, source snapshots, protocols and worksheet backup are included.
Full raw model-response caches, complete input corpora, per-question trace files, model weights and Python environments remain in the server workspace: /mnt/disk11/user/xiaoyih1/course_projects/nlp576
This is a review bundle, not a self-contained model/data mirror or a passing functional release. The final fresh positive-control passed for plain and failed for full (added leading quote space, discarded card, abstention); the failure is retained in planning/final_smoke_review.json. See analysis/phase1/reproduce.txt for historical-source replay and fresh-generation requirements. No human-gold or72B results are implied. Annotation drafts/review packets remain unreviewed and their keys/references are separate files. Worksheet: https://docs.google.com/spreadsheets/d/1kyOgopAvdpwcipRXhXNwefmUYDv2N-Vowr9zRlbRyQA/edit
'''
manifest={'created_epoch':time.time(),'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},'scope':'review artifacts and code; raw corpus/cache/model/env excluded'}
out=ROOT/'deliverables/phase1_review_bundle.zip';out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('README.txt',readme);z.writestr('bundle_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
 for p in sorted(paths):assert p.resolve().is_relative_to(ROOT);z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
info={'path':str(out),'size_bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'md5':hashlib.md5(out.read_bytes()).hexdigest(),'file_count':len(paths)+2,'zip_crc_verified':True};write_json(ROOT/'planning/phase1_bundle.json',info);print(json.dumps(info))
