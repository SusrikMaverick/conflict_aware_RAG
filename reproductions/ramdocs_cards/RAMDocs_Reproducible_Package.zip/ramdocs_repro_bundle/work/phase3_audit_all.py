"""Preservation audit, never overwrites historical audits."""
import json,hashlib,time
from real_runtime import ROOT,write_json
src=(ROOT/'work/verify_phase1_integrity.py').read_text().replace("ROOT/'planning/phase1_final_integrity.json'","ROOT/'planning/phase3f/prior_phase1_integrity.json'")
exec(compile(src,'preservation_audit','exec'))
checks={};failure=[]
for f in ['planning/phase2_output_hashes.json','planning/phase3/output_hashes.json']:
 x=json.loads((ROOT/f).read_text());x=x.get('output_sha256',x)
 if 'hashes' in x:x=x['hashes']
 if 'sha256' in x:x=x['sha256']
 n=0
 for path,h in x.items():
  if not isinstance(h,str) or len(h)!=64:continue
  n+=1
  if hashlib.sha256((ROOT/path).read_bytes()).hexdigest()!=h:failure.append(path)
 assert n>0,f
 checks[f]=n
for file in ['planning/protocols/phase2_v2.json','planning/phase3/dev_freeze_v1.json','planning/phase3b/freeze_v2.json','planning/phase3c/freeze_v1.json','planning/phase3d/dev_freeze_v1.json','planning/phase3d/bound_dev_freeze_v1.json','planning/phase3e/dev_freeze_v2.json','planning/phase3e/check_freeze_v2.json','planning/phase3f/freeze_v1.json','planning/phase3f/freeze_v2.json','planning/phase3f/freeze_v3.json','planning/phase3f/runtime2_freeze.json']:
 p=json.loads((ROOT/file).read_text());hashes=p.get('hashes',p.get('code_hashes',{}));checks[file]=len(hashes)
 for f,h in hashes.items():
  if hashlib.sha256((ROOT/f).read_bytes()).hexdigest()!=h:failure.append(f)
transition=json.loads((ROOT/'planning/phase3f/runtime_transition_v2.json').read_text())
for kind,expected in [('preserved_outputs',787),('preserved_cache',3900)]:
 hashes=transition[kind];assert len(hashes)==expected
 checks['runtime_transition/'+kind]=len(hashes)
 for f,h in hashes.items():
  if hashlib.sha256((ROOT/f).read_bytes()).hexdigest()!=h:failure.append(f)
write_json(ROOT/'planning/phase3f/preservation_audit.json',{'epoch':time.time(),'checks':checks,'mismatches':failure,'passed':not failure});assert not failure
