"""Deterministic constructed mechanism checks; no human/natural gold claim."""
import json,hashlib,time
from pathlib import Path
from real_runtime import ROOT,write_json
families=['singleton','agreement','entity','version','time','complementary','contradiction','unclear','opinion']
base=ROOT/'materials/prepared/phase2_v1';base.mkdir(parents=True,exist_ok=True)
for split,prefix in [('dev','DORIN'),('check','VELAN')]:
 rows=[];refs=[]
 for f in families:
  for i in range(4):
   ident=f'{prefix}-{f}-{i}';a=f'{prefix}A{families.index(f)}{i}';b=f'{prefix}B{families.index(f)}{i}';name=f'Station {ident}'
   verb='has access code' if split=='dev' else 'uses entry token'
   q=f'What codes or tokens are explicitly assigned to {name}? Preserve distinct scopes.'
   docs=[f'{name} {verb} {a}.'];answers=[a];relation='insufficient_information';scope=None
   if f=='agreement':docs*=2;relation='agreement';scope='same_scope'
   if f=='entity':
    docs=[f'{name} in North District {verb} {a}.',f'{name} in South District {verb} {b}.'];answers=[a,b];relation='different_entity';scope='different_entity'
   if f=='version':
    docs=[f'{name} in simulation version 1 {verb} {a}.',f'{name} in simulation version 2 {verb} {b}.'];answers=[a,b];relation='different_sense_version';scope='different_event_or_version'
   if f=='time':
    docs=[f'{name} {verb} {a} during 2021 only.',f'From 2022 onward, {name} replaced its previous code and {verb} {b}.'];answers=[a,b];relation='temporal_update';scope='different_time'
   if f=='complementary':
    docs=[f'{name} simultaneously accepts multiple access tokens. One accepted token is {a}.',f'{name} simultaneously accepts multiple access tokens. Another accepted token is {b}.'];answers=[a,b];relation='complementary';scope='same_scope'
   if f=='contradiction':
    docs=[f'At 12:00 on 2025-03-01, {name} has exactly one active access token: {a}.',f'At 12:00 on 2025-03-01, {name} has exactly one active access token: {b}.'];answers=[];relation='contradiction';scope='same_scope'
   if f=='unclear':
    docs=[f'A station named {ident} {verb} {a}; its location and identity are unspecified.',f'A station named {ident} {verb} {b}; its location and identity are unspecified.'];answers=[];relation='insufficient_information';scope='unclear'
   if f=='opinion':
    q=f'Which token does each reviewer prefer for {name}?'
    docs=[f'Reviewer Lio personally prefers token {a} for {name}.',f'Reviewer Tavi personally prefers token {b} for {name}.'];answers=[a,b];relation='opinion';scope=None
   # Singleton tests whether the inherited fewer-than-two-cards policy can answer a single source.
   rows.append({'question_id':ident,'question':q,'documents':[{'doc_id':f'd{j+1}','text':t} for j,t in enumerate(docs)]})
   refs.append({'question_id':ident,'family':f,'answers':answers,'candidate_literals':[a,b] if len(docs)>1 else [a],'relation':relation if f!='singleton' else None,'scope':scope,'desired_status':'abstain' if not answers else 'nonempty','reference_type':'agent_constructed_design_expectation'})
 for suffix,data in [('inputs',rows),('eval',refs)]:
  p=base/f'{split}.{suffix}.jsonl'
  if p.exists():assert p.read_text()==''.join(json.dumps(r)+'\n' for r in data)
  else:p.write_text(''.join(json.dumps(r)+'\n' for r in data))
write_json(ROOT/'planning/phase2_data_review.json',{'n_per_split':36,'families':families,'no_annotation_fields_in_inputs':True,'disjoint_ids_and_answer_literals':True,'limitations':['Constructed by same agent; not human gold','Shared concepts/templates; check is held out from output-guided tuning but not independent distribution','Singleton has no relation target because taxonomy is pair-based','Opinion scope target omitted because reviewer identity complicates pair scope'],'counterexamples_review':['No majority or world-truth target','Same-time exclusive token is explicit contradiction','Different entity/event/time are explicitly scoped','Complementary tokens explicitly coexist','No identity inference for unclear cases']})
print(base)
