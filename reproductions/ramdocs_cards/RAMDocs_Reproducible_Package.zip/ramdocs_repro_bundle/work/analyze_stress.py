import argparse,collections,json
from pathlib import Path
from real_runtime import ROOT,write_json
from metrics import normalize
ap=argparse.ArgumentParser();ap.add_argument('run',type=Path);a=ap.parse_args()
refs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/stress_dev_v1/references.jsonl').open())};allrows=[];summary={}
for d in sorted(a.run.iterdir()):
 if not d.is_dir():continue
 rows=[]
 for p in sorted(d.glob('*.json')):
  r=json.loads(p.read_text());ref=refs[r['question_id']];expected=ref['expected'];accepted=r.get('accepted_answers',[])
  rr={'question_id':r['question_id'],'method':d.name,'group_id':ref['group_id'],'variant':ref['variant'],'relation':r.get('relation'),'expected_relation':expected['relation'],'relation_correct':r.get('relation')==expected['relation'],'status':r['status'],'accepted_answers':accepted,'expected_answers':expected['accepted_answers'],'expected_abstention':not expected['accepted_answers'],'abstention_correct':not accepted if not expected['accepted_answers'] else None,'exact_answer_set':set(map(normalize,accepted))==set(map(normalize,expected['accepted_answers'])),'decision_basis':r.get('decision_basis'),'constraint':r.get('constraint')};rows.append(rr)
 byid={r['question_id']:r for r in rows};changes=[]
 for r in rows:
  if r['variant'] not in ('reverse','duplicate_first_x5'):continue
  base=byid.get('stress-'+r['group_id']+'-original')
  if base:changes.append({'id':r['question_id'],'variant':r['variant'],'relation_changed':r['relation']!=base['relation'],'answer_set_changed':set(map(normalize,r['accepted_answers']))!=set(map(normalize,base['accepted_answers'])),'status_changed':r['status']!=base['status']})
 summary[d.name]={'n':len(rows),'relation_accuracy':sum(r['relation_correct'] for r in rows)/len(rows) if rows and any(r['relation'] is not None for r in rows) else None,'status_counts':dict(collections.Counter(r['status'] for r in rows)),'unresolved_cases':sum(r['expected_abstention'] for r in rows),'unresolved_with_accepted_answer':sum(r['expected_abstention'] and bool(r['accepted_answers']) for r in rows),'perturbation_changes':changes,'constraint_cases':[r for r in rows if r['group_id']=='C11']};allrows+=rows
write_json(a.run/'analysis.json',{'scope':'constructed dev counterfactuals and perturbations; not human gold','methods':summary});write_json(a.run/'case_review.json',allrows)
print(json.dumps(summary,indent=2))
