"""Post-evaluation descriptive audit of policy guards, not human correctness labels."""
import collections, json
from real_runtime import ROOT, write_json

out = {'scope': 'Descriptive, post-test; no prompt/threshold/prediction changes. Counts do not certify semantic correctness.', 'datasets': {}}
for dataset, run in [('ramdocs', 'ramdocs-main-v3'), ('conflicts', 'conflicts-main-v3')]:
    rows = [json.loads(p.read_text()) for p in (ROOT/'runs'/run/'full').glob('*.json')]
    reasons = collections.Counter(x for r in rows for x in r.get('enforcement_reasons', []))
    issues = collections.Counter(x.get('error','unknown') for r in rows for x in r.get('extraction_issues', []))
    cards = [c for r in rows for c in r.get('cards', [])]
    nulls = collections.Counter(f for c in cards for f in ['entity','sense_version','valid_time'] if isinstance(c.get(f), str) and c[f].lower().strip() == 'null')
    accepted_e1 = [{'question_id': r['question_id'], 'relation': r.get('relation'), 'status': r['status'], 'answers': r.get('accepted_answers')} for r in rows if r.get('accepted_answers') and r.get('decision_basis') == 'E1']
    accepted_e2 = [{'question_id': r['question_id'], 'relation': r.get('relation'), 'status': r['status']} for r in rows if r.get('accepted_answers') and r.get('decision_basis') == 'E2']
    out['datasets'][dataset] = {'n': len(rows), 'enforcement_reason_counts_nonexclusive': dict(reasons),
        'extraction_log_entries': dict(issues), 'retained_cards': len(cards), 'literal_null_string_fields': dict(nulls),
        'accepted_with_model_E1_label': accepted_e1, 'accepted_with_model_E2_label': accepted_e2,
        'accepted_E1_note': 'E1 rejection is only in the predicted-contradiction guard. Other predicted labels can retain E1 strings and accepted answers; these are not independently validated authority/correction decisions.',
        'empty_object_note': 'Logged {} normalization is not itself proof of incorrect extraction; some documents contain no relevant answer. Other issue types are counted separately.'}
write_json(ROOT/'analysis/phase1/policy_diagnostics.json', out)
print(json.dumps(out, ensure_ascii=False))
