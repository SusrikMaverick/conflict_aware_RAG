"""Continue scientific v3 with recorded runtime-only worker concurrency changes.
Requires the existing scientific freeze; never re-freezes from current files.
"""
import hashlib,json,subprocess,time
from pathlib import Path
from real_runtime import ROOT,write_json
freeze=json.loads((ROOT/'planning/protocols/main_freeze_v3.json').read_text());expected=freeze['code_hashes']
def verify():
 for path,h in expected.items():
  assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h,('Frozen source changed',path)
def command(args,log):
 verify()
 with (ROOT/log).open('w') as f:subprocess.run([str(ROOT/'.venv/bin/python'),*args],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
for dataset,methods,run in [('ramdocs','raw,flat,aligned,full,majority','ramdocs-main-v3'),('conflicts','plain,raw,full','conflicts-main-v3')]:
 command(['work/run_experiment.py','--input',f'materials/prepared/v1/{dataset}.inputs.jsonl','--methods',methods,'--workers','24','--run','runs/'+run],'logs/'+run+'-workers24.log')
 command(['work/audit_run.py','runs/'+run],'logs/'+run+'-audit.log')
 a=json.loads((ROOT/'runs'/run/'audit.json').read_text());assert a['all_outputs_accounted'] and not a['missing_cache'] and not a['bad_citations']
 verify()
write_json(ROOT/'planning/main_sequence_finished.json',{'finished':True,'version':'scientific_v3_runtime_workers24','epoch':time.time(),'code_hashes':expected})
print('FROZEN V3 SEQUENCE FINISHED',flush=True)
