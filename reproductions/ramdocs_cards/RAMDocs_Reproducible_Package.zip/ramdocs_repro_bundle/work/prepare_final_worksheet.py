"""Prepare cell-level edits from the last shared-sheet snapshot; apply/readback separately."""
import json
from real_runtime import ROOT, write_json

def read(name): return json.loads((ROOT/name).read_text())
assert read('planning/extra_analysis_finished.json')['finished']
assert (ROOT/'planning/final_runtime_smoke.json').exists()
before=read('planning/worksheet_before_final.json')
tabs=read('planning/worksheet_data.json')['tabs']
meta={t['title']:t for t in tabs}
edits=[]
def cell(tab,row,col,value):
    values=before[tab]['values']
    old=values[row][col] if row<len(values) and col<len(values[row]) else ''
    if old!=value: edits.append({'tab':tab,'sheetId':meta[tab]['sheetId'],'row':row,'col':col,'before':old,'after':str(value)})
def rec(tab,key,col,value):
    row=next(i for i,r in enumerate(before[tab]['values']) if r and r[0]==key)
    cell(tab,row,col,value)
def cells(tab,row,vals):
    for col,v in enumerate(vals):cell(tab,row,col,v)

ram=read('runs/ramdocs-combined-v3/analysis.json')
conf=read('analysis/confrag_comparison/comparison.json')
budget=read('runs/output_budget_diagnostic_v1/analysis.json')
smoke=read('planning/final_runtime_smoke.json')
ledger=read('analysis/phase1/run_ledger.json')
f=ram['methods']['full']; p=ram['methods']['plain']; m=ram['methods']['madam']
headline=f"RAMDocs500：full {f['official_compatible']:.1%}，plain {p['official_compatible']:.1%}，MADAM {m['official_compatible']:.1%}；当前原型未胜过普通RAG，完整统计与覆盖权衡见report。"
scope='本轮固定7B计算与整理完成：RAMDocs500×8、CONFLICTS458×3、ConfRAG1061×4，共9,618逐题输出，含所有失败；另有开发/压力、预算诊断与新smoke。'
rec('00_使用说明','项目定位',1,'研究结构化证据对齐是否改善关系分类与回答行为；本轮7B原型出现明确负结果，不能声称主方法已有效。')
rec('00_使用说明','项目定位',2,headline)
rec('00_使用说明','本次工作范围',1,scope)
rec('00_使用说明','本次工作范围',2,'已完成全量审计、配对统计、案例复盘与阶段归档；人工gold、72B、独立CONFLICTS评价和完整proposal实现仍缺。')
rec('00_使用说明','本次工作范围',3,'阶段核验：2026-10-31 America/Phoenix；不等于最终课程提交完成')
rec('00_使用说明','环境约束',2,'项目内.venv/.analysis-venv；42项测试＋1000缓存重放；新toy推理已检查。现有conda未改；自有GPU服务在归档前释放。')
rec('00_使用说明','环境约束',3,'phase1_tests.json、cache_replay_baselines.json、final_runtime_smoke.json、runtime_release.json')
rec('00_使用说明','已知完成项',1,'P01–08、P10–16、P22–24及本轮P29/P30有完成证据；P18–21为有缺口原型，P25–28/P31–34按真实范围标部分完成。人工门槛仍未通过。')
rec('00_使用说明','已知完成项',2,'阶段报告：analysis/phase1/report.html；逐项状态见01，实际run见05，负结果与改进见06。')
rec('00_使用说明','下一次agent开始',1,'先读阶段report、qualitative_review、methods_and_deviations与agent_state；不得把本轮partial任务当proposal全部实现。')
rec('00_使用说明','下一次agent开始',2,'本轮运行结束；不要重启旧控制器或改写正式输出。后续方法改进使用新dev，已看测试再次使用标exploratory；GitHub仍只读。')

states={
'P25':('部分完成（7B基线已完成）','RAMDocs500题×8方法全部完成；普通RAG/MADAM/多数票齐备；独立预算匹配MADAM未做。runs/ramdocs-combined-v3/analysis.json'),
'P26':('部分完成（7B矩阵已完成）','RAMDocs消融与CONFLICTS458×3完成；所有失败入分母；人工oracle/关系test和完整多关系实现尚缺。'),
'P27':('部分完成（独立诊断已完成）','closed-book500与构造约束诊断完成；自然interval适用率见analysis/interval_natural_applicability.json；memory融合checker未做。'),
'P28':('部分完成（4条件计算已完成）','ConfRAG1061×4完成；官方确定性评分与配对group bootstrap齐全；gold选页/oracleK/4000tokens每页限制公开；人工质量抽检仍缺。'),
'P29':('已完成（本轮构造诊断）','stress39-v3：39×3，0接口错误；不可裁决17例full误接受1、raw1、majority8。可选来源合并/训练/第二模型本轮延期。'),
'P30':('已完成（本轮7B）','六个主run全部题目齐全、缓存/精确引文审计通过；原始trace一致性及3663份断点前输出hash核验；历史失败和运行偏差保留。'),
'P31':('部分完成（可计算指标已完成）','RAMDocs/ConfRAG配对group bootstrap2000次；覆盖/风险、分层与4组图齐全。自然人工关系F1与CONFLICTS适当性无gold，未伪造。'),
'P32':('部分完成（自动分析＋agent复核）','500题自动桶＋固定哈希抽样26题agent复核，5例原文核对；非人工最早错误gold。analysis/phase1/qualitative_review.txt与casebook.html。'),
'P33':('部分完成（探索性诊断已完成）',f"输出上限加倍：{budget['n_selected']}条失败请求中{budget['complete_JSON_after_larger_cap']}条恢复完整JSON；只诊断格式，未改正式预测；新方法独立验证待做。"),
'P34':('部分完成（阶段证据已归档）','42项fixture、1000条匹配归档源码缓存重放、新toy真实推理（plain答对、full引用前导空格被拒后弃答，smoke未通过）、源码/PDF/检查点hash、图表检查与阶段review bundle；尚非完整课程release或另一台机器独立复现。')}
for key,(status,evidence) in states.items():rec('01_执行流程',key,10,status);rec('01_执行流程',key,11,evidence)

exp={
'E01':'已完成（本轮7B）：RAMDocs500与CONFLICTS458；完整失败记录与统计已归档',
'E02':'部分完成：原文分类/回答全量完成；自然8类人评与F1仍缺',
'E03':'部分完成：flat500与ConfRAG1061已完成；自然关系gold仍缺',
'E04':'部分完成：aligned/full全量完成；精确分组＋集合级单标签原型，非完整多关系图',
'E05':'未完成：人工card gold为0；constructed-oracle20仅agent构造开发诊断',
'E06':'部分完成：full两主数据集全量完成；RAMDocs负结果，CONFLICTS独立适当性评价仍缺',
'E07':'已完成（本轮7B）：精确scope多数票500＋固定tie/minority分层；标签票数与预测分开',
'E08':'未完成：自然人工关系oracle为0，不能填oracle性能',
'E09':'部分完成：MADAM500、官方逻辑适配与BF16偏差披露；预算匹配版未做',
'E10':'部分完成：closed-book500已跑，未运行memory融合yes/no checker',
'E11':'部分完成：构造约束/删除/冲突诊断＋自然适用率；未证明通用E2或细节计数收益',
'E12':'部分完成：1061×4预测/确定性评分/配对统计完成；上下文受限、gold选页、3条件oracleK；人工核读缺',
'E13':'本阶段延期：未做独立自动来源合并消融',
'E14':'已完成（本轮构造诊断）：39例×3含顺序/重复/约束；不是自然全量稳健性证明',
'E15':'本阶段延期：未训练编辑检测器',
'E16':'本阶段延期：无人工gold，未训练relation classifier',
'E17':'本阶段延期：未跑第二backbone，不能宣称跨模型泛化'}
for key,status in exp.items():
    rec('02_实验矩阵',key,10,status)
    rec('05_运行记录',key,9,'状态汇总；下面追加逐run真实记录。'+status)
    rec('05_运行记录',key,10,status)

for key,record,status in [
('G11','各主run/audit.json；raw_trace_consistency.json；phase1_final_integrity.json；code/runtime差异完整披露','已完成（本轮7B审计）'),
('G12','RAMDocs与ConfRAG配对group区间、全分母、common接受集覆盖、固定案例集；自然人评缺项单列','已完成（可计算结论核验）'),
('G13','42项fixture、1000缓存重放、新toy推理失败已保留（full引用多空格导致弃答）、review ZIP；功能release门槛未通过，也未在另一全新安装环境独立重现全实验','部分完成（阶段复现证据）')]:
    rec('03_检查门槛',key,5,record);rec('03_检查门槛',key,6,status)

start=len(before['05_运行记录']['values'])
for i,row in enumerate(ledger['rows']):cells('05_运行记录',start+i,row)
newrows=[['探索性格式诊断','输出上限加倍','output_budget_diagnostic_v1 / seed576','原payload仅max_tokens×2；批时序可不同',str(budget['n_selected'])+'个失败请求；非随机全量','正式结果后，时间见manifest',str(budget['complete_JSON_after_larger_cap'])+'完整JSON／'+str(budget['n_selected'])+'；不代表正确率',f"prompt/output {budget['new_prompt_tokens']}/{budget['new_completion_tokens']}",'runs/output_budget_diagnostic_v1','未覆盖主预测；新请求单独计费','已完成（探索性）'],
['复现smoke','新构造字面事实','phase1-reproduction-smoke-v1 / seed576','同一冻结7B源代码','1个新toy×plain/full=2','见planning/final_runtime_smoke.json','passed='+str(smoke['passed'])+'；answer='+str(smoke['constructed_literal_answer_match']),f"prompt/output {smoke['prompt_tokens']}/{smoke['completion_tokens']}",'runs/phase1-reproduction-smoke-v1','新请求创建时间已核；full引文多空格导致弃答，功能smoke未过；非自然benchmark','已结束（full功能检查失败）']]
for i,row in enumerate(newrows):cells('05_运行记录',start+len(ledger['rows'])+i,row)

retro={
'R03':('合成field-scope对照及自然annotation-match代理已完成；人工card gold仍0。','保留原始span与失败日志；不能把verified当真值。','先真实人审，再决定是否调整字段／验证机制。','部分完成（人工gold仍缺）'),
'R04':('合成full FCR0.1667但召回0.50/insufficient0.35；constructed oracle非自然gold；自然同名专辑误判案例已复核。','FCR下降不能单独算成功；精确分组并未保证下游正确使用。','新dev优先隔离pairwise可比性与策略一致性。','已完成（本轮机制复盘）'),
'R05':('stress17不可解例full误接受1；自然full无accepted E2；非contradiction下E1标记接受RAMDocs17/CONFLICTS5。','当前E1/E2防护不能称全局可靠裁决或形式证明。','后续新dev验证跨类别防护；本轮预测原样保留。','已完成（本轮边界复盘）'),
'R06':('closed-book500正确率1.2%；未跑融合checker。','不能由closed-book基线推断memory融合帮助或覆盖正确上下文。','暂只作诊断，融合实验需单列协议。','部分完成（checker未运行）'),
'R07':(headline,'详见主比较CI、覆盖率和ConfRAG配对差；负结果不删除。','报告每RQ支持范围；不追加同测试调参。','已完成（本轮7B复盘）'),
'R08':(f"开发字段范围/接口修订已保存；事后64上限诊断实际选{budget['n_selected']}条，完整JSON{budget['complete_JSON_after_larger_cap']}条。",'格式恢复不等于方法收益；冻结主结果未覆盖。','下一轮新dev只改一个机制；不把事后诊断叫独立验证。','已完成（本轮修订记录）'),
'R09':('methods_and_deviations.txt逐方法与proposal核对；qualitative_review列5原文案例。','本轮贡献是可复算负结果/证据链/适用边界；不是已成功的完整新算法。','人工gold、72B、完整图和最终报告仍需后续完成。','已完成（阶段声明核对）'),
'R10':('9,618主输出＋开发/压力/预算诊断/新smoke；完整统计、4组图、casebook、review bundle、worksheet读回。','模型跑完与研究成立/课程提交分开；所有缺项保留。','下一轮按qualitative_review优先级推进，未知项见10。','已完成（第一阶段归档）')}
for key,(evidence,criterion,next_action,status) in retro.items():
    for col,value in [(3,evidence),(5,criterion),(6,next_action),(7,status)]:rec('06_复盘迭代',key,col,value)

for key,evidence,status in [
('S03','methods_and_deviations.txt；collection-level原型与proposal差异明确','部分完成（7B原型）'),
('S04','RAMDocs/ConfRAG统计与图完成；人工gold/72B/CONFLICTS适当性缺项','部分完成（第一阶段证据）'),
('S05','casebook.html、qualitative_review.txt、主方法负结果与下一轮顺序','已完成（第一阶段复盘）'),
('S12','reproduce.txt、依赖锁、1000缓存重放与新toy推理；跨机器复现尚未执行','部分完成（阶段复现说明）'),
('S13','phase1 review bundle与SHA；完整原始cache/模型在server；团队GitHub未改','部分完成（阶段归档）'),
('S14','9,618逐题输出、审计、评分、图、失败日志已归档；全原始轨迹仍在server','已完成（本轮预测归档）')]:
    rec('09_提交清单',key,6,evidence);rec('09_提交清单',key,7,status)

unknown=read('planning/unknowns.json')
for r in unknown['items']:
    if r['ID']=='U09':r.update({'问题／已知边界':'ConfRAG4条件计算已完成；gold选页与截断限制明确','下一次核验动作':'后续人审质量；如新版本/全上下文需新协议，不能并入本轮','状态':'本轮计算完成；外推仍受限'})
    if r['ID']=='U05':r['下一次核验动作']='本轮成本已归档并释放自有服务；72B另列后续资源与验证任务。'
    if r['ID']=='D01':r.update({'下一次核验动作':'policy_diagnostics已发现非contradiction下E1标签接受；下一轮新dev补一致性防护。','状态':'主协议保留；原型有缺口'})
new_unknown=['U15','原型与proposal实现缺口','源码审查：精确分组、单一集合标签、提示内解释查找；E1仅contradiction分支拒绝，E2仅结构检查。','本轮定义为7B原型；不宣称完整多关系图或可靠真伪裁决。','按qualitative_review在新dev单因素改进；保留当前负结果。','下一轮设计前','我们；影响研究主张','已确认并披露']
headers=before['10_未知与决策']['values'][0]
unknown['items']=[r for r in unknown['items'] if r['ID']!='U15']+[dict(zip(headers,new_unknown))]
unknown['version']='2026-10-31-phase1-final-America-Phoenix'
for r in unknown['items']:
    old=next((i for i,v in enumerate(before['10_未知与决策']['values']) if v and v[0]==r['ID']),None)
    if old is None:old=len(before['10_未知与决策']['values'])
    cells('10_未知与决策',old,[r.get(h,'') for h in headers])
write_json(ROOT/'planning/unknowns.json',unknown)

materials=[
['M122','阶段报告','第一阶段7B实验与复盘','2026-10-31 America/Phoenix','主结果/失败/局限/下一步','真实结果＋agent核读','', 'analysis/phase1/report.html','不是最终ACL报告；自然人评与72B未做'],
['M123','统计与逐题评分','RAMDocs/ConfRAG配对统计','冻结v3','2000次group bootstrap、全分母','完整主矩阵；CI与定义公开','', 'runs/ramdocs-combined-v3/analysis.json；analysis/confrag_comparison/comparison.json','多比较区间非family-wise保证'],
['M124','错误分析','固定抽样案例与复盘','本轮正式结果后','26题概要复核、5例原文核对','agent描述性分析，不是人工gold','', 'analysis/phase1/casebook.html；qualitative_review.txt','后续同测试改进标exploratory'],
['M125','方法与偏差','原型方法/冻结/运行偏差','v3＋runtime epochs A/B/C','说明实际做了什么与没做什么','源码/轨迹/冻结hash核验','', 'analysis/phase1/methods_and_deviations.txt','准确率低与方法缺口均保留'],
['M126','复现与审计','阶段完整性/重放/新smoke','阶段最终检查','42tests、1000缓存重放、3663检查点hash、新推理','原始PDF/团队快照/6冻结源文件未变','', 'planning/phase1_final_integrity.json；final_runtime_smoke.json','缓存重放与独立新生成分开；无跨机器复现']]
for i,row in enumerate(materials):cells('11_资料索引',len(before['11_资料索引']['values'])+i,row)
write_json(ROOT/'planning/worksheet_final_edits.json',{'edits':edits,'n_cells':len(edits),'note':'Expected-before values must be checked against live cells before write; read back after write.'})
print('Prepared',len(edits),'cell changes')
