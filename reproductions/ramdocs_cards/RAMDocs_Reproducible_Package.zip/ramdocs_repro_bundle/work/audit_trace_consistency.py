"""Verify retained card/decision fields against original cached model JSON, read-only."""
import json
from functools import lru_cache
from pathlib import Path
from real_runtime import ROOT,parse_json,write_json
@lru_cache(maxsize=512)
def raw(key):return parse_json(json.loads((ROOT/'runs/request_cache/v1'/(key+'.json')).read_text())['text'])
def main():
 mismatches=[];cards=0;decisions=0;outputs=0
 for name,dataset in [('ramdocs-main-v3','ramdocs'),('conflicts-main-v3','conflicts'),('confrag-cards-v3','confrag')]:
  directory=ROOT/'runs'/name;inp=ROOT/('materials/prepared/confrag_official_v1/inputs.jsonl' if dataset=='confrag' else f'materials/prepared/v1/{dataset}.inputs.jsonl');inputs={r['question_id']:r for r in map(json.loads,inp.open())}
  for p in sorted(directory.glob('*/*.json')):
   r=json.loads(p.read_text())
   if 'question_id' not in r:continue
   outputs+=1;calls=r.get('requests',[]);docids=[d['doc_id'] if 'doc_id' in d else 'web-'+str(d['index']) for d in inputs[r['question_id']]['documents']]
   for card in r.get('cards',[]):
    cards+=1
    try:
     request=calls[docids.index(card['doc_id'])];original=raw(request['key'])['cards'][int(card['card_id'].rsplit(':c',1)[1])]
     for field in ['answer','claim','quote','entity','sense_version','valid_time']:
      if original.get(field)!=card.get(field):mismatches.append([str(p.relative_to(ROOT)),card['card_id'],field])
    except Exception as e:mismatches.append([str(p.relative_to(ROOT)),card.get('card_id'),'trace_lookup:'+str(e)])
   if r.get('relation') and calls:
    decisions+=1
    try:
     original=raw(calls[-1]['key'])
     for field in ['explanation','decision_basis','competing_candidates','constraint']:
      if original.get(field)!=r.get(field):mismatches.append([str(p.relative_to(ROOT)),'decision',field])
     if original.get('relation')!=r.get('model_proposed_relation',r['relation']):mismatches.append([str(p.relative_to(ROOT)),'decision','relation'])
    except Exception as e:mismatches.append([str(p.relative_to(ROOT)),'decision','trace_lookup:'+str(e)])
 write_json(ROOT/'analysis/phase1/raw_trace_consistency.json',{'outputs_inspected':outputs,'cards_checked':cards,'decisions_checked':decisions,'mismatches':mismatches,'passed':not mismatches,'note':'Checks retained raw fields against referenced cache JSON; does not certify semantic correctness. Guard-modified fields are excluded or compared to recorded proposed labels.'})
 assert not mismatches,mismatches[:5]
 print('Raw trace consistency passed',outputs,cards,decisions)
if __name__=='__main__':main()
