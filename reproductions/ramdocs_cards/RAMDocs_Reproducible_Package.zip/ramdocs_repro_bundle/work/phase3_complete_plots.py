import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'analysis/phase3_complete/figures'
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':220})
e=json.loads((ROOT/'analysis/phase3e/check_v2/summary.json').read_text())['variants'];fig,ax=plt.subplots(figsize=(8.2,5))
for m,color,marker in [('quote_fix','#7f8c8d','s'),('direct_json','#b9770e','^'),('C1','#9467bd','o'),('CG','#17a2a4','o'),('E_blind','#2166ac','D')]:
 x=e[m];xx=100*x['false_answers']/x['unanswerable_n'];yy=100*x['answerable_em']/x['answerable_n'];ax.scatter(xx,yy,s=85,color=color,marker=marker);ax.annotate(m,(xx,yy),xytext=(7,7),textcoords='offset points')
ax.set_xlabel('False-answer rate on 100 unanswerable questions (%) — lower is better');ax.set_ylabel('Exact match on 100 answerable questions (%)');ax.set_title('Independent component confirmation: 200 questions / 29 article clusters');ax.set_xlim(-2,44);ax.set_ylim(0,65);ax.grid(alpha=.2);fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(OUT/f'component_confirmation.{ext}')
plt.close(fig)
d=json.loads((ROOT/'analysis/phase3d/bound_dev_v1/summary.json').read_text())['variants'];ms=list(d);fig,ax=plt.subplots(figsize=(9,4.5));pos=list(range(len(ms)));ax.bar([x-.18 for x in pos],[d[m]['pair_f1'] for m in ms],width=.36,label='Strict source-answer pair F1',color='#2166ac');ax.bar([x+.18 for x in pos],[d[m]['doc_token_f1'] for m in ms],width=.36,label='Per-source token F1',color='#83b5cc');ax.set_xticks(pos,ms);ax.set_ylabel('Score');ax.set_ylim(0,1);ax.set_title('AmbigDocs development: 100 groups / 307 documents');ax.legend();ax.grid(axis='y',alpha=.2);fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(OUT/f'multidoc_development.{ext}')
plt.close(fig)
x=json.loads((ROOT/'analysis/phase3e/check_v2/decision.json').read_text())['contrasts']
fig,axes=plt.subplots(1,2,figsize=(9,3.8))
for ax,key,label,threshold in [(axes[0],'E_blind-quote_fix/em/None','Overall exact-match difference',10),(axes[1],'E_blind-quote_fix/false_answer/True','Unanswerable false-answer difference',5)]:
 r=x[key];lo,hi=[100*v for v in r['cluster_bootstrap95']];point=100*r['delta'];ax.errorbar(point,0,xerr=[[point-lo],[hi-point]],fmt='D',color='#2166ac',capsize=7,markersize=7);ax.axvline(0,color='#777',linewidth=1);ax.axvline(threshold,color='#a33',linestyle='--',linewidth=1);ax.set_yticks([]);ax.set_xlabel('Percentage points: E_blind minus quote_fix');ax.set_title(label,fontsize=11);ax.text(.03,.92,f'{point:+.1f} pp [{lo:+.2f}, {hi:+.2f}]',transform=ax.transAxes);ax.text(.03,.07,'Gain point estimate must be >= +10 pp' if threshold==10 else 'CI upper bound must be <= +5 pp',transform=ax.transAxes,fontsize=9);ax.set_ylim(-1,1);ax.set_xlim(min(-6,lo-3),max(18,hi+3))
fig.suptitle('Independent confirmation: predeclared primary gates not met',fontsize=12);fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(OUT/f'primary_gate_intervals.{ext}')
plt.close(fig)
