import unittest,copy
from phase3d.method import resolve_edges
class GraphTests(unittest.TestCase):
 def setUp(self):
  self.cards=[{'card_id':'d1:c0','doc_id':'d1'},{'card_id':'d2:c0','doc_id':'d2'},{'card_id':'d3:c0','doc_id':'d3'}]
  self.pairs=[{'pair_id':'p0','left':'d1:c0','right':'d2:c0'}]
  self.refs={'d1:s0':{'doc_id':'d1'},'d2:s0':{'doc_id':'d2'},'d3:s0':{'doc_id':'d3'}}
  self.audit={'edges':[{'pair_id':'p0','label':'different_entity','source_refs':['d1:s0','d2:s0'],'reason':'distinct locations'}]}
 def test_distinct_preserved(self):self.assertEqual(resolve_edges(self.cards,self.pairs,self.audit,self.refs)[0],self.cards)
 def test_conflict_blocks_only_involved(self):
  self.audit['edges'][0]['label']='contradiction';self.assertEqual(resolve_edges(self.cards,self.pairs,self.audit,self.refs)[0],[self.cards[2]])
 def test_unclear_not_true_vote(self):
  self.audit['edges'][0]['label']='unclear';self.assertEqual(resolve_edges(self.cards,self.pairs,self.audit,self.refs)[0],[self.cards[2]])
 def test_one_source_not_enough(self):
  self.audit['edges'][0]['source_refs']=['d1:s0']
  with self.assertRaises(ValueError):resolve_edges(self.cards,self.pairs,self.audit,self.refs)
 def test_unknown_ref(self):
  self.audit['edges'][0]['source_refs']=['d1:s0','d9:s0']
  with self.assertRaises(ValueError):resolve_edges(self.cards,self.pairs,self.audit,self.refs)
 def test_missing_pair(self):
  with self.assertRaises(ValueError):resolve_edges(self.cards,self.pairs,{'edges':[]},self.refs)
 def test_duplicate_pair(self):
  self.audit['edges']*=2
  with self.assertRaises(ValueError):resolve_edges(self.cards,self.pairs,self.audit,self.refs)
 def test_invalid_label(self):
  self.audit['edges'][0]['label']='majority_winner'
  with self.assertRaises(ValueError):resolve_edges(self.cards,self.pairs,self.audit,self.refs)
 def test_no_mutation(self):
  original=copy.deepcopy((self.cards,self.pairs,self.audit));resolve_edges(self.cards,self.pairs,self.audit,self.refs);self.assertEqual(original,(self.cards,self.pairs,self.audit))
