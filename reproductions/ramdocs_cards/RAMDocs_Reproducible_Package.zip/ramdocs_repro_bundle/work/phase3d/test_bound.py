import unittest
from unittest.mock import patch
from phase3d.bound import FilteredBound
from phase3e.method_v2 import BoundQuestion
class T(unittest.TestCase):
 def test_unbound_source_cards_not_accepted(self):
  raw={'cards':[{'card_id':'d:c0','support_status':'verified'},{'card_id':'d:c1','support_status':'verified'}],'binding_checks':[{'card_id':'d:c0','verification':{'status':'uncertain'}},{'card_id':'d:c1','verification':{'status':'verified'}}]}
  with patch.object(BoundQuestion,'run',return_value=raw):out=FilteredBound(None,None).run({})
  self.assertEqual(out['cards'][0]['support_status'],'uncertain_question_binding');self.assertEqual(out['cards'][1]['support_status'],'verified');self.assertEqual(raw['cards'][0]['support_status'],'verified')
if __name__=='__main__':unittest.main()
