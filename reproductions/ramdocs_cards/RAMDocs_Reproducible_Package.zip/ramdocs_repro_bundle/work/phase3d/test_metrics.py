import unittest
from scope_metrics import score,predicted_pairs
class MetricTests(unittest.TestCase):
 def setUp(self):self.ref={'pairs':[{'doc_id':'d1','answer':'Amber'},{'doc_id':'d2','answer':'Cobalt'}]}
 def out(self,pairs):return {'status':'answered','attributed_answers':[{'doc_id':d,'answer':a} for d,a in pairs]}
 def test_exact(self):self.assertEqual(score(self.out([('d1','Amber'),('d2','Cobalt')]),self.ref)['complete'],1)
 def test_swapped_not_correct(self):self.assertEqual(score(self.out([('d2','Amber'),('d1','Cobalt')]),self.ref)['pair_f1'],0)
 def test_partial(self):self.assertAlmostEqual(score(self.out([('d1','Amber')]),self.ref)['pair_f1'],2/3)
 def test_extra_penalized(self):self.assertAlmostEqual(score(self.out([('d1','Amber'),('d2','Cobalt'),('d2','Red')]),self.ref)['pair_f1'],.8)
 def test_error_zero(self):self.assertEqual(score({'status':'error'},self.ref)['complete'],0)
 def test_rejected_citation_excluded(self):
  x={'status':'answered','accepted_answers':['Amber'],'citations':[{'doc_id':'d1','answer':'Amber'},{'doc_id':'d2','answer':'Cobalt'}]};self.assertEqual(predicted_pairs(x),{('d1','amber')})
