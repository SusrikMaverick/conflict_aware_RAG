"""Frozen question binding transferred per source; graph remains disabled."""
import copy
from phase3d.method import DocumentGraph
from phase3e.method_v2 import BoundQuestion
class FilteredBound(BoundQuestion):
 def run(self,row,method=None):
  out=super().run(row,method);out=copy.deepcopy(out)
  allowed={b['card_id'] for b in out['binding_checks'] if b['verification']['status']=='verified'}
  for c in out['cards']:
   if c['support_status']=='verified' and c['card_id'] not in allowed:c['support_status']='uncertain_question_binding'
  return out
class BoundDocuments(DocumentGraph):
 def __init__(self,client,verifier):
  super().__init__(client,verifier,True,False);self.extractor=FilteredBound(client,verifier,'blind')
