import unittest
from confrag_metrics import ns,score
class OfficialScorer(unittest.TestCase):
 def test_partition(self):
  self.assertEqual(ns['bad_partition']([[0,1],[2]],[[0,1],[2]]),'Normal');self.assertEqual(ns['bad_partition']([[0],[2]],[[0,1],[2]]),'Missing Elements');self.assertEqual(ns['bad_partition']([[0,1],[1,2]],[[0,1],[2]]),'Duplicate Elements')
 def test_nmi(self):self.assertAlmostEqual(ns['compute_soft_nmi']([[0,1],[2]],[[2],[0,1]]),1)
 def test_single_cluster_official_behavior(self):self.assertEqual(ns['compute_soft_nmi']([[0,1]],[[0,1]]),0)
 def test_keyword_maximum_matching(self):self.assertEqual(ns['compare_answer'](['alpha beta','alpha'],[['alpha'],['beta']])[0],2)
 def test_empty_predictions(self):
  ref={'selected_gold_partition':[[0,1],[2]],'data':{'answers':[{'answer_judge_keyword':['alpha'],'reason':[{'reason_judge_keyword':['a']}]}]}}
  out=score({'answers':[]},ref);self.assertEqual(out['NMI'],0);self.assertEqual(out['answerScore'],0)
 def test_official_empty_gold_reason_zero_division(self):
  ref={'selected_gold_partition':[[0]],'data':{'answers':[{'answer_judge_keyword':['alpha'],'reason':[]}]}}
  with self.assertRaises(ZeroDivisionError):score({'answers':[{'answer':'alpha','index':[0],'reason':['a']}]},ref)
if __name__=='__main__':unittest.main()
