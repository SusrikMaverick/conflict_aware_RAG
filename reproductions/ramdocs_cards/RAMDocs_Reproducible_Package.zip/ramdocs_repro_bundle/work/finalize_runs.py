"""Finalize only complete runs; preserve partial/aborted runs outside main comparison."""
import hashlib,json,subprocess,time
from pathlib import Path
from real_runtime import ROOT,write_json
runs=['ramdocs-baselines-v1','ramdocs-madam-v1','ramdocs-main-v3','conflicts-main-v3','confrag-bounded-v1','confrag-cards-v3']
while True:
 states={}
 for r in runs:
  p=ROOT/'runs'/r/'progress.json';states[r]=json.loads(p.read_text()) if p.exists() else {}
 if all(x.get('finished') for x in states.values()):break
 time.sleep(30)
def command(args,log):
 with (ROOT/log).open('w') as f:subprocess.run([str(ROOT/'.venv/bin/python'),*args],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
command(['work/recover_confrag_traces.py','runs/confrag-bounded-v1'],'logs/confrag-trace-recovery.log')
for r in runs:
 command(['work/audit_run.py','runs/'+r],'logs/'+r+'-audit.log')
 audit=json.loads((ROOT/'runs'/r/'audit.json').read_text())
 if not audit['all_outputs_accounted'] or audit['missing_cache'] or audit['bad_citations']:raise RuntimeError('Run incomplete or integrity failure:'+r)
combined=ROOT/'runs/ramdocs-combined-v3';combined.mkdir(parents=True,exist_ok=True);sources={'memory':'ramdocs-baselines-v1','plain':'ramdocs-baselines-v1','madam':'ramdocs-madam-v1',**{m:'ramdocs-main-v3' for m in ['raw','flat','aligned','full','majority']}}
base=json.loads((ROOT/'runs/ramdocs-main-v3/manifest.json').read_text());manifest={'input':base['input'],'selected_ids':base['selected_ids'],'methods':list(sources),'kind':'read-only combined evaluation index; no new generation','source_runs':sources,'source_manifest_sha256':{r:hashlib.sha256((ROOT/'runs'/r/'manifest.json').read_bytes()).hexdigest() for r in set(sources.values())}}
write_json(combined/'manifest.json',manifest)
for method,r in sources.items():
 target=ROOT/'runs'/r/method;dest=combined/method
 if not dest.exists():dest.symlink_to(target,target_is_directory=True)
write_json(combined/'progress.json',{'completed':len(base['selected_ids'])*len(sources),'total':len(base['selected_ids'])*len(sources),'finished':True,'note':'evaluation index only; does not duplicate inference'})
command(['work/audit_run.py',str(combined)],'logs/ramdocs-combined-v3-audit.log')
command(['work/analyze_benchmark.py',str(combined)],'logs/ramdocs-combined-v3-analysis.log')
command(['work/analyze_benchmark.py','runs/conflicts-main-v3','--dataset','conflicts'],'logs/conflicts-main-v3-analysis.log')
for r in ['confrag-bounded-v1','confrag-cards-v3']:command(['work/analyze_confrag.py','runs/'+r],'logs/'+r+'-analysis.log')
command(['work/make_phase_report.py'],'logs/phase_report.log')
write_json(ROOT/'planning/automatic_finalization_finished.json',{'finished':True,'epoch':time.time(),'runs':runs,'remaining_agent_checks':['review summary/paired statistics and error analysis','verify source snapshot/environment integrity','update worksheet and read back','release owned model server after all analysis','deliver honest report with remaining human/72B/independent-judge gaps']})
print('AUTOMATIC ANALYSIS FINISHED',flush=True)
