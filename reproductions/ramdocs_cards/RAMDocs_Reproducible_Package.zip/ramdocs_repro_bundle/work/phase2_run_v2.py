"""Frozen phase2 input-only runner; evaluator annotations never loaded."""
import argparse,json,time,hashlib,traceback
from concurrent.futures import ThreadPoolExecutor,as_completed
from real_runtime import ROOT,Client,write_json
from pipeline import Verifier
from phase2.pipeline import Phase2Pipeline
ap=argparse.ArgumentParser();ap.add_argument('--split',choices=['dev','check'],required=True);a=ap.parse_args()
protocol=json.loads((ROOT/'planning/protocols/phase2_v2.json').read_text())
for p,h in protocol['hashes'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
rows=[json.loads(l) for l in (ROOT/f'materials/prepared/phase2_v2/{a.split}.inputs.jsonl').read_text().splitlines()]
run=ROOT/f'runs/phase2-v2-{a.split}';run.mkdir(parents=True,exist_ok=True)
assert not list(run.glob('*/*.json')), 'Do not overwrite/retry completed outputs'
write_json(run/'manifest.json',{'protocol':protocol,'split':a.split,'started_epoch':time.time(),'workers':4})
c=Client();c.cache=ROOT/'runs/request_cache/phase2_v2';c.cache.mkdir(parents=True,exist_ok=True)
v=Verifier();v.cache=ROOT/'runs/verifier_cache/phase2_v2';v.cache.mkdir(parents=True,exist_ok=True)
pipes={m:Phase2Pipeline(c,v,m) for m in protocol['variants']}
def one(row,m):
 p=pipes[m];start=time.time()
 try:out=p.run(row)
 except Exception as e:out={'question_id':row['question_id'],'method':m,'status':'error','error':str(e),'traceback':traceback.format_exc(),'requests':getattr(p.local,'trace',[]),'quote_repairs':getattr(p.local,'repairs',[]),'scope_audit':getattr(p.local,'scope_audit',{})}
 out['wall_seconds']=time.time()-start;write_json(run/m/(row['question_id']+'.json'),out);return out
start=time.time();errors=0
with ThreadPoolExecutor(max_workers=4) as pool:
 fs=[pool.submit(one,r,m) for r in rows for m in pipes]
 for n,f in enumerate(as_completed(fs),1):
  out=f.result();errors+=out['status']=='error';progress={'completed':n,'total':len(fs),'errors':errors,'elapsed_seconds':time.time()-start,'finished':n==len(fs)};write_json(run/'progress.json',progress)
  if n%9==0 or out['status']=='error':print(json.dumps(progress|{'last':out['question_id'],'variant':out['method'],'error':out.get('error')}),flush=True)
