import json,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
names=['ramdocs-main-v3','ramdocs-madam-v1','conflicts-main-v3','confrag-bounded-v1','confrag-cards-v3','output_budget_diagnostic_v1']
out={'utc':time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime()),'runs':{}}
for name in names:
 p=root/'runs'/name/'progress.json'
 if p.exists():
  try:
   x=json.loads(p.read_text());out['runs'][name]={k:x[k] for k in ('completed','total','errors','finished') if k in x}
  except json.JSONDecodeError:out['runs'][name]={'status':'atomic write pending'}
 else:out['runs'][name]={'status':'queued'}
for name in ['main_sequence_v3.log','main_sequence_runtime_resume.log','finalize_runs.log','finish_extra_analysis.log']:
 p=root/'logs'/name
 if p.exists() and 'Traceback' in p.read_text():out[name]=p.read_text()[-1500:]
print(json.dumps(out))
