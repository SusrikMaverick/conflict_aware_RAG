"""Complete decision contract; no optional scientific trace fields silently disappear."""
LABELS=['agreement','different_entity','different_sense_version','temporal_update','complementary','opinion','contradiction','insufficient_information']
S={'type':'string'}
STRINGS={'type':'array','items':S}
CITE={'type':'object','properties':{'answer':S,'doc_id':S,'quote':S},'required':['answer','doc_id','quote'],'additionalProperties':False}
PREMISE={'type':'object','properties':{'doc_id':S,'quote':S},'required':['doc_id','quote'],'additionalProperties':False}
CONSTRAINT={'type':'object','properties':{'premises':{'type':'array','items':PREMISE},'rule':S,'eliminated':STRINGS},'required':['premises','rule','eliminated'],'additionalProperties':False}
DECISION_SCHEMA={'type':'object','properties':{'relation':{'type':'string','enum':LABELS},'status':{'type':'string','enum':['answered','partial','abstain']},'accepted_answers':STRINGS,'competing_candidates':STRINGS,'citations':{'type':'array','items':CITE},'decision_basis':S,'constraint':CONSTRAINT,'explanation':S},'required':['relation','status','accepted_answers','competing_candidates','citations','decision_basis','constraint','explanation'],'additionalProperties':False}
