import json,hashlib,collections,time
from pathlib import Path
from real_runtime import ROOT,write_json
spec=[('A','runs/phase3-grounding-dev-v1',300,0),('B_interface_pilot','runs/phase3b-dev-v1',70,0),('B','runs/phase3b-dev-v2',700,0),('C','runs/phase3c-dev-v1',700,0),('D','runs/phase3d-dev-v1',500,0),('E_v1_dev','runs/phase3e-dev-v1',700,400),('E_v2_dev','runs/phase3e-dev-v2',700,400),('E_confirmation','runs/phase3e-check-v2',1400,0),('D_bound_dev','runs/phase3d-bound-dev-v1',600,500),('F_transfer','runs/phase3f-transfer-v3',4038,0)]
rows=[];hashes={};contents={};allunique=set()
for label,folder,expected,reused in spec:
 files=list((ROOT/folder).glob('*/*/*.json' if label=='F_transfer' else '*/*.json'));assert len(files)==expected,(folder,len(files),expected)
 statuses=collections.Counter();qids=set();unique=0
 for p in files:
  b=p.read_bytes();h=hashlib.sha256(b).hexdigest();x=json.loads(b);assert 'question_id' in x
  statuses[x['status']]+=1;qids.add(x['question_id']);hashes[str(p.relative_to(ROOT))]=h
  if h not in allunique:unique+=1
  allunique.add(h)
 rows.append({'label':label,'run':folder,'output_records':len(files),'planned_output_records':expected,'question_ids':len(qids),'reused_records':reused,'new_records_expected':expected-reused,'new_unique_content_hashes':unique,'status_counts':dict(statuses),'interpretation':'Outputs/variants are not independent question observations or physical model calls.'})
assert sum(x['output_records'] for x in rows)==9708
assert sum(x['new_records_expected'] for x in rows)==8408
write_json(ROOT/'planning/phase3_complete/run_inventory.json',{'epoch':time.time(),'runs':rows,'output_records_total_including_copies':9708,'new_output_records_total':8408,'new_this_continuation_excluding_A':8108,'unique_content_hashes':len(allunique),'known_smoke_separate':'runs/phase3-final-smoke/results.json','human_gold':0,'test_multidoc200_run':False})
write_json(ROOT/'planning/phase3_complete/all_output_hashes.json',hashes)
print('Inventoried',len(hashes),'records;',len(allunique),'unique contents')
