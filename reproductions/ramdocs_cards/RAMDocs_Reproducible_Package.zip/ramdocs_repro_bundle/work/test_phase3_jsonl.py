import json,tempfile,unittest
from pathlib import Path
class JSONLPhysicalLines(unittest.TestCase):
 def test_unicode_paragraph_separator_is_not_record_boundary(self):
  original={'text':'first\u2028second\u2029third','question_id':'q'}
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'in.jsonl';p.write_text(json.dumps(original,ensure_ascii=False)+'\n')
   self.assertGreater(len(p.read_text().splitlines()),1)
   with p.open() as f:self.assertEqual(list(map(json.loads,f)),[original])
if __name__=='__main__':unittest.main()
