"""Explicit oracle-subset adapter. All gold selection happens before inference."""
import ast,json,random,hashlib,collections
from pathlib import Path
from real_runtime import ROOT,write_json
p=ROOT/'materials/runtime_sources/confrag_generateIndex.py';tree=ast.parse(p.read_text())
ns={'random':random,'MAX_WEBSITES':5};body=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))];exec(compile(ast.Module(body=body,type_ignores=[]),str(p),'exec'),ns)
inputs=[];evaluation=[];excluded=[]
rows=[json.loads(l) for l in (ROOT/'materials/datasets/confrag/ConfRAGsuggested.jsonl').open() if l.strip()]
for idx,row in enumerate(rows):
 qid=f'confrag-official-{idx:04d}';random.seed(576+idx)
 try:
  indices,groups=ns['generateIndex'](row)
  webs={w['index']:w for w in row['websites'] if 'index' in w}
  documents=[{'index':i,'text':webs[i]['content']} for i in sorted(indices)]
  inputs.append({'question_id':qid,'question':row['question'],'documents':documents,'oracle_cluster_count':len(groups)})
  evaluation.append({'question_id':qid,'selected_gold_partition':groups,'data':{'id':qid,'answers':row['answers']}})
 except Exception as e:excluded.append({'question_id':qid,'reason':type(e).__name__+':'+str(e)})
out=ROOT/'materials/prepared/confrag_official_v1';out.mkdir(parents=True,exist_ok=True)
for name,data in [('inputs',inputs),('evaluation',evaluation),('excluded',excluded)]:
 (out/(name+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in data))
write_json(out/'manifest.json',{'raw_n':len(rows),'eligible_n':len(inputs),'excluded_n':len(excluded),'exclusions':dict(collections.Counter(x['reason'] for x in excluded)),'oracle_information':'gold-driven subset selection plus supplied K in known-K setting; unknown-K shares oracle-selected subset','selection_seed':'576+original row index','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scores':'official recommended release keywords; original full gold answers retained as official scorer does'})
print((out/'manifest.json').read_text())
