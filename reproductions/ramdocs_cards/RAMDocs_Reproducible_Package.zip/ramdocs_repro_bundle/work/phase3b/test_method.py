import unittest,copy
from phase3b.method import select,DIMS
class SelectionTests(unittest.TestCase):
 def setUp(self):
  self.doc='Navo opened in 1984. It did not open in 1983.'
  self.cards=[{'card_id':'d1:c0','answer':'1984'}]
  self.audit={'audits':[{'card_id':'d1:c0','supported':True,'conditions':[{'dimension':d,'verdict':'satisfied' if d in ['referent','requested_attribute'] else 'not_applicable','quote':'Navo opened in 1984.' if d in ['referent','requested_attribute'] else '', 'reason':''} for d in DIMS]}]}
 def test_single_source_accepted(self):self.assertEqual(select(self.audit,self.cards,self.doc,True),self.cards)
 def test_contradicted_condition_overrides_supported(self):
  self.audit['audits'][0]['conditions'][2].update(verdict='contradicted',quote='It did not open in 1983.')
  self.assertFalse(select(self.audit,self.cards,self.doc,True))
 def test_missing_requirement_blocks(self):
  self.audit['audits'][0]['conditions'][3]['verdict']='not_established'
  self.assertFalse(select(self.audit,self.cards,self.doc,True))
 def test_referent_cannot_be_na(self):
  self.audit['audits'][0]['conditions'][0]['verdict']='not_applicable'
  self.assertFalse(select(self.audit,self.cards,self.doc,True))
 def test_no_fuzzy_quote(self):
  self.audit['audits'][0]['conditions'][0]['quote']='Navo opened in 1983.'
  with self.assertRaises(ValueError):select(self.audit,self.cards,self.doc,True)
 def test_missing_candidate(self):
  with self.assertRaises(ValueError):select({'audits':[]},self.cards,self.doc,True)
 def test_duplicate_candidate(self):
  self.audit['audits']*=2
  with self.assertRaises(ValueError):select(self.audit,self.cards,self.doc,True)
 def test_missing_dimension(self):
  self.audit['audits'][0]['conditions'].pop()
  with self.assertRaises(ValueError):select(self.audit,self.cards,self.doc,True)
 def test_empty_candidates(self):self.assertEqual(select({'audits':[]},[],self.doc,True),[])
 def test_no_mutation(self):
  before=copy.deepcopy((self.audit,self.cards));select(self.audit,self.cards,self.doc,True);self.assertEqual(before,(self.audit,self.cards))
 def test_generic_needs_exact_quote(self):
  with self.assertRaises(ValueError):select({'audits':[{'card_id':'d1:c0','supported':True,'quote':'fabricated'}]},self.cards,self.doc,False)
