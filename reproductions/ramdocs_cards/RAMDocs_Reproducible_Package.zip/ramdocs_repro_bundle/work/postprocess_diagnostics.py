"""Frozen bounded interval diagnostic and annotation-proxy extraction audit.
No changes to primary generation or primary result files.
"""
import collections,json,hashlib,random
from pathlib import Path
from real_runtime import ROOT,write_json
from interval_diagnostic import interval_decision
from metrics import normalize,score
inputs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/v1/ramdocs.inputs.jsonl').open())};refs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/v1/ramdocs.evaluation.jsonl').open())}
rows=[];counters=collections.defaultdict(collections.Counter);intervals=[]
for p in sorted((ROOT/'runs/ramdocs-main-v3/full').glob('*.json')):
 r=json.loads(p.read_text());qid=r['question_id'];bydoc=collections.defaultdict(list)
 for c in r.get('cards',[]):bydoc[c['doc_id']].append(c)
 for ann in refs[qid]['document_annotations']:
  cs=bydoc[ann['doc_id']];counts=counters[ann['type']];counts['documents']+=1;counts['with_card']+=bool(cs);counts['with_verified_card']+=any(c['support_status']=='verified' for c in cs)
  counts['exact_annotation_answer_extracted']+=any(normalize(c['answer'])==normalize(ann['answer']) for c in cs)
  counts['exact_annotation_answer_verified']+=any(normalize(c['answer'])==normalize(ann['answer']) and c['support_status']=='verified' for c in cs)
 d=interval_decision(inputs[qid],r.get('cards',[]))
 if d:intervals.append({'question_id':qid,'diagnostic':d,'base_answers':r.get('accepted_answers',[])})
write_json(ROOT/'analysis/extraction_annotation_proxy.json',{'by_annotated_type':{k:dict(v) for k,v in counters.items()},'limits':['Document annotations are dataset metadata, not human fact-card gold','Exact answer strings are a proxy; aliases/units can mismatch','Verified misinformation cards can be textually entailed by their source; this is not verification of truth']})
write_json(ROOT/'analysis/interval_natural_applicability.json',{'n_questions':len(inputs),'applicable_cases':len(intervals),'cases':intervals,'status':'separate bounded diagnostic; primary full outputs unchanged'})
# Blind review packet: preserve system output and references separately, no invented review scores.
conf_inputs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/v1/conflicts.inputs.jsonl').open())};packet=[];unblinding=[]
for method in ('plain','raw','full'):
 for p in sorted((ROOT/'runs/conflicts-main-v3'/method).glob('*.json')):
  r=json.loads(p.read_text());review_id=hashlib.sha256((p.stem+'|'+method).encode()).hexdigest()[:16];unblinding.append({'review_id':review_id,'question_id':p.stem,'method':method});packet.append({'review_id':review_id,'question_id':p.stem,'question':conf_inputs[p.stem]['question'],'response':{k:r[k] for k in ['status','raw_output','accepted_answers','competing_candidates','explanation','citations','relation','constraint'] if k in r},'human_reviewed':False,'appropriateness_score':None,'reviewer':None})
random.Random(576).shuffle(packet)
(ROOT/'annotations/conflicts_response_review_key.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in unblinding))
p=ROOT/'annotations/conflicts_response_review_packet.jsonl';p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in packet));print('Prepared',len(packet),'unreviewed CONFLICTS responses')
from audit_trace_consistency import main as audit_trace_consistency
audit_trace_consistency()
