"""Download pinned, public model artifacts into a project-local directory."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import urllib.request


def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--revision',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    with urllib.request.urlopen(f'https://huggingface.co/api/models/{a.repo}/revision/{a.revision}?blobs=true',timeout=60) as f:meta=json.load(f)
    if meta['sha']!=a.revision:raise ValueError('Revision mismatch')
    a.out.mkdir(parents=True,exist_ok=True)
    has_safetensors=any(x['rfilename'].endswith('.safetensors') for x in meta['siblings'])
    selected=[x for x in meta['siblings'] if '/' not in x['rfilename'] and (x['rfilename'].endswith(('.safetensors','.json','.txt','.model')) or (not has_safetensors and x['rfilename'].endswith('.bin')) or x['rfilename']=='README.md')]
    def fetch(x):
        name=x['rfilename'];dest=a.out/name;expected=(x.get('lfs') or {}).get('sha256')
        if not dest.exists():
            temp=a.out/(name+'.part')
            with urllib.request.urlopen(f'https://huggingface.co/{a.repo}/resolve/{a.revision}/{name}',timeout=120) as f,temp.open('wb') as out:
                while chunk:=f.read(8*1024*1024):out.write(chunk)
            temp.rename(dest)
        h=hashlib.sha256()
        with dest.open('rb') as f:
            while chunk:=f.read(8*1024*1024):h.update(chunk)
        if expected and h.hexdigest()!=expected:raise ValueError('Checksum mismatch:'+name)
        result={'name':name,'bytes':dest.stat().st_size,'sha256':h.hexdigest(),'upstream_lfs_sha256':expected}
        print(json.dumps(result),flush=True);return result
    with ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(fetch,selected))
    (a.out/'download_manifest.json').write_text(json.dumps({'repo':a.repo,'revision':a.revision,'files':files},indent=2)+'\n')

if __name__=='__main__':main()
