"""Dev interface repair, then frozen benchmarks. No prompt/threshold retuning."""
import hashlib,json,subprocess,time
from pathlib import Path
from real_runtime import ROOT,write_json
sources=['work/pipeline.py','work/decision_schema.py','work/real_runtime.py','work/run_experiment.py','work/madam_adapter.py','work/metrics.py']
expected={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in sources}
def command(args,log):
 with (ROOT/log).open('w') as f:subprocess.run([str(ROOT/'.venv/bin/python'),*args],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
def audit(run,dev=False):
 command(['work/audit_run.py',run],'logs/'+Path(run).name+'-audit.log');a=json.loads((ROOT/run/'audit.json').read_text())
 if not a['all_outputs_accounted'] or a['missing_cache'] or a['bad_citations']:raise RuntimeError('Integrity gate failure')
 if dev and a['statuses'].get('error',0):raise RuntimeError('Dev interface errors must be repaired before launch')
 for s,h in expected.items():
  if hashlib.sha256((ROOT/s).read_bytes()).hexdigest()!=h:raise RuntimeError('Frozen code changed:'+s)
command(['work/run_experiment.py','--input','materials/prepared/v1/synthetic_pilot_dev.inputs.jsonl','--limit','20','--methods','plain,raw,flat,aligned,full,majority,madam,memory','--workers','4','--run','runs/real-pilot20-v3'],'logs/real-pilot20-v3.log')
audit('runs/real-pilot20-v3',True);command(['work/analyze_pilot.py','runs/real-pilot20-v3'],'logs/pilot_v3_analysis.log')
command(['work/run_experiment.py','--input','materials/prepared/stress_dev_v1/inputs.jsonl','--methods','raw,full,majority','--workers','4','--run','runs/stress39-v3'],'logs/stress39-v3.log')
audit('runs/stress39-v3',True);command(['work/analyze_stress.py','runs/stress39-v3'],'logs/stress39-v3-analysis.log')
write_json(ROOT/'planning/protocols/main_freeze_v3.json',{'code_hashes':expected,'frozen_epoch':time.time(),'basis':'20dev and39stress interface audit pass; method settings unchanged except explicit{} parser repair','timing_disclosure':'brief main-v2 run had started before repair; no main predictions reviewed to choose repair; old run aborted and retained','model':'Qwen2.5-7B-bf16','threshold':0.5,'field_scope':'document','no_benchmark_prompt_tuning':True})
for dataset,methods,run in [('ramdocs','raw,flat,aligned,full,majority','ramdocs-main-v3'),('conflicts','plain,raw,full','conflicts-main-v3')]:
 command(['work/run_experiment.py','--input',f'materials/prepared/v1/{dataset}.inputs.jsonl','--methods',methods,'--workers','8','--run','runs/'+run],'logs/'+run+'.log');audit('runs/'+run)
write_json(ROOT/'planning/main_sequence_finished.json',{'finished':True,'version':'v3','epoch':time.time(),'code_hashes':expected});print('MAIN V3 FINISHED',flush=True)
