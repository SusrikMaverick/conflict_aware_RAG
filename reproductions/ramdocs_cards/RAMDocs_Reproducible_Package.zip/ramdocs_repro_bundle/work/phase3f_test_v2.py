import unittest
from phase3f_v2 import Transfer
class Stub:
 def run(self,row,m):
  return {'requests':[],'cards':[{'card_id':'d:c0','support_status':'verified'},{'card_id':'d:c1','support_status':'uncertain'}],'binding_checks':[{'card_id':'d:c0','verification':{'status':'uncertain_overflow'}}]}
class TestTransfer(unittest.TestCase):
 def test_question_rejection_cannot_enter_verified_group(self):
  pipe=Transfer(None,None,True);pipe.source=Stub();cards,_=pipe.extract({'question_id':'q','question':'q','documents':[{'doc_id':'d','text':'x'}]},[])
  self.assertEqual(cards[0]['support_status'],'uncertain_question_binding');self.assertEqual(cards[0]['source_support_status'],'verified');self.assertEqual(cards[1]['support_status'],'uncertain')
 def test_control_preserves_source_status(self):
  pipe=Transfer(None,None,False);pipe.source=Stub();cards,_=pipe.extract({'question_id':'q','question':'q','documents':[{'doc_id':'d','text':'x'}]},[])
  self.assertEqual(cards[0]['support_status'],'verified');self.assertNotIn('question_binding',cards[0])
 def test_empty_source_no_model_call(self):
  pipe=Transfer(None,None,True);pipe.source=None
  cards,issues=pipe.extract({'question_id':'q','question':'q','documents':[{'doc_id':'d','text':'  '}]},[])
  self.assertEqual(cards,[]);self.assertTrue(issues[0]['model_request_skipped'])
if __name__=='__main__':unittest.main()
