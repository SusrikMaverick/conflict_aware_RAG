import argparse,collections,json
from pathlib import Path
from real_runtime import ROOT,write_json
from pipeline import LABELS

def main():
 ap=argparse.ArgumentParser();ap.add_argument('run',type=Path);a=ap.parse_args()
 refs={x['sample_id']:x for x in map(json.loads,(ROOT/'annotations/pilot30_agent_references.jsonl').read_text().splitlines())};design={x['id']:x for x in json.loads((ROOT/'planning/design_review/counterexamples_v1_1.json').read_text())};summary={};details=[]
 for directory in sorted(a.run.iterdir()):
  if not directory.is_dir():continue
  results=[json.loads(p.read_text()) for p in sorted(directory.glob('*.json'))];cm=collections.Counter();states=collections.Counter();issues=collections.Counter();cards=collections.Counter();tokens=collections.Counter();requestkeys=set();errors=[]
  for r in results:
   qid=r['question_id'];ref=refs.get(qid)
   if not ref:continue
   expected=ref['agent_reference_relation'];pred=r.get('relation');states[r['status']]+=1
   if directory.name in ('raw','flat','aligned','full'):cm[(expected,pred or '__error__')]+=1
   if r['status']=='error':errors.append({'id':qid,'error':r['error']})
   issues.update(r.get('enforcement_reasons',[]));cards.update(c['support_status'] for c in r.get('cards',[]));cards['discarded_span']+=sum(i.get('error')=='quote_not_exact' for i in r.get('extraction_issues',[]))
   for call in r.get('requests',[]):
    requestkeys.add(call['key']);tokens.update({k:v for k,v in call['usage'].items() if k in ('prompt_tokens','completion_tokens','total_tokens')})
   case=design[ref['parent_question_id'].replace('design-','')]
   details.append({'method':directory.name,'id':qid,'expected_relation':expected,'predicted_relation':pred,'relation_correct':pred==expected,'status':r['status'],'answers':r.get('accepted_answers'),'construction_expected':case['expected'],'enforcement':r.get('enforcement_reasons',[])})
  per={}
  for label in LABELS:
   tp=cm[(label,label)];fn=sum(v for (t,p),v in cm.items() if t==label and p!=label);fp=sum(v for (t,p),v in cm.items() if p==label and t!=label)
   per[label]={'n':tp+fn,'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0}
  contra_n=sum(v for (t,p),v in cm.items() if t=='contradiction');noncontra_n=sum(v for (t,p),v in cm.items() if t!='contradiction')
  summary[directory.name]={'contradiction_recall':cm[('contradiction','contradiction')]/contra_n if contra_n else None,'false_contradiction_rate':sum(v for (t,p),v in cm.items() if p=='contradiction' and t!='contradiction')/noncontra_n if noncontra_n else None,'insufficient_rate':sum(v for (t,p),v in cm.items() if p=='insufficient_information')/sum(cm.values()) if cm else None,'n':len(results),'status_counts':dict(states),'relation_accuracy':sum(v for (t,p),v in cm.items() if t==p)/sum(cm.values()) if cm else None,'fixed8_macro_f1':sum(v['f1'] for v in per.values())/8 if cm else None,'per_class':per,'enforcement_reasons':dict(issues),'cards':dict(cards),'request_count_including_shared':sum(len(r.get('requests',[])) for r in results),'unique_request_count':len(requestkeys),'tokens_including_shared':dict(tokens),'errors':errors}
 out={'scope':'20 constructed synthetic dev cases; correlated variants, NOT human gold or natural benchmark generalization','run':str(a.run),'methods':summary}
 write_json(a.run/'analysis.json',out);write_json(a.run/'case_review.json',details);print(json.dumps(out,indent=2))
if __name__=='__main__':main()
