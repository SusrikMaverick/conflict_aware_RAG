import unittest,copy
from phase3.context import envelope,unique_span,ContextPipeline
from real_runtime import parse_json
from pipeline import EXTRACT,TAXONOMY

def card(q,entity='Ria',answer='LIME'):
 return {'quote':q,'entity':entity,'sense_version':None,'valid_time':None,'answer':answer,'claim':f'{entity} uses {answer}.','field_evidence':{'entity':entity,'answer':answer}}
class EnvelopeTests(unittest.TestCase):
 def test_subject_recovered(self):
  x=envelope('Ria uses LIME.',card('uses LIME'));self.assertEqual(x['quote'],'Ria uses LIME.');self.assertEqual(x['span_start'],0)
 def test_same_full_sentence_unchanged(self):self.assertEqual(envelope('Ria uses LIME.',card('Ria uses LIME.'))['status'],'unchanged')
 def test_internal_typo_rejected(self):self.assertEqual(envelope('Ria uses LIME.',card('uses L1ME'))['status'],'skipped')
 def test_repeated_anchor(self):self.assertIsNone(unique_span('LIME LIME','LIME'))
 def test_overlapping_anchor(self):self.assertIsNone(unique_span('aaa','aa'))
 def test_repeated_field(self):self.assertEqual(envelope('Ria came. Ria uses LIME.',card('uses LIME'))['reason'],'field_not_unique_exact')
 def test_two_sentences(self):self.assertEqual(envelope('Ria arrived. Her code is LIME.',card('code is LIME'))['sentence_count'],2)
 def test_cross_paragraph_rejected(self):self.assertEqual(envelope('Ria arrived.\n\nThe code is LIME.',card('code is LIME'))['reason'],'cross_paragraph')
 def test_sentence_cap(self):self.assertEqual(envelope('Ria arrived. Next. Later. Code LIME.',card('Code LIME'))['reason'],'sentence_cap')
 def test_character_cap(self):self.assertEqual(envelope('Ria '+'x'*1700+' LIME.',card('LIME'))['reason'],'character_cap')
 def test_missing_answer_evidence(self):
  c=card('LIME');c['field_evidence'].pop('answer');self.assertEqual(envelope('Ria LIME.',c)['reason'],'field_not_unique_exact')
 def test_nonnull_missing_field(self):
  c=card('LIME');c['valid_time']='2024';self.assertEqual(envelope('Ria LIME 2024.',c)['reason'],'field_not_unique_exact')
 def test_negation_not_removed(self):self.assertEqual(envelope('Ria does not use LIME.',card('use LIME'))['quote'],'Ria does not use LIME.')
 def test_no_claim_mutation(self):
  c=card('uses LIME');before=copy.deepcopy(c);envelope('Ria uses LIME.',c);self.assertEqual(c,before)
 def test_offsets_are_source(self):
  text='Other. Ria uses LIME. Last.';r=envelope(text,card('uses LIME'));self.assertEqual(text[r['span_start']:r['span_end']],r['quote'])
 def test_null_optional_fields(self):self.assertEqual(envelope('Ria uses LIME.',card('LIME'))['status'],'expanded')
class FakeClient:
 def __init__(self):self.prompts=[]
 def chat(self,prompt,*args):
  self.prompts.append(prompt)
  import json
  payload={'cards':[card('uses LIME')]} if prompt.startswith(EXTRACT) else {'relation':'agreement','status':'answered','accepted_answers':['LIME'],'citations':[{'answer':'LIME','doc_id':'d1','quote':'Ria uses LIME.'}]}
  return {'key':str(len(self.prompts)),'text':json.dumps(payload),'usage':{},'latency_seconds':0,'cache_hit':False,'attempts':1,'finish_reason':'stop'}
class FakeVerifier:
 def __init__(self):self.seen=[]
 def check(self,q,c):self.seen.append((q,c));return {'status':'verified','probability':1}
class IntegrationTests(unittest.TestCase):
 def test_expansion_reaches_verifier_without_extra_calls(self):
  c=FakeClient();v=FakeVerifier();p=ContextPipeline(c,v);o=p.run({'question_id':'unit','question':'Code?','documents':[{'doc_id':'d1','text':'Ria uses LIME.'}]})
  self.assertEqual(len(c.prompts),2);self.assertEqual(v.seen,[('Ria uses LIME.','Ria uses LIME.')]);self.assertEqual(o['accepted_answers'],['LIME']);self.assertEqual(o['coverage_ledger'][0]['verified'],1)
 def test_duplicate_docs_record_source_ids(self):
  c=FakeClient();v=FakeVerifier();p=ContextPipeline(c,v);o=p.run({'question_id':'unit','question':'Code?','documents':[{'doc_id':d,'text':'Ria uses LIME.'} for d in ['d1','d2']]})
  self.assertEqual([r['doc_id'] for r in o['context_records']],['d1','d2'])
if __name__=='__main__':unittest.main()
