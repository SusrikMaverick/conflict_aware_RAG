"""Exact source-context assembly without semantic text repair or new model calls."""
import copy,re,collections
from phase2.pipeline import Phase2Pipeline

def unique_span(text,fragment):
    if not isinstance(fragment,str) or not fragment:return None
    start=text.find(fragment)
    if start<0 or text.find(fragment,start+1)>=0:return None
    return start,start+len(fragment)

def envelope(text,card,max_chars=1600,max_sentences=3):
    q=card.get('quote');anchor=unique_span(text,q)
    if anchor is None:return {'status':'skipped','reason':'quote_not_unique_exact'}
    fields=card.get('field_evidence')
    if not isinstance(fields,dict):return {'status':'skipped','reason':'missing_fields'}
    intervals=[anchor]
    for field in ('entity','sense_version','valid_time','answer'):
        if field!='answer' and card.get(field) is None:continue
        pos=unique_span(text,fields.get(field))
        if pos is None:return {'status':'skipped','reason':'field_not_unique_exact','field':field}
        intervals.append(pos)
    lo=min(a for a,b in intervals);hi=max(b for a,b in intervals)
    spans=[];start=0
    for m in re.finditer(r'(?<=[.!?])\s+|\n+',text):
        if m.start()>start:spans.append((start,m.start()))
        start=m.end()
    if start<len(text):spans.append((start,len(text)))
    chosen=[i for i,(a,b) in enumerate(spans) if b>lo and a<hi]
    if not chosen:return {'status':'skipped','reason':'no_sentence_span'}
    left,right=spans[chosen[0]][0],spans[chosen[-1]][1]
    quote=text[left:right]
    if re.search(r'\n\s*\n',quote):return {'status':'skipped','reason':'cross_paragraph'}
    if len(quote)>max_chars:return {'status':'skipped','reason':'character_cap'}
    if len(chosen)>max_sentences:return {'status':'skipped','reason':'sentence_cap'}
    assert left<=lo and right>=hi and q in quote
    return {'status':'expanded' if quote!=q else 'unchanged','raw_quote':q,'quote':quote,'span_start':left,'span_end':right,'original_span_start':anchor[0],'original_span_end':anchor[1],'sentence_count':len(chosen),'rule':'unique-exact-field-envelope-in-one-paragraph'}

class ContextPipeline(Phase2Pipeline):
    def __init__(self,client,verifier):super().__init__(client,verifier,'quote_fix')
    def call(self,prompt,trace,max_tokens=768,json_mode=True,penalty=1.0):
        source=getattr(self.local,'source_map',{}).get(prompt)
        out=super().call(prompt,trace,max_tokens,json_mode,penalty)
        if source is not None and isinstance(out,dict) and isinstance(out.get('cards'),list):
            out=copy.deepcopy(out)
            for i,card in enumerate(out['cards']):
                if not isinstance(card,dict):continue
                result=envelope(source['text'],card)
                self.local.context_records.append({'doc_id':source['doc_id'],'card_index':i,'request_key':trace[-1]['key'],**result})
                if result['status']=='expanded':card['quote']=result['quote']
        return out
    def extract(self,row,trace):
        cards=[];issues=[]
        # One source at a time avoids attribution ambiguity for duplicate-text documents.
        for doc in row['documents']:
            c,e=super().extract(dict(row,documents=[doc]),trace);cards.extend(c);issues.extend(e)
        self.local.cards=cards
        return cards,issues
    def run(self,row,method='full'):
        self.local.context_records=[]
        out=super().run(row)
        out['method']='context_envelope';out['context_records']=self.local.context_records
        out['coverage_ledger']=[{'doc_id':d['doc_id'],'cards':sum(c['doc_id']==d['doc_id'] for c in out['cards']),'verified':sum(c['doc_id']==d['doc_id'] and c['support_status']=='verified' for c in out['cards']),'issues':[i['error'] for i in out['extraction_issues'] if i.get('doc_id',i.get('card',{}).get('doc_id'))==d['doc_id']]} for d in row['documents']]
        return out
