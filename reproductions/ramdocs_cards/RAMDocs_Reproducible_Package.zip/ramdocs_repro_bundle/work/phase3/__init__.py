"""Independent phase3 prototypes; previous scientific sources stay frozen."""
