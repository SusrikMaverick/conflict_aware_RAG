"""Versioned real experiments. Never imports evaluation files during generation."""
import argparse,hashlib,json,sys,time,traceback
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from real_runtime import Client,ROOT,digest,write_json
from pipeline import Pipeline,Verifier

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True,type=Path);ap.add_argument('--run',required=True,type=Path);ap.add_argument('--methods',required=True);ap.add_argument('--limit',type=int);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args()
    rows=[json.loads(l) for l in a.input.open() if l.strip()];rows=rows[:a.limit] if a.limit else rows
    methods=a.methods.split(',');a.run.mkdir(parents=True,exist_ok=True)
    source={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'work/real_runtime.py',ROOT/'work/pipeline.py',ROOT/'work/madam_adapter.py',ROOT/'work/decision_schema.py',Path(__file__)]}
    contract={'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'input':str(a.input),'selected_ids':[r['question_id'] for r in rows],'methods':methods,'source':source,'model_revision':'a09a35458c702b33eeacc393d103063234e8bc28','seed':576,'dtype':'bfloat16','model_size':'7B','human_gold':False,'workers':a.workers}
    manifest=a.run/'manifest.json'
    if manifest.exists() and json.loads(manifest.read_text())!=contract:raise ValueError('Immutable run manifest mismatch; use new run name')
    write_json(manifest,contract)
    client=Client();verifier=Verifier() if any(m not in ('plain','raw','memory','madam') for m in methods) else None;pipe=Pipeline(client,verifier)
    tasks=[(r,m) for r in rows for m in methods];started=time.time();completed=0;failures=0
    def one(row,method):
        p=a.run/method/(row['question_id']+'.json')
        if p.exists():return json.loads(p.read_text())
        start=time.time()
        try:result=pipe.run(row,method)
        except Exception as e:result={'question_id':row['question_id'],'method':method,'status':'error','error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'requests':getattr(pipe.local,'trace',[])}
        result['wall_seconds']=time.time()-start;write_json(p,result);return result
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        fs=[pool.submit(one,r,m) for r,m in tasks]
        for f in as_completed(fs):
            out=f.result();completed+=1;failures+=out['status']=='error'
            if completed%10==0 or out['status']=='error':print(json.dumps({'completed':completed,'total':len(tasks),'errors':failures,'last_id':out['question_id'],'method':out['method'],'status':out['status'],'elapsed':time.time()-started}),flush=True)
            write_json(a.run/'progress.json',{'completed':completed,'total':len(tasks),'errors':failures,'elapsed_seconds':time.time()-started,'finished':completed==len(tasks)})
    print('FINISHED',completed,'errors',failures,flush=True)
if __name__=='__main__':main()
