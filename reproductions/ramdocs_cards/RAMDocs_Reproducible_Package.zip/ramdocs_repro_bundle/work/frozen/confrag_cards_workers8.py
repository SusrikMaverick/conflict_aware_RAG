"""ConfRAG representation contrast on identical gold-selected, bounded input pages.
Flat versus aligned cards share extraction and MiniCheck; no gold answers reach inference.
"""
import argparse,collections,hashlib,json,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from real_runtime import ROOT,Client,parse_json,write_json
from pipeline import Pipeline,Verifier,norm
ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);a=ap.parse_args();a.run.mkdir(parents=True,exist_ok=True)
rows=list(map(json.loads,(ROOT/'materials/prepared/confrag_official_v1/inputs.jsonl').open()));c=Client();pipe=Pipeline(c,Verifier(),'document')
contract={'ids':[r['question_id'] for r in rows],'methods':['flat_K','aligned_K'],'model':'Qwen2.5-7B-bf16','verifier_threshold':0.5,'document_token_cap':4000,'oracle_K':True,'source':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'work/pipeline.py',ROOT/'work/real_runtime.py']},'max_output_tokens':1536,'workers':8,'input_sha256':hashlib.sha256((ROOT/'materials/prepared/confrag_official_v1/inputs.jsonl').read_bytes()).hexdigest()}
if (a.run/'manifest.json').exists():assert json.loads((a.run/'manifest.json').read_text())==contract
write_json(a.run/'manifest.json',contract)
base=(ROOT/'materials/datasets/confrag/generateResult/TestPrompt.txt').read_text()
def one(row):
 qid=row['question_id'];paths={m:a.run/m/(qid+'.json') for m in contract['methods']}
 if all(p.exists() for p in paths.values()):return [json.loads(p.read_text()) for p in paths.values()]
 trace=[];context=[];result=[];inputs={'question_id':qid,'question':row['question'],'documents':[]}
 for d in row['documents']:
  with c.lock:tokens=c.tokenizer.encode(d['text'],add_special_tokens=False);text=c.tokenizer.decode(tokens[:4000],skip_special_tokens=False) if len(tokens)>4000 else d['text']
  inputs['documents'].append({'doc_id':'web-'+str(d['index']),'text':text});context.append({'index':d['index'],'original_tokens':len(tokens),'retained_tokens':min(len(tokens),4000),'truncated':len(tokens)>4000})
 try:cards,issues=pipe.extract(inputs,trace)
 except Exception as e:
  for m,p in paths.items():
   r={'question_id':qid,'method':m,'status':'error','error':'extraction:'+type(e).__name__+':'+str(e),'requests':trace,'context_audit':context};write_json(p,r);result.append(r)
  return result
 groups=collections.defaultdict(list)
 for card in cards:
  if card['support_status']=='verified':groups[(norm(card.get('entity') or '?'),norm(card.get('sense_version') or '?'),norm(card.get('valid_time') or '?'))].append(card)
 mapping=[{'scope_key':list(k),'cards':v} for k,v in groups.items()]
 for m,p in paths.items():
  if p.exists():result.append(json.loads(p.read_text()));continue
  localtrace=list(trace);r={'question_id':qid,'method':m,'cards':cards,'extraction_issues':issues,'context_audit':context,'requests':localtrace}
  representation={'all_webpage_indices':[d['index'] for d in row['documents']]}
  if m=='flat_K':representation['cards']=cards
  else:representation.update(evidence_map=mapping,uncertain_cards=[x for x in cards if x['support_status']!='verified'])
  text=base.replace('[CLUSTERING NUMBER]',str(row['oracle_cluster_count']))+'\nThe webpage contents below are represented by fact cards. A doc_id web-N denotes webpage index N. A verified card is textually supported, not certified true. Uncertain cards cannot settle truth. Counts do not imply independent sources. Include all original webpage indexes, even when no useful card was extracted.\nQuestion: '+row['question']+'\nEvidence: '+json.dumps(representation,ensure_ascii=False)
  try:
   raw=c.chat(text,1536,True);localtrace.append({k:raw[k] for k in ('key','usage','latency_seconds','finish_reason')});pred=parse_json(raw['text']);assert isinstance(pred.get('answers'),list)
   for g in pred['answers']:assert isinstance(g['index'],list) and isinstance(g['answer'],str) and isinstance(g['reason'],list)
   r.update(status='ok' if raw['finish_reason']!='length' else 'output_limit',prediction=pred)
  except Exception as e:r.update(status='error',error=type(e).__name__+':'+str(e))
  write_json(p,r);result.append(r)
 return result
n=0;errors=0;start=time.time()
with ThreadPoolExecutor(8) as pool:
 for f in as_completed([pool.submit(one,r) for r in rows]):
  rs=f.result();n+=len(rs);errors+=sum(r['status']!='ok' for r in rs)
  if n%20==0:print(n,len(rows)*2,'errors',errors,'elapsed',time.time()-start,flush=True)
  write_json(a.run/'progress.json',{'completed':n,'total':len(rows)*2,'errors':errors,'finished':n==len(rows)*2,'elapsed':time.time()-start})
print('CONFRAG CARD COMPARISON FINISHED',flush=True)
