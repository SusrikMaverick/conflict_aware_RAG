"""Load only official prompt functions via AST, replacing the inference call.
No upstream imports/model setup execute. Convergence preserves official behavior.
"""
import ast
from real_runtime import ROOT

def run_madam(pipe,row):
    source=ROOT/'materials/audit_2026-10-31/official_madam_rag.py'
    tree=ast.parse(source.read_text());keep={'normalize_answer','agent_response','aggregate_responses','multi_agent_debate'}
    functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in keep]
    import re,string
    trace=[]
    def call(prompt,generator,max_new_tokens=128):return pipe.call(prompt,trace,128,False,1.05)
    ns={'re':re,'string':string,'List':list,'call_llm':call}
    exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),ns)
    result=ns['multi_agent_debate'](row['question'],[d['text'] for d in row['documents']],None,3)
    from real_runtime import plain_parse
    text=result['final_aggregation']
    try:a=plain_parse(text);status='answered' if a else 'abstain'
    except (ValueError,SyntaxError):a=[];status='parse_error'
    return {'question_id':row['question_id'],'method':'madam','status':status,'accepted_answers':a,'raw_output':text,'rounds':result,'requests':trace,'adaptation':'official prompts and previous-round convergence; 7B bf16/vLLM instead of original NF4 transformers'}
