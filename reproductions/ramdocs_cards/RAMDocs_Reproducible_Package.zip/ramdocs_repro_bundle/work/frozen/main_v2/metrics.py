"""RAMDocs official-compatible substring metric and strict parsed-set metric."""
import json,re,string
PUNCT=set(string.punctuation+'‘’“”–—')
def normalize(s):return ' '.join(re.sub(r'\b(a|an|the)\b',' ',''.join(c for c in s.lower() if c not in PUNCT)).split())
def words(s):return re.compile(rf'(?<!\S){re.escape(s)}(?!\S)')
def official(output,gold,wrong):
    listed=re.search(r'All Correct Answers:(.*?)(?:Explanation:|$)',output,re.S|re.I)
    text=normalize(listed.group(1) if listed else output);g={normalize(x) for x in gold}
    if not all(words(x).search(text) for x in g):return False
    for x in g:text=words(x).sub('|',text)
    return not any(words(x).search(text) for x in {normalize(x) for x in wrong}-g)
def score(result,gold,wrong):
    accepted=result.get('accepted_answers',[]);p={normalize(x) for x in accepted};g={normalize(x) for x in gold};w={normalize(x) for x in wrong}-g
    ok=result.get('status') not in ('error','parse_error');text=result.get('raw_output','All Correct Answers: '+json.dumps(accepted)+'. Explanation: {}')
    exact=p==g if ok else False;tp=len(p&g);precision=tp/len(p) if p else 0;recall=tp/len(g) if g else 0
    remaining=' '.join(sorted(p))
    for answer in g:remaining=words(answer).sub('|',remaining)
    wrong_mentioned=any(words(answer).search(remaining) for answer in w)
    return {'official_compatible':int(official(text,gold,wrong)) if result.get('status')!='error' else 0,'strict_set_exact':int(exact),'precision':precision,'recall':recall,'f1':2*precision*recall/(precision+recall) if precision+recall else 0,'wrong_only_accepted':int(wrong_mentioned),'wrong_only_exact_accepted':int(bool(p&w)),'answered':int(result.get('status')=='answered'),'any_accepted':int(bool(p)),'partial':int(result.get('status')=='partial'),'parse_error':int(result.get('status')=='parse_error'),'infra_error':int(result.get('status')=='error' and result.get('error_kind','infrastructure')=='infrastructure'),'model_output_error':int(result.get('status')=='error' and result.get('error_kind')=='model_output'),'context_overflow':int(result.get('status')=='error' and result.get('error_kind')=='context_overflow')}
