import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'analysis/figures';out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140,'savefig.bbox':'tight'})
path=ROOT/'runs/ramdocs-combined-v3/analysis.json'
if path.exists():
 data=json.loads(path.read_text())['methods'];order=[m for m in ['memory','plain','madam','raw','majority','flat','aligned','full'] if m in data];labels={'memory':'Closed-book','plain':'Plain RAG','madam':'MADAM','raw':'Raw policy','majority':'Exact-scope vote','flat':'Flat cards','aligned':'Aligned cards','full':'Full LLM policy'}
 fig,axes=plt.subplots(1,3,figsize=(14,4.6),sharey=True)
 for ax,metric,title in zip(axes,['official_compatible','wrong_only_accepted','answered'],['Paper-compatible accuracy','Parsed wrong-only acceptance','Declared complete-answer coverage']):
  bars=ax.barh(range(len(order)),[100*data[m][metric] for m in order],color=['#316c88' if m!='full' else '#ba5b31' for m in order]);ax.set_yticks(range(len(order)),[labels[m] for m in order]);ax.set_xlim(0,100);ax.set_title(title);ax.set_xlabel('% of all 500 questions');ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
  for bar in bars:ax.text(bar.get_width()+1,bar.get_y()+bar.get_height()/2,f'{bar.get_width():.1f}',va='center',fontsize=9)
 axes[0].invert_yaxis();fig.suptitle('RAMDocs: fixed Qwen2.5-7B BF16; failures remain in denominator',y=1.02)
 for suffix in ['png','pdf']:fig.savefig(out/('ramdocs_overview.'+suffix))
 plt.close(fig)
 for coverage,risk,filename,xlabel in [('answered','selective_risk','ramdocs_risk_coverage','Declared complete-answer coverage (%)'),('any_accepted','selective_risk_any_accepted','ramdocs_any_answer_risk','Nonempty accepted-answer sets (%)')]:
  fig,ax=plt.subplots(figsize=(7,5))
  for m in order:
   d=data[m]
   if d[risk] is None:continue
   x=100*d[coverage];y=100*d[risk];ax.scatter(x,y,s=55,label=labels[m],edgecolors='white',linewidths=.5)
  ax.set(xlim=(0,100),ylim=(0,100),xlabel=xlabel,ylabel='Incorrect among the selected answers (%)',title='Observed operating points; no interpolated risk curve');ax.grid(alpha=.2);ax.legend(loc='upper left',bbox_to_anchor=(1.02,1),frameon=False)
  for suffix in ['png','pdf']:fig.savefig(out/(filename+'.'+suffix))
  plt.close(fig)
p=ROOT/'analysis/confrag_comparison/comparison.json'
if p.exists():
 data=json.loads(p.read_text())['methods'];order=['unknown_K','oracle_K','flat_K','aligned_K'];labels=['Raw, unknown K','Raw, oracle K','Flat, oracle K','Aligned, oracle K'];fig,ax=plt.subplots(figsize=(8,4.8));bars=ax.bar(labels,[data[m]['mean']['NMI'] for m in order],color=['#91a4af','#316c88','#709b88','#ba5b31']);ax.set(ylim=(0,1),ylabel='Mean soft NMI (all eligible n=1061)',title='ConfRAG: identical gold-selected pages, first4000 tokens/page');ax.tick_params(axis='x',rotation=12)
 for b in bars:ax.text(b.get_x()+b.get_width()/2,b.get_height()+.015,f'{b.get_height():.3f}',ha='center')
 ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
 for suffix in ['png','pdf']:fig.savefig(out/('confrag_representation.'+suffix))
 plt.close(fig)
print(out)
