"""Stdlib-only backends. Mock is explicitly non-scientific plumbing output."""
import json
import os
import time
import urllib.error
import urllib.request


class MockBackend:
    def chat(self,messages,config):
        return {'text':json.dumps({'status':'abstain','accepted_answers':[],'reason':'mock plumbing fixture; not model inference'}),
                'usage':None,'latency_seconds':0.0,'backend':'mock','is_model_inference':False}


class OpenAICompatibleBackend:
    def chat(self,messages,config):
        base=config['base_url'].rstrip('/')
        if not base.startswith(('http://127.0.0.1:','http://localhost:','https://')):
            raise ValueError('Use localhost or an explicit HTTPS endpoint')
        payload={'model':config['model'],'messages':messages,'temperature':config.get('temperature',0),
                 'max_tokens':config['max_output_tokens'],'stream':False}
        headers={'Content-Type':'application/json'}
        if config.get('api_key_env'):
            key=os.environ.get(config['api_key_env'])
            if not key:raise ValueError('Configured API credential is unavailable')
            headers['Authorization']='Bearer '+key
        req=urllib.request.Request(base+'/chat/completions',data=json.dumps(payload).encode(),headers=headers,method='POST')
        start=time.monotonic()
        try:
            with urllib.request.urlopen(req,timeout=config.get('timeout_seconds',60)) as response:out=json.load(response)
        except urllib.error.HTTPError as exc:
            # Do not persist headers, credentials or arbitrary remote error bodies.
            raise RuntimeError(f'backend_http_status_{exc.code}') from None
        choice=out['choices'][0]
        return {'text':choice['message']['content'],'usage':out.get('usage'),'latency_seconds':time.monotonic()-start,
                'finish_reason':choice.get('finish_reason'),'backend':'openai_compatible','is_model_inference':True,'model':out.get('model')}


def create_backend(config):
    if config['backend']=='mock':return MockBackend()
    if config['backend']=='openai_compatible':return OpenAICompatibleBackend()
    raise ValueError('Unknown backend')
