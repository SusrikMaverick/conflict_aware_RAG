import argparse,collections,csv,json,random,statistics
from pathlib import Path
from real_runtime import ROOT,write_json
from metrics import score

def interval(values):
 s=sorted(values);return [s[int(.025*len(s))],s[min(len(s)-1,int(.975*len(s)))]]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('run',type=Path);ap.add_argument('--dataset',default='ramdocs');a=ap.parse_args()
 refs={r['question_id']:r for r in map(json.loads,(ROOT/f'materials/prepared/v1/{a.dataset}.evaluation.jsonl').open())}
 summary={};allmetrics={};rows=[]
 for d in sorted(a.run.iterdir()):
  if not d.is_dir():continue
  results=[json.loads(p.read_text()) for p in sorted(d.glob('*.json'))];metrics={};tokens=collections.Counter();cards=collections.Counter();usagekeys=set()
  for r in results:
   if r['question_id'] not in refs:continue
   ref=refs[r['question_id']]
   if a.dataset=='ramdocs':m=score(r,ref['gold_answers'],ref['wrong_answers'])
   else:
    m={'infra_error':int(r['status']=='error' and r.get('error_kind')=='infrastructure'),'model_output_error':int(r['status']=='error' and r.get('error_kind')=='model_output'),'context_overflow':int(r.get('error_kind')=='context_overflow'),'any_error':int(r['status']=='error'),'parse_error':int(r['status']=='parse_error'),'answered':int(r['status']=='answered'),'any_accepted':int(bool(r.get('accepted_answers')))}
   metrics[r['question_id']]=m;rows.append({'method':d.name,'question_id':r['question_id'],**m})
   cards.update(c['support_status'] for c in r.get('cards',[]))
   for x in r.get('requests',[]):
    usagekeys.add(x['key']);tokens.update({k:v for k,v in x['usage'].items() if k in ('prompt_tokens','completion_tokens','total_tokens')})
  if not metrics:continue
  agg={k:sum(m[k] for m in metrics.values())/len(metrics) for k in next(iter(metrics.values()))}
  agg.update(n=len(metrics),status_counts=dict(collections.Counter(r['status'] for r in results)),unique_requests=len(usagekeys),tokens_including_cached_shared=dict(tokens),cards=dict(cards))
  if a.dataset=='ramdocs':
   answered=[m for m in metrics.values() if m['answered']];agg['selective_risk']=sum(1-m['official_compatible'] for m in answered)/len(answered) if answered else None
   accepted=[m for m in metrics.values() if m['any_accepted']];agg['selective_risk_any_accepted']=sum(1-m['official_compatible'] for m in accepted)/len(accepted) if accepted else None
   strata={}
   for label,selector in [('with_fake',lambda ref:any(x['type']=='misinfo' for x in ref['document_annotations'])),('without_fake',lambda ref:not any(x['type']=='misinfo' for x in ref['document_annotations'])),('single_gold',lambda ref:len(set(ref['gold_answers']))==1),('multiple_gold',lambda ref:len(set(ref['gold_answers']))>1)]:
    part=[m for q,m in metrics.items() if selector(refs[q])];strata[label]={'n':len(part),**{k:sum(m[k] for m in part)/len(part) if part else None for k in next(iter(metrics.values()))}}
   agg['strata']=strata
   fixed_strata=json.loads((ROOT/'analysis/data_audit/data_audit.json').read_text())['strata_question_ids']
   for label in ['single_tie_candidates','single_candidate_1_vs_1','single_fake_ahead_candidates','any_positive_gold_not_ahead','missing_gold_support']:
    selected=set(fixed_strata.get(label,[]));part=[m for q,m in metrics.items() if q in selected]
    agg['strata']['annotation_'+label]={'n':len(part),**{k:sum(m[k] for m in part)/len(part) if part else None for k in next(iter(metrics.values()))}}
  else:
   strata={}
   for label in sorted({refs[q]['conflict_type'] for q in metrics}):
    part=[m for q,m in metrics.items() if refs[q]['conflict_type']==label]
    strata[label]={'n':len(part),**{k:sum(m[k] for m in part)/len(part) for k in next(iter(metrics.values()))}}
   agg['descriptive_category_strata']=strata
   agg['predicted_relation_counts']=dict(collections.Counter(r.get('relation','not_emitted') for r in results))
   agg['interpretation']='Descriptive behavior only. Original conflict categories are not equivalent to our8-class taxonomy; no appropriateness or relation accuracy is inferred.'
  summary[d.name]=agg;allmetrics[d.name]=metrics
 # Paired grouped bootstrap. Keys from frozen grouping manifest; absent keys explicitly question-wise.
 manifest=json.loads((ROOT/'materials/prepared/v1/split_manifest.json').read_text());groupof={}
 def visit(v):
  if isinstance(v,dict):
   if 'question_id' in v and 'group_id' in v:groupof[v['question_id']]=v['group_id']
   for x in v.values():visit(x)
  elif isinstance(v,list):
   for x in v:visit(x)
 visit(manifest);paired={}
 if a.dataset=='ramdocs':
  for x,y in [('full','plain'),('full','raw'),('full','majority'),('aligned','flat')]:
   if x not in allmetrics or y not in allmetrics:continue
   ids=sorted(set(allmetrics[x])&set(allmetrics[y]));groups=collections.defaultdict(list)
   for q in ids:groups[groupof.get(q,q)].append(q)
   keys=sorted(groups);rng=random.Random(576);draws=[]
   for _ in range(2000):
    selected=[q for g in rng.choices(keys,k=len(keys)) for q in groups[g]];draws.append(sum(allmetrics[x][q]['official_compatible']-allmetrics[y][q]['official_compatible'] for q in selected)/len(selected))
   paired[x+'-minus-'+y]={'n_questions':len(ids),'n_groups':len(keys),'group_manifest_matches':sum(q in groupof for q in ids),'metric':'official_compatible','delta':sum(allmetrics[x][q]['official_compatible']-allmetrics[y][q]['official_compatible'] for q in ids)/len(ids),'95pct_paired_group_bootstrap':interval(draws),'replicates':2000,'seed':576}
 out={'dataset':a.dataset,'run':str(a.run),'methods':summary,'paired':paired,'limitations':['7B BF16 mechanism study, not72B replication','strict answer sets use exact normalization, no newly inferred aliases','infra and parse errors retained in denominator','no human labels or IAA claimed']};write_json(a.run/'analysis.json',out)
 with (a.run/'per_question_metrics.csv').open('w') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else []);writer.writeheader();writer.writerows(rows)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
