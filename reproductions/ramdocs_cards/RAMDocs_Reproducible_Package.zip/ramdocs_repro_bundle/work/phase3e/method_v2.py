"""Versioned binding-interface repair; same hypotheses and NLI decision rule."""
import json
from phase3e.method import BoundQuestion as V1,BIND
FORMAT='''Return ONLY a complete JSON object with this exact structure: {"bindings":[{"card_id":"supplied ID","can_form":true,"hypothesis":"standalone declarative hypothesis including the candidate verbatim","reason":"brief explanation of how the candidate fills the question"}]}. Every item MUST include all four fields, including reason even when can_form=true. Do not omit candidates, output an empty list, stop after hypothesis, or repeat whitespace. If unable to form one, still include that card_id with can_form=false, hypothesis="", and a reason.'''
class BoundQuestion(V1):
 def call(self,prompt,trace,max_tokens=768,json_mode=True,penalty=1.0):
  if prompt.startswith(BIND):
   body=json.loads(prompt.split('\nInput: ',1)[1]);n=len(body['candidates'])
   prompt=prompt.replace('\nInput: ',f'\n{FORMAT}\nProduce exactly {n} bindings, each candidate ID once.\nInput: ',1)
  return super().call(prompt,trace,max_tokens,json_mode,penalty)
