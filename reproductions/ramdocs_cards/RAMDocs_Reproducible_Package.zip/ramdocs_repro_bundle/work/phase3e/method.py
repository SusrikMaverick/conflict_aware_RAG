"""Bind the candidate to the question before exposing evidence to the verifier."""
import json
from pipeline import Pipeline,norm
from phase3b.method import obj,STR,BOOL
from phase3c.method import SourceCards

BIND='''Turn each QUESTION + CANDIDATE ANSWER into a single standalone declarative hypothesis whose truth would mean that this candidate answers this exact question. Do not decide whether it is true. Preserve the question's referent, requested relation, time direction, negation, numbers and quantifiers. Do not weaken or silently fix a false premise. Do not add requirements absent from the question. Include the candidate answer verbatim in the hypothesis. Do not answer a different question or simply assert that the candidate exists. Use only the question and candidate for the hypothesis; do not substitute a nearby fact. If the candidate is incomplete or cannot meaningfully fill the question, can_form=false and explain. Return one binding for every supplied card_id, no new candidates.'''

class BoundQuestion(Pipeline):
 def __init__(self,client,verifier,mode='blind'):super().__init__(client,verifier);self.base=SourceCards(client,verifier,True);self.mode=mode
 def run(self,row,method=None):
  self.local.trace=[]
  try:old=self.base.run(row,'C1')
  except Exception:
   self.local.trace=getattr(self.base.local,'trace',[]);raise
  trace=old['requests'];self.local.trace=trace;cards=[c for c in old['cards'] if c['support_status']=='verified'];chosen=[];checks=[];raw={'bindings':[]}
  if cards:
   visible={'question':row['question'],'candidates':[{'card_id':c['card_id'],'answer':c['answer']} for c in cards]}
   if self.mode=='seen':visible['document']=row['documents'][0]['text']
   item=obj({'card_id':{'type':'string','enum':[c['card_id'] for c in cards]},'can_form':BOOL,'hypothesis':STR,'reason':STR})
   schema=obj({'bindings':{'type':'array','minItems':len(cards),'maxItems':len(cards),'items':item}})
   raw=self.call(BIND+'\nInput: '+json.dumps(visible,ensure_ascii=False),trace,1024,schema)
   lookup={c['card_id']:c for c in cards};seen=set()
   for b in raw['bindings']:
    key=b['card_id']
    if key not in lookup or key in seen:raise ValueError('binding_card_coverage')
    seen.add(key);c=lookup[key]
    valid=b['can_form'] and b['hypothesis'].strip() and norm(c['answer']) in norm(b['hypothesis'])
    if valid:
     context=c['quote'] if self.mode=='quote' else row['documents'][0]['text']
     verified=self.v.check(context,b['hypothesis'])
    else:verified={'status':'invalid_binding','probability':None}
    checks.append(b|{'verification':verified,'context':'selected_quote' if self.mode=='quote' else 'whole_document'})
    if verified['status']=='verified':chosen.append(c)
   if seen!=set(lookup):raise ValueError('binding_missing_card')
  answers=list(dict.fromkeys(c['answer'] for c in chosen))
  return old|{'method':method,'status':'answered' if answers else 'abstain','accepted_answers':answers,'citations':[{'answer':c['answer'],'doc_id':c['doc_id'],'quote':c['quote']} for c in chosen],'binding_checks':checks,'binding_request_source_blind':self.mode!='seen','binding_raw':raw,'requests':trace,'decision_basis':'question_bound_hypothesis_'+self.mode}
