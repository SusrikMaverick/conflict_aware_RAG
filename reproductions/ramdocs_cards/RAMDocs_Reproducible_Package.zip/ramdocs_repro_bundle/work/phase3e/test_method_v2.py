import json,unittest
from phase3e.method_v2 import BoundQuestion
from phase3e.method import BIND
class FakeClient:
 def __init__(self,claim='Navo opened before 1984.',can=True):self.prompts=[];self.claim=claim;self.can=can
 def chat(self,prompt,*args):
  self.prompts.append(prompt)
  raw={'bindings':[{'card_id':'d1:c0','can_form':self.can,'hypothesis':self.claim,'reason':''}]} if prompt.startswith(BIND) else {'cards':[{'answer':'Navo','entity':'Navo','scope':'opening','claim':'Navo opened after 1984.','source_ids':['s0']}]}
  return {'key':str(len(self.prompts)),'usage':{'total_tokens':1},'latency_seconds':0,'cache_hit':False,'attempts':1,'finish_reason':'stop','text':json.dumps(raw)}
class FakeVerifier:
 def __init__(self):self.calls=[]
 def check(self,quote,claim):
  self.calls.append((quote,claim));return {'status':'uncertain' if 'before' in claim else 'verified','probability':.1 if 'before' in claim else .9}
class BindingTests(unittest.TestCase):
 def setUp(self):self.row={'question_id':'x','question':'What opened before 1984?','documents':[{'doc_id':'d1','text':'Navo opened after 1984. SecretMarker.'}]}
 def test_question_polarity_mismatch_rejected(self):
  out=BoundQuestion(FakeClient(),FakeVerifier()).run(self.row);self.assertEqual(out['accepted_answers'],[])
 def test_blind_request_has_no_source(self):
  c=FakeClient();BoundQuestion(c,FakeVerifier()).run(self.row);self.assertNotIn('SecretMarker',c.prompts[-1]);self.assertIn('What opened before 1984?',c.prompts[-1])
 def test_seen_control_has_source(self):
  c=FakeClient();BoundQuestion(c,FakeVerifier(),'seen').run(self.row);self.assertIn('SecretMarker',c.prompts[-1])
 def test_whole_document_verifier(self):
  v=FakeVerifier();BoundQuestion(FakeClient(),v).run(self.row);self.assertIn('SecretMarker',v.calls[-1][0])
 def test_quote_ablation(self):
  v=FakeVerifier();BoundQuestion(FakeClient(),v,'quote').run(self.row);self.assertNotIn('SecretMarker',v.calls[-1][0])
 def test_missing_candidate_in_binding_rejected(self):
  out=BoundQuestion(FakeClient('Something opened.'),FakeVerifier()).run(self.row);self.assertEqual(out['binding_checks'][0]['verification']['status'],'invalid_binding')
 def test_can_form_false_rejected(self):
  out=BoundQuestion(FakeClient('Navo opened.',False),FakeVerifier()).run(self.row);self.assertEqual(out['accepted_answers'],[])
 def test_supported_binding_accepted(self):
  self.row['question']='What opened after 1984?';out=BoundQuestion(FakeClient('Navo opened after 1984.'),FakeVerifier()).run(self.row);self.assertEqual(out['accepted_answers'],['Navo'])
