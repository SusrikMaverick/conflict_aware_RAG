"""Build local review report after completed transfer analysis; never uploads."""
import json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
audit=ROOT/'analysis/phase3f/audit.json';inventory=ROOT/'planning/phase3_complete/run_inventory.json';preservation=ROOT/'planning/phase3f/preservation_audit.json'
while True:
 if all(p.exists() for p in [audit,inventory,preservation]):
  a=json.loads(audit.read_text());i=json.loads(inventory.read_text());p=json.loads(preservation.read_text())
  if a.get('passed') and a.get('n')==4038 and i.get('output_records_total_including_copies')==9708 and p.get('passed') and preservation.stat().st_mtime>=audit.stat().st_mtime:break
 time.sleep(30)
env=dict(os.environ,PYTHONPATH='work')
for script in ['phase3_pair_and_cost_audit.py','phase3f_confrag_cases.py','phase3_complete_retrospective.py','phase3_complete_report.py','phase3_report_validate.py']:
 with (ROOT/'logs'/script.replace('.py','.log')).open('w') as log:
  subprocess.run([str(ROOT/'.venv/bin/python'),'work/'+script],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Completed',script,flush=True)
(ROOT/'planning/phase3_complete/automatic_report_build.json').write_text(json.dumps({'epoch':time.time(),'report_built':True,'local_links_checked':True,'pending':['Own GPU server release verification','Final worksheet live-read/write/readback','Final agent state','Local ZIP SHA/CRC verification'],'uploaded':False},indent=2)+'\n')
print('Review report ready; final resource/worksheet/archive checks remain.',flush=True)
