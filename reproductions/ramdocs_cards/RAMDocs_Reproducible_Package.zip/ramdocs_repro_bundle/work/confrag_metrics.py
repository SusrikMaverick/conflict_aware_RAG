"""Execute pinned upstream deterministic scorer with no upstream config imports."""
import ast
from real_runtime import ROOT
p=ROOT/'materials/datasets/confrag/analysisResult/grade.py';tree=ast.parse(p.read_text());ns={'CACHE_SIZE':65536}
body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef)) and not (isinstance(n,ast.ImportFrom) and n.module=='config')]
exec(compile(ast.Module(body=body,type_ignores=[]),str(p),'exec'),ns)
def score(prediction,reference):return ns['test']({'answer':prediction,'info':reference['selected_gold_partition']},dict(reference['data']))
