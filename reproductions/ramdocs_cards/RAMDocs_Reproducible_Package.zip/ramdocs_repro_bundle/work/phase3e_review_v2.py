import json,hashlib
from real_runtime import ROOT,write_json
from phase3e.method import BIND
p=ROOT/'analysis/phase3e/dev_v2';s=json.loads((p/'summary.json').read_text());v=s['variants'];b=v['quote_fix'];d=v['direct_json'];cases=json.loads((p/'casebook.json').read_text());errors=[];checked=0
for case in cases:
 keys={}
 for m in ['E_blind','E_seen','E_quote']:
  x=case['outputs'][m]
  for r in x.get('requests',[]):
   raw=json.loads((ROOT/'runs/request_cache/phase3c_v1'/(r['key']+'.json')).read_text());prompt=raw['request']['messages'][0]['content']
   if prompt.startswith(BIND):
    visible=json.loads(prompt.split('\nInput: ',1)[1]);checked+=1;keys[m]=r['key']
    expected={'question','candidates','document'} if m=='E_seen' else {'question','candidates'}
    if set(visible)!=expected or any(set(c)!= {'card_id','answer'} for c in visible['candidates']):errors.append([case['input']['question_id'],m,'binding_input_not_isolated'])
 if keys.get('E_blind')!=keys.get('E_quote'):errors.append([case['input']['question_id'],'shared_binding_request'])
gate={}
for m in ['E_blind','E_seen','E_quote']:
 a=v[m];gate[m]={'all_em_gain_ge10pp':(a['em']-b['em'])/100>=.1,'answerable_gain_ge10pp':(a['answerable_em']-b['answerable_em'])/50>=.1,'false_answer_increase_le2pp':(a['false_answers']-b['false_answers'])/50<=.02,'errors_not_increased':a['errors']<=b['errors'],'logical_tokens_le2x':a['tokens']<=2*b['tokens'],'source_and_binding_audit':not errors and s['audit']['passed'],'strong_baseline_boundary':(a['em']-d['em'])/100>=-.05 or (d['false_answers']-a['false_answers'])/50>=.04}
eligible=[m for m in gate if all(gate[m].values())];chosen=sorted(eligible,key=lambda m:(-v[m]['em'],v[m]['false_answers'],v[m]['tokens']))[0] if eligible else None
out={'gates':gate,'eligible':eligible,'selected_for_independent_confirmation':chosen,'binding_requests_audited':checked,'audit_errors':errors,'adaptive_development':True,'source_blinding_not_established_without_blind_seen_advantage':True};write_json(p/'decision.json',out);print(json.dumps(out,indent=2));assert not errors
