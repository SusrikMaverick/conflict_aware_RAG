"""Post-test exploratory output-cap diagnostic; primary predictions remain immutable."""
import collections,copy,hashlib,json,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from real_runtime import ROOT,Client,write_json,parse_json
run=ROOT/'runs/output_budget_diagnostic_v1';run.mkdir(exist_ok=True)
plan={'scope':'Exploratory format completion only, not benchmark efficacy; selected after observing primary failures','selection':'All unique JSON-mode cached requests ending in length and referenced by failed primary outputs; exclude doubled-cap context overflow; select up to64 by SHA256(seed576|key)','intervention':'Double max_tokens only; exact original prompt/schema/model/seed/penalty retained','limit':64,'workers':8,'primary_outputs_changed':False,'gold_used':False,'metrics':['finish_stop_and_json_object','completion_tokens','finish_reason'],'limits':['Selected failure subset, not all-question performance','JSON object completion does not establish schema/field/semantic correctness','Serving batch composition/epoch can differ from original; exploratory attribution only'],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
write_json(run/'protocol.json',plan)
while not (ROOT/'planning/automatic_finalization_finished.json').exists():time.sleep(30)
runs=['ramdocs-baselines-v1','ramdocs-main-v3','ramdocs-madam-v1','conflicts-main-v3','confrag-bounded-v1','confrag-cards-v3'];refs=collections.defaultdict(list)
for name in runs:
 d=ROOT/'runs'/name;recovered={}
 if (d/'recovered_request_links.json').exists():recovered={(r['method'],r['question_id']):r['request'] for r in json.loads((d/'recovered_request_links.json').read_text())['links']}
 for p in d.glob('*/*.json'):
  r=json.loads(p.read_text())
  if r.get('status') not in ('error','parse_error','output_limit') or 'question_id' not in r:continue
  calls=r.get('requests',[])
  if r.get('request'):calls=[r['request']]
  if (r['method'],r['question_id']) in recovered:calls=[recovered[(r['method'],r['question_id'])]]
  for call in calls:
   if call.get('finish_reason')=='length':refs[call['key']].append({'run':name,'question_id':r['question_id'],'method':r['method']})
chosen=[];excluded=[]
for key in sorted(refs,key=lambda k:hashlib.sha256(('budget-diagnostic-576|'+k).encode()).hexdigest()):
 old=json.loads((ROOT/'runs/request_cache/v1'/(key+'.json')).read_text());payload=old['request']
 if not payload.get('response_format'):excluded.append({'key':key,'reason':'not_JSON_mode'});continue
 cap=payload['max_tokens']*2
 if old['preflight_tokens']+cap>32768:excluded.append({'key':key,'reason':'doubled_cap_context_overflow'});continue
 chosen.append({'key':key,'original_max_tokens':payload['max_tokens'],'new_max_tokens':cap,'references':refs[key]})
selected=chosen[:64];write_json(run/'manifest.json',{'protocol':plan,'eligible':len(chosen),'selected':selected,'excluded':excluded,'selection_frozen_epoch':time.time()});client=Client()
def one(item):
 p=run/'responses'/(item['key']+'.json')
 if p.exists():return json.loads(p.read_text())
 old=json.loads((ROOT/'runs/request_cache/v1'/(item['key']+'.json')).read_text());payload=old['request'];fmt=payload['response_format'];mode=fmt['json_schema']['schema'] if fmt['type']=='json_schema' else True
 assert len(payload['messages'])==1 and payload['messages'][0]['role']=='user'
 target=copy.deepcopy(payload);target['max_tokens']=item['new_max_tokens'];out=dict(item)
 try:
  new=client.chat(payload['messages'][0]['content'],item['new_max_tokens'],mode,payload['repetition_penalty']);assert new['request']==target
  try:parse_json(new['text']);valid=True
  except Exception:valid=False
  out.update(status='evaluated',original_finish=old['finish_reason'],new_finish=new['finish_reason'],new_request_key=new['key'],new_json_object_valid=valid,finish_stop_and_json_object=bool(valid and new['finish_reason']=='stop'),original_completion_tokens=old['usage']['completion_tokens'],new_completion_tokens=new['usage']['completion_tokens'],new_prompt_tokens=new['usage']['prompt_tokens'])
 except Exception as e:out.update(status='error',error=type(e).__name__+':'+str(e))
 write_json(p,out);return out
results=[]
with ThreadPoolExecutor(8) as pool:
 for f in as_completed([pool.submit(one,x) for x in selected]):
  results.append(f.result());write_json(run/'progress.json',{'completed':len(results),'total':len(selected),'finished':len(results)==len(selected),'errors':sum(r['status']=='error' for r in results)})
summary={'n_selected':len(selected),'eligible_failed_JSON_requests':len(chosen),'complete_JSON_after_larger_cap':sum(r.get('finish_stop_and_json_object',False) for r in results),'new_status_counts':dict(collections.Counter(r.get('new_finish',r['status']) for r in results)),'new_completion_tokens':sum(r.get('new_completion_tokens',0) for r in results),'new_prompt_tokens':sum(r.get('new_prompt_tokens',0) for r in results),'primary_predictions_unchanged':True,'limits':plan['limits'],'results':sorted(results,key=lambda r:r['key'])};write_json(run/'analysis.json',summary);print('OUTPUT BUDGET DIAGNOSTIC FINISHED',json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)
