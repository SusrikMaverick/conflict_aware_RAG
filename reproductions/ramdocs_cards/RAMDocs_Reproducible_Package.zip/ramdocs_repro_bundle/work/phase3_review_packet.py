"""Retrospective diagnostic packet, not a random human-gold evaluation set."""
import json,csv,random,html
from pathlib import Path
from real_runtime import ROOT,write_json
out=ROOT/'annotations/phase3_diagnostic_review';rng=random.Random(576);rows=[];keys=[];seen=set()
x=json.loads((ROOT/'analysis/phase3e/check_v2/changed_cases.json').read_text())
for stratum in ['gain_vs_old','loss_vs_old','E_false_answer']:
 selected=0
 for c in x[stratum]:
  if c['question_id'] in seen:continue
  seen.add(c['question_id']);selected+=1;rid=f'R{len(rows)+1:03d}';models=['E','old'];rng.shuffle(models)
  answers={m:' | '.join(c[m].get('accepted_answers',[])) or '[ABSTAIN]' for m in models}
  rows.append({'review_id':rid,'task':'single_document_answer_review','question':c['question'],'sources':c['document'],'candidate_A':answers[models[0]],'candidate_B':answers[models[1]],'rater_1':'','rater_1_answerability':'','rater_1_supported_answer':'','rater_1_A_valid':'','rater_1_B_valid':'','rater_1_reason':'','rater_2':'','rater_2_answerability':'','rater_2_supported_answer':'','rater_2_A_valid':'','rater_2_B_valid':'','rater_2_reason':'','adjudication':''})
  keys.append({'review_id':rid,'question_id':c['question_id'],'diagnostic_stratum':stratum,'candidate_A_method':models[0],'candidate_B_method':models[1],'published_gold':c['gold'],'published_impossible':c['impossible']})
  if selected==5:break
cases=json.loads((ROOT/'analysis/phase3d/dev_v1/casebook.json').read_text())
for case in cases:
 edges=case['outputs']['graph_C1'].get('pair_edges',[]);cards={c['card_id']:c for c in case['outputs']['perdoc_C1'].get('cards',[])}
 edge=next((e for e in edges if cards[e['left']]['doc_id']!=cards[e['right']]['doc_id']),None)
 if edge is None:continue
 rid=f'R{len(rows)+1:03d}';a=cards[edge['left']];b=cards[edge['right']];ids={a['doc_id'],b['doc_id']};sources='\n\n'.join(d['doc_id']+': '+d['text'] for d in case['input']['documents'] if d['doc_id'] in ids)
 blank={k:'' for k in rows[0]};blank.update(review_id=rid,task='pair_scope_and_compatibility_review',question=case['input']['question'],sources=sources,candidate_A=a['claim'],candidate_B=b['claim']);rows.append(blank);keys.append({'review_id':rid,'question_id':case['input']['question_id'],'candidate_A_card':a['card_id'],'candidate_B_card':b['card_id'],'model_edge_hidden':edge,'human_gold_available':False})
 if len(rows)==30:break
assert len(rows)==30
with (out/'blind_review.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write_json(out/'evaluator_only_key.json',keys)
(out/'instructions.txt').write_text('本包30条为回顾性机制诊断，不是随机/代表性抽样，不用于总体准确率或关系F1。15条单源、15条多源；均来自已观察评测。human gold=0，所有rater字段空白。\n两位真实评审独立完成后再讨论分歧；本agent不冒填。单源：仅据原文判问题可答性/支持的答案、A/B是否完整且保留实体/时间/否定/数量条件。明确错误与gold词面/粒度歧义分开记录。多源：candidateA/B为两个claim，A_valid/B_valid记录各自来源支持，supported_answer栏记录same/different/unclear entity及relation与证据；不要把不同数值自动当矛盾。\n不要打开evaluator_only_key.json直到两位独立评审提交。该key含模型方法/既有gold/选样层，仅供后续分析；不是新的人类gold。若有人认出公开数据内容，在reason中记录。此packet不能用于在原test继续调参；后续方法要新开发/新确认。\n')
body='<h1>Retrospective diagnostic review: 30 items</h1><p>No human labels yet. Read instructions.txt first. This purposive sample cannot estimate population accuracy.</p>'
for r in rows:
 body+='<article><h2>'+r['review_id']+' · '+html.escape(r['task'])+'</h2><h3>'+html.escape(r['question'])+'</h3><pre>'+html.escape(r['sources'])+'</pre><p><b>A:</b> '+html.escape(r['candidate_A'])+'</p><p><b>B:</b> '+html.escape(r['candidate_B'])+'</p></article>'
(out/'blind_packet.html').write_text('<meta charset="utf-8"><style>body{font:16px/1.6 sans-serif;max-width:1000px;margin:30px auto}pre{white-space:pre-wrap}article{border-top:1px solid #ccc;margin-top:30px;page-break-before:always}</style>'+body)
write_json(out/'manifest.json',{'n':30,'single_source_n':15,'pair_scope_n':15,'human_annotations':0,'selection':'5 old-to-new gains,5 losses,5 unanswerable errors without duplicate questions; first15 eligible multi-document pairs','role':'purposive retrospective diagnosis, not representative human gold','labels_blind_file':'blind_review.csv','evaluator_key':'evaluator_only_key.json'})
