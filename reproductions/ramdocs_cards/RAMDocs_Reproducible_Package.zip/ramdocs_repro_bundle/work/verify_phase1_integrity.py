"""Read-only checks of frozen source, supplied materials and checkpoint outputs."""
import base64, hashlib, json, time
from pathlib import Path
from real_runtime import ROOT, write_json

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

freeze = json.loads((ROOT/'planning/protocols/main_freeze_v3.json').read_text())
sources = {n: sha(ROOT/n) == h for n,h in freeze['code_hashes'].items()}
snapshot = []
for item in json.loads((ROOT/'.metadata/github_snapshot.json').read_text())['files']:
    data = (ROOT/'conflict_aware_RAG'/item['path']).read_bytes()
    snapshot.append({'path': item['path'], 'bytes_match': data == base64.b64decode(item['content']),
                     'git_blob_match': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest() == item['sha']})
proposal = sha(ROOT/'materials/proposal_submitted.pdf')
transitions = {}
for name in ['planning/runtime_client_resume.json','planning/runtime_confrag_card_resume.json',
             'runs/confrag-bounded-v1/runtime_history/concurrency_transition.json']:
    d = json.loads((ROOT/name).read_text())
    records = d.get('runs', {'single': d})
    checks = {}
    for run, record in records.items():
        hashes = record['preserved_output_sha256']
        failures = [p for p,h in hashes.items() if not (ROOT/p).exists() or sha(ROOT/p) != h]
        checks[run] = {'n_checked': len(hashes), 'mismatches': failures}
    transitions[name] = checks
passed = all(sources.values()) and all(r['bytes_match'] and r['git_blob_match'] for r in snapshot)
passed = passed and proposal == '003280e1cc9d3f8de03f615861ff7811c170b75cd01c23deb103567b3898c38f'
passed = passed and not any(v['mismatches'] for t in transitions.values() for v in t.values())
primary_path = ROOT/'planning/primary_output_hashes.json'
primary = {'n_checked': 0, 'mismatches': []}
if primary_path.exists():
    hashes = json.loads(primary_path.read_text())['output_sha256']
    primary = {'n_checked': len(hashes), 'mismatches': [p for p,h in hashes.items() if sha(ROOT/p) != h]}
    passed = passed and not primary['mismatches']
out = {'epoch': time.time(), 'frozen_sources': sources, 'team_snapshot': snapshot,
       'proposal_sha256': proposal, 'runtime_checkpoint_integrity': transitions, 'primary_outputs': primary, 'passed': passed,
       'conda_note': 'Only project-local .venv/.analysis-venv were installed into. No conda/global package mutation issued; action provenance, not a complete disk comparison.'}
write_json(ROOT/'planning/phase1_final_integrity.json', out)
print(json.dumps(out))
assert passed
