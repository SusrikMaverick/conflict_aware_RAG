import argparse,collections,json
from pathlib import Path
from confrag_metrics import score
from real_runtime import ROOT,write_json
ap=argparse.ArgumentParser();ap.add_argument('run',type=Path);a=ap.parse_args()
refs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/confrag_official_v1/evaluation.jsonl').open())};out={};per=[]
for method in json.loads((a.run/'manifest.json').read_text())['methods']:
 metrics=[];errors=[];full_context=[]
 for p in sorted((a.run/method).glob('*.json')):
  r=json.loads(p.read_text());m={'question_id':r['question_id'],'method':method,'status':r['status'],'NMI':0,'answerScore':0,'reasonScore':0}
  if r['status']=='ok':
   try:m.update(score(r['prediction'],refs[r['question_id']]))
   except Exception as e:m.update(status='scorer_error',scorer_error=type(e).__name__+':'+str(e))
  metrics.append(m);per.append(m)
  if not any(x['truncated'] for x in r.get('context_audit',[])):full_context.append(m)
 out[method]={'n':len(metrics),'status_counts':dict(collections.Counter(m['status'] for m in metrics)),**{k:sum(m[k] for m in metrics)/len(metrics) if metrics else None for k in ('NMI','answerScore','reasonScore')},'without_truncation_n':len(full_context),'without_truncation_scores':{k:sum(m[k] for m in full_context)/len(full_context) if full_context else None for k in ('NMI','answerScore','reasonScore')},'bad_partition_counts':dict(collections.Counter(m.get('badPartition','no_valid_output') for m in metrics))}
write_json(a.run/'analysis.json',{'methods':out,'limitations':['Recommended1098 release;1061 official-rule-eligible','Both conditions have gold-selected max5-doc subsets; oracle_K additionally receives gold cluster count','Original prompt roles flattened to one user message in local client; report as adapter not exact original API reproduction','Overflow/errors score0 in all-eligible denominator','Official empty-gold-reason division error is retained as scorer_error, not silently repaired']})
(a.run/'scored.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in per))
print(json.dumps(out,indent=2))
