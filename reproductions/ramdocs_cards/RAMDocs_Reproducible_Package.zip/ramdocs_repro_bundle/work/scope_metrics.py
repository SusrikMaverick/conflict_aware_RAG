import json,collections,hashlib,random,argparse
from real_runtime import ROOT,write_json
from component_metrics import norm,f1
def predicted_pairs(out):
 if out['status'] in ['error','parse_error','abstain']:return set()
 if 'attributed_answers' in out:vals=out['attributed_answers']
 else:
  accepted={norm(a) for a in out.get('accepted_answers',[])}
  vals=[c for c in out.get('citations',[]) if norm(c.get('answer','')) in accepted]
 return {(r['doc_id'],norm(r['answer'])) for r in vals if r.get('answer','').strip()}
def score(out,ref):
 gold={(r['doc_id'],norm(r['answer'])) for r in ref['pairs']};pred=predicted_pairs(out);tp=len(pred&gold)
 scores={'pair_f1':2*tp/(len(pred)+len(gold)) if pred or gold else 1.,'complete':int(gold==pred),'pair_recall':tp/len(gold),'tp':tp,'pred_n':len(pred),'gold_n':len(gold),'wrong':len(pred-gold),'doc_token_f1':sum(max([f1(a,r['answer']) for d,a in pred if d==r['doc_id']] or [0]) for r in ref['pairs'])/len(ref['pairs'])}
 return scores
def analyze(protocol):
 rows=[json.loads(l) for l in (ROOT/protocol['input']).read_text().splitlines()];refs={r['question_id']:r for r in map(json.loads,(ROOT/protocol['eval']).read_text().splitlines())};run=ROOT/protocol['run'];out=ROOT/protocol['analysis'];out.mkdir(exist_ok=True);records=[];cases=[];cache={};audit={'citation_errors':[],'missing_cache':[],'unknown_doc_ids':[]}
 for row in rows:
  q=row['question_id'];ref=refs[q];outputs={};docs={d['doc_id']:d['text'] for d in row['documents']}
  for m in protocol['methods']:
   x=json.loads((run/m/(q+'.json')).read_text());outputs[m]=x
   for d,a in predicted_pairs(x):
    if d not in docs:audit['unknown_doc_ids'].append([q,m,d])
   for c in x.get('citations',[]):
    if c.get('doc_id') not in docs or not c.get('quote') or c['quote'] not in docs[c['doc_id']]:audit['citation_errors'].append([q,m,c])
   for r in x.get('requests',[]):
    p=ROOT/protocol['cache']/(r['key']+'.json')
    if not p.exists():audit['missing_cache'].append([q,m,r['key']])
    elif r['key'] not in cache:cache[r['key']]=json.loads(p.read_text())
   records.append({'question_id':q,'group':ref['group'],'variant':m,'status':x['status'],'error':x.get('error'),**score(x,ref),'tokens':sum(r.get('usage',{}).get('total_tokens',0) for r in x.get('requests',[])),'calls':len(x.get('requests',[]))})
  cases.append({'input':row,'reference':ref,'outputs':outputs})
 summary={}
 for m in protocol['methods']:
  rr=[r for r in records if r['variant']==m];summary[m]={'n':len(rr),**{k:sum(r[k] for r in rr)/len(rr) for k in ['pair_f1','pair_recall','doc_token_f1']},**{k:sum(r[k] for r in rr) for k in ['complete','tp','pred_n','gold_n','wrong','tokens','calls']},'errors':sum(r['status'] in ['error','parse_error'] for r in rr)}
  summary[m]['wrong_prediction_fraction']=summary[m]['wrong']/summary[m]['pred_n'] if summary[m]['pred_n'] else None
 contrasts={};rng=random.Random(576)
 for left,right in protocol['contrasts']:
  l={r['question_id']:r for r in records if r['variant']==left};r={r['question_id']:r for r in records if r['variant']==right};groups=collections.defaultdict(list)
  for q in l:groups[l[q]['group']].append((l[q],r[q]))
  for metric in ['pair_f1','complete','doc_token_f1']:
   vals={g:(sum(a[metric]-b[metric] for a,b in pairs),len(pairs)) for g,pairs in groups.items()};keys=list(vals);bs=[]
   for _ in range(5000):
    chosen=rng.choices(keys,k=len(keys));bs.append(sum(vals[g][0] for g in chosen)/sum(vals[g][1] for g in chosen))
   bs.sort();contrasts[f'{left}-{right}/{metric}']={'delta':sum(x[0] for x in vals.values())/sum(x[1] for x in vals.values()),'cluster_bootstrap95':[bs[124],bs[4874]],'groups':len(keys)}
 audit.update(passed=not any(audit.values()),n_outputs=len(records),unique_requests=len(cache),unique_request_tokens=sum(r.get('usage',{}).get('total_tokens',0) for r in cache.values()))
 result={'variants':summary,'contrasts':contrasts,'audit':audit,'split_role':protocol['split_role'],'metric_scope':'strict source-attributed answer metrics, not official AmbigDocs DF1 or human semantic relation metrics'}
 write_json(out/'summary.json',result);write_json(out/'per_question.json',records);write_json(out/'casebook.json',cases);write_json(out/'output_hashes.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in run.glob('*/*.json')});print(json.dumps(result,indent=2));return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('protocol');a=p.parse_args();analyze(json.loads((ROOT/a.protocol).read_text()))
