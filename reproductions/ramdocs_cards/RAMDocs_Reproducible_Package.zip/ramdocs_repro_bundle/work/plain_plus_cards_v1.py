"""User-requested exploratory ablation: unchanged plain prompt + extracted cards."""
import collections
import hashlib
import json
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from real_runtime import ROOT, Client, load_plain_prompt, plain_parse, write_json
from metrics import score

NAME = 'plain_plus_cards_v1'
PLAN = ROOT / 'planning' / NAME
RUN = ROOT / 'runs' / NAME
FIELDS = ('doc_id', 'card_id', 'entity', 'scope', 'claim', 'answer', 'quote')
SUFFIX = ('\n\nAdditional extracted evidence from the SAME documents (not independent '
          'sources and not guaranteed true). Use alongside the original documents above.\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    rows = [json.loads(x) for x in (ROOT/'materials/prepared/v1/ramdocs.inputs.jsonl').read_text().splitlines()]
    hashes = {}
    prepared = []
    for row in rows:
        q = row['question_id']
        source = ROOT/'runs/phase3f-transfer-v3/ramdocs/F_C1'/f'{q}.json'
        baseline = ROOT/'runs/ramdocs-combined-v3/plain'/f'{q}.json'
        hashes[str(source.relative_to(ROOT))] = sha(source)
        hashes[str(baseline.relative_to(ROOT))] = sha(baseline)
        extracted = json.loads(source.read_text())
        cards = [{k: c[k] for k in FIELDS if k in c} for c in extracted.get('cards', [])]
        docs = '\n'.join(f"Document {i}: {d['text']}" for i, d in enumerate(row['documents'], 1))
        prompt = load_plain_prompt().format(question=row['question'], documents=docs)
        id_map = {d['doc_id']: i for i, d in enumerate(row['documents'], 1)}
        for c in cards:
            c['original_document_number'] = id_map[c['doc_id']]
        prepared.append({'question_id': q, 'prompt': prompt + SUFFIX + json.dumps(cards, ensure_ascii=False),
                         'cards': cards, 'source_status': extracted['status'], 'source': str(source.relative_to(ROOT))})
    for path in ['materials/prepared/v1/ramdocs.inputs.jsonl', 'materials/prepared/v1/ramdocs.evaluation.jsonl',
                 'work/plain_plus_cards_v1.py', 'work/real_runtime.py', 'work/metrics.py', 'conflict_aware_RAG/src/eval.py']:
        hashes[path] = sha(ROOT/path)
    manifest = {'name': NAME, 'frozen_before_generation_epoch': time.time(), 'n': 500,
        'primary': 'official_compatible; paired difference vs frozen plain',
        'secondary': ['strict_set_exact', 'wrong_only_accepted', 'parse_error', 'output_limit', 'token_usage'],
        'model': 'Qwen2.5-7B-Instruct BF16', 'temperature': 0, 'seed': 576, 'max_tokens': 128,
        'repetition_penalty': 1.05, 'workers': 24, 'max_context': 32768,
        'intervention': 'Append all available C1 extracted cards; exclude support scores/status, binding and relation decisions. No filtering, voting, enforced abstention or answer edits.',
        'baseline': 'Reuse fixed original 500 plain outputs; no baseline rerun. Runtime batching may differ.',
        'incomplete_extraction_policy': 'Four prior extraction/collection errors have no saved cards: retain all questions, append empty list, report separately; do not retry old failures.',
        'incomplete_sources': [r['question_id'] for r in prepared if r['source_status']=='error'],
        'test_status': 'Previously observed RAMDocs; exploratory, not independent confirmation.',
        'overflow_policy': 'No truncation; count overflow or request failure as failure; no completed-output retries.',
        'hashes': hashes}
    assert len(prepared) == 500
    PLAN.mkdir(parents=True, exist_ok=True)
    write_json(PLAN/'protocol.json', manifest)
    write_json(PLAN/'inputs.json', prepared)
    return manifest, prepared

def run():
    p = json.loads((PLAN/'protocol.json').read_text())
    for f, h in p['hashes'].items():
        assert sha(ROOT/f) == h, f
    rows = json.loads((PLAN/'inputs.json').read_text())
    c = Client()
    c.cache = RUN/'request_cache'
    c.cache.mkdir(parents=True, exist_ok=True)
    def one(row):
        start = time.time()
        out = {'question_id': row['question_id'], 'method': NAME, 'card_count': len(row['cards']),
               'source_status': row['source_status'], 'accepted_answers': []}
        try:
            response = c.chat(row['prompt'], 128, False, 1.05)
            out.update(raw_output=response['text'], finish_reason=response['finish_reason'],
                       requests=[{k: response[k] for k in ('key','usage','latency_seconds','finish_reason','cache_hit')}])
            try:
                answers = plain_parse(response['text'])
                out.update(accepted_answers=answers, status='answered' if answers else 'abstain')
            except (ValueError, SyntaxError):
                out['status'] = 'parse_error'
        except Exception as exc:
            out.update(status='error', error=str(exc), error_kind='context_overflow' if str(exc).startswith('context_overflow') else 'infrastructure', traceback=traceback.format_exc())
        out['wall_seconds'] = time.time()-start
        write_json(RUN/'outputs'/(row['question_id']+'.json'), out)
        return out
    jobs = [r for r in rows if not (RUN/'outputs'/(r['question_id']+'.json')).exists()]
    with ThreadPoolExecutor(max_workers=24) as pool:
        futures = [pool.submit(one, row) for row in jobs]
        for i, future in enumerate(as_completed(futures), 1):
            result = future.result()
            write_json(RUN/'progress.json', {'completed_this_pass': i, 'planned_this_pass':len(jobs), 'last_status':result['status']})
            if i % 25 == 0:
                print(i, '/', len(jobs), flush=True)
    analyze()

def analyze():
    gold = [json.loads(x) for x in (ROOT/'materials/prepared/v1/ramdocs.evaluation.jsonl').read_text().splitlines()]
    metrics = collections.defaultdict(list)
    outputs = collections.defaultdict(list)
    paired = []
    for row in gold:
        q = row['question_id']
        pair = {'question_id': q}
        for name, path in [('plain', ROOT/'runs/ramdocs-combined-v3/plain'/f'{q}.json'),
                           ('plus_cards', RUN/'outputs'/f'{q}.json')]:
            out = json.loads(path.read_text())
            s = score(out, row['gold_answers'], row['wrong_answers'])
            metrics[name].append(s)
            outputs[name].append(out)
            pair[name] = s
        paired.append(pair)
    summary = {}
    for name, ms in metrics.items():
        summary[name] = {k: sum(m[k] for m in ms)/len(ms) for k in ms[0]}
        summary[name]['n'] = len(ms)
        summary[name]['statuses'] = dict(collections.Counter(o['status'] for o in outputs[name]))
        summary[name]['output_limit'] = sum(o.get('finish_reason')=='length' or any(r.get('finish_reason')=='length' for r in o.get('requests',[])) for o in outputs[name])
        summary[name]['logical_tokens'] = sum(sum(r.get('usage',{}).get('total_tokens',0) for r in o.get('requests',[])) for o in outputs[name])
    gains = sum(p['plus_cards']['official_compatible'] > p['plain']['official_compatible'] for p in paired)
    losses = sum(p['plus_cards']['official_compatible'] < p['plain']['official_compatible'] for p in paired)
    import numpy as np
    delta = np.array([p['plus_cards']['official_compatible']-p['plain']['official_compatible'] for p in paired])
    rng = np.random.default_rng(576)
    boots = delta[rng.integers(0,500,size=(10000,500))].mean(axis=1)
    summary['paired'] = {'gains':gains,'losses':losses,'delta':float(delta.mean()),'question_bootstrap_95CI':np.quantile(boots,[.025,.975]).tolist(), 'caveat':'Question bootstrap assumes independence; dataset may share entities/documents.'}
    outdir = ROOT/'analysis'/NAME
    write_json(outdir/'summary.json', summary)
    write_json(outdir/'paired.json', paired)
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)

if __name__ == '__main__':
    import sys
    if sys.argv[-1] == 'prepare': prepare()
    elif sys.argv[-1] == 'analyze': analyze()
    else: run()
