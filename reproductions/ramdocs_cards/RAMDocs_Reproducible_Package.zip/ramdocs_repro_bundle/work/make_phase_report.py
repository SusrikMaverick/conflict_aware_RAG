"""Build a self-contained local HTML report from measured run artifacts only."""
import csv,html,json
from pathlib import Path
from real_runtime import ROOT,write_json

def esc(s):return html.escape(f'{s:.4f}' if isinstance(s,float) else str(s))
def table(headers,rows):return '<table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</tbody></table>'
def main():
 out=ROOT/'analysis/phase1';out.mkdir(parents=True,exist_ok=True)
 sections=[];index=[]
 def add(title,body):sections.append('<h2>'+esc(title)+'</h2>'+body)
 p=ROOT/'runs/ramdocs-combined-v3/analysis.json'
 if p.exists():
  x=json.loads(p.read_text());f=x['methods']['full'];b=x['methods']['plain'];d=x['paired']['full-minus-plain'];ci=d['95pct_paired_group_bootstrap']
  interpretation='区间跨0，当前证据不能确定该比较的收益方向。' if ci[0]<=0<=ci[1] else ('该固定设置下完整方法低于普通RAG。' if ci[1]<0 else '该固定设置下完整方法高于普通RAG；不能外推到其他backbone。')
  add('主结果概览','<p>RAMDocs500题：full论文口径兼容正确率'+f"{100*f['official_compatible']:.1f}%"+'，普通RAG为'+f"{100*b['official_compatible']:.1f}%"+'；差值'+f"{100*d['delta']:.1f}"+'个百分点，95%配对分组区间'+f"[{100*ci[0]:.1f}, {100*ci[1]:.1f}]"+'。'+interpretation+'</p><p>full完整回答覆盖率'+f"{100*f['answered']:.1f}%"+'，接受wrong-only答案比例'+f"{100*f['wrong_only_accepted']:.1f}%"+'。必须同时评估正确率与覆盖，不能将更多弃答单独算作成功。</p>')
 add('范围与有效性','<p><a href="methods_and_deviations.txt">逐条件方法与proposal偏离清单</a>：full表示本次prompt原型；单一集合标签、精确字符串分组、同集合提示内解释搜索，以及E2结构检查，均有明确能力边界。字段span存在不等于逐字段语义已验证。</p><p>全部数值来自服务器上的真实模型输出。使用固定版本 Qwen2.5-7B-Instruct（BF16）与 MiniCheck-Flan-T5-Large；这不是 proposal 的72B复现。所有新代码与结果留在服务器，未向团队GitHub写入，未修改已有conda环境。</p><p>人工试标、人工fact-card金标准、自然数据八分类人工评估和IAA仍未完成。合成开发样例的构造参考不能代替人工gold；模型预测和流程完成也不等于研究假设成立。</p>')
 if p.exists():
  majority=x['methods']['majority']
  add('逐研究问题结论',table(['问题','本阶段结论','证据与不能推出的结论'],[
   ['RQ1：关系识别是否改善','自然数据主指标尚不能回答','缺人工held-out八类标签；合成开发诊断和ConfRAG的NMI不能替代自然关系macro-F1。'],
   ['RQ2：回答质量是否改善','RAMDocs当前full原型不支持改善；CONFLICTS尚无独立质量评价','RAMDocs主对照见上述配对区间；CONFLICTS只报告输出行为，不能用回答比例冒充适当性。'],
   ['RQ3：是否更可靠地裁决','错误接受减少伴随回答覆盖大幅减少，尚不能确认可靠裁决',f"全500题wrong-only接受：full {f['wrong_only_accepted']:.1%}，精确scope多数票 {majority['wrong_only_accepted']:.1%}；有接受答案的覆盖：{f['any_accepted']:.1%} vs {majority['any_accepted']:.1%}。这不是人工确认矛盾子集上的因果结论；自然full未观察到accepted E2。"]]))
 runs=['real-pilot20-v1','real-pilot20-v1_1','real-pilot20-v1_2','real-pilot20-v1_3','real-pilot20-v2','real-pilot20-v3','constructed-oracle20-v2','stress39-v2','stress39-v3','ramdocs-main-v2','ramdocs-baselines-v1','ramdocs-main-v3','ramdocs-madam-v1','conflicts-main-v3','confrag-bounded-v1','confrag-cards-v3','output_budget_diagnostic_v1','phase1-reproduction-smoke-v1']
 progress=[]
 for run in runs:
  directory=ROOT/'runs'/run
  if not directory.exists():progress.append([run,'未运行','','']);continue
  p=directory/'progress.json';state=json.loads(p.read_text()) if p.exists() else {}
  progress.append([run,'已停止／排除主比较' if (directory/'ABORTED.json').exists() else ('已结束' if state.get('finished') else ('运行中' if state else '等待前置')), str(state.get('completed',''))+'/'+str(state.get('total','')),state.get('errors','')]);index.append({'run':run,'path':str(directory),'progress':state})
 add('运行清单',table(['run','状态','输出数','错误数'],progress))
 p=ROOT/'planning/primary_output_hashes.json'
 if p.exists():
  completion=json.loads(p.read_text());add('主矩阵完成与失败','<p>9,618份逐题输出全部保留：'+esc(completion['status_counts'])+'。257条error与72条parse_error合计329条异常输出；这些仍保留在各自评分分母。进度文件的errors字段不一定包括parse_error，应以审计状态为准。ConfRAG卡片的172条异常涉及86个问题、两个条件共用失败抽取，不是172个独立请求。</p>')
 for run in ['real-pilot20-v1_3','real-pilot20-v3','constructed-oracle20-v2']:
  p=ROOT/'runs'/run/'analysis.json'
  if not p.exists():continue
  x=json.loads(p.read_text());rows=[]
  for method,m in x['methods'].items():rows.append([method,m['n'],m['status_counts'],'—' if m['relation_accuracy'] is None else f"{m['relation_accuracy']:.3f}",'—' if m['fixed8_macro_f1'] is None else f"{m['fixed8_macro_f1']:.3f}",m.get('false_contradiction_rate'),m.get('contradiction_recall'),m.get('insufficient_rate'),m['cards']])
  add(run+'：合成开发诊断',table(['方法','n','输出状态','关系准确率','固定8类macro-F1','假矛盾率','矛盾召回','insufficient比例','卡片状态'],rows)+'<p>这些是相关的构造样例，不能据此声称自然数据泛化；无关系分类输出的方法不计算关系分数。constructed-oracle为agent构造卡片，不是人工gold。quote-scope的零假矛盾同时伴随零矛盾召回，不能视为成功。最终full开发集FCR从raw的0.50降至0.167，但召回从1.0降至0.50，insufficient达0.35；必须一起解释。构造oracle提高关系准确率，却没有提高macro-F1，不能把瓶颈归结为抽取一项。</p>')
 for run in ['ramdocs-combined-v3','conflicts-main-v3']:
  p=ROOT/'runs'/run/'analysis.json'
  if not p.exists():continue
  x=json.loads(p.read_text());rows=[]
  for method,m in x['methods'].items():rows.append([method,m['n'],m.get('official_compatible','—'),m.get('strict_set_exact','—'),m.get('wrong_only_accepted','—'),m.get('answered','—'),m.get('selective_risk','—'),m['status_counts']])
  if run=='conflicts-main-v3':
   add(run,table(['方法','分母','完整回答比例','有接受答案比例','执行错误比例','输出状态'],[[k,v['n'],v['answered'],v['any_accepted'],v.get('any_error'),v['status_counts']] for k,v in x['methods'].items()])+'<p>这里只报告行为分布，不报告回答适切性或准确率。独立评价尚未进行；1374条输出准备为待审包。原数据类别与本方法8类并非一一对应，不强行映射评分。675篇short_text为空，涉及272题，保留缺失性而不静默替换为full content。</p>')
   add('CONFLICTS类别分层（描述性）',table(['方法','原始类别','n','完整回答比例','有接受答案比例'],[[k,label,d['n'],d['answered'],d['any_accepted']] for k,v in x['methods'].items() for label,d in v.get('descriptive_category_strata',{}).items()]))
  else:add(run,table(['方法','分母','论文口径兼容正确率','严格答案集合','接受wrong-only比例','完整回答覆盖','选择风险','状态'],rows))
  if run=='ramdocs-combined-v3':
   add('共同回答覆盖口径（补充诊断）',table(['方法','n','非空accepted集合比例','该子集的选择风险','系统声明完整回答比例','声明完整子集的风险'],[[k,v['n'],v['any_accepted'],v.get('selective_risk_any_accepted'),v['answered'],v['selective_risk']] for k,v in x['methods'].items()])+'<p>各方法对status=answered的保守程度不同，因此另报统一的“accepted_answers非空”口径，包含partial。补充诊断不改变主正确率或任何预测；风险按论文兼容正确性计算，仅为固定工作点，不是阈值扫描或校准证明。</p>')
   add('RAMDocs计分说明','<p>完整回答覆盖按系统status=answered统计，部分回答另保留；它不是gold意义的完整性标签。选择风险只在该answered子集内计算。wrong-only接受率依据可解析的accepted_answers；格式失败的真实答案内容可能未被此指标覆盖，因此必须同时看失败数。论文口径兼容分数读取答案区原文，可能给格式解析失败但字符串匹配的输出得分；严格答案集合分数不会。未获接受的争议候选不计入accepted答案。</p>')
   add('RAMDocs预定分层', '<details><summary>展开fake、标注平票／少数与缺支持分层</summary>'+table(['方法','分层','n','论文兼容正确率','wrong-only接受','完整回答覆盖'],[[k,label,d['n'],d['official_compatible'],d['wrong_only_accepted'],d['answered']] for k,v in x['methods'].items() for label,d in v['strata'].items() if label not in ('single_gold','multiple_gold')])+'</details><p>平票／少数层基于事前固定的数据集答案标注计票，不等于模型提取后的票数或语义蕴涵。假答案领先单答案层仅2题，不支持稳定泛化判断；159题也不是方法必错上限。</p>')
  if x.get('paired'):add(run+'：配对统计',table(['对照','样本数','分组数','正确率差','95%分组bootstrap区间'],[[k,v['n_questions'],v['n_groups'],v['delta'],v['95pct_paired_group_bootstrap']] for k,v in x['paired'].items()]))
 p=ROOT/'runs/stress39-v3/analysis.json'
 if p.exists():
  x=json.loads(p.read_text());add('顺序、重复文档与约束反事实',table(['方法','n','构造关系准确率','不可裁决例仍接受答案','顺序/重复后答案变化数'],[[k,v['n'],v['relation_accuracy'],str(v['unresolved_with_accepted_answer'])+'/'+str(v['unresolved_cases']),sum(r['answer_set_changed'] for r in v['perturbation_changes'])] for k,v in x['methods'].items()]))
 p=ROOT/'analysis/confrag_comparison/comparison.json'
 if p.exists():
  x=json.loads(p.read_text());add('ConfRAG上下文受限适配',table(['条件','n','NMI','答案分数','理由分数','状态'],[[k,v['n'],*[round(v['mean'][m],4) for m in ['NMI','answerScore','reasonScore']],v['status_counts']] for k,v in x['methods'].items()])+'<p>推荐修订版1098题，官方子集选择规则可用1061题。四个条件都使用金标准辅助选出的网页子集；oracle_K、flat_K、aligned_K另提供金标准簇数。每页最多4000 Qwen tokens，截断逐页留痕。这不是完整原文的官方复现。失败按0计入全部1061题分母；答案和理由采用官方关键词匹配，并非语义正确性裁判。</p>')
  add('ConfRAG配对比较',table(['比较','题数/组数','指标','均值差','95%分组bootstrap区间'],[[k,str(v['n_questions'])+'/'+str(v['n_groups']),m,round(d['mean_delta'],4),d['95pct_paired_group_bootstrap']] for k,v in x['paired'].items() for m,d in v['metrics'].items()])+'<p>主对照为aligned-flat与aligned-raw的NMI；其余为诊断。2000次配对分组bootstrap，seed576；区间为边际区间，未作多重比较校正。模型仅一次固定解码种子；这些区间描述题目抽样不确定性，不衡量模型重复运行方差。</p>')
  add('ConfRAG结论','<p>aligned_K平均NMI为0.0953，flat_K为0.0970：差值−0.0017，95%配对分组区间[−0.0142, 0.0103]，未显示对齐优于平铺的证据。对比同样给定K的原文条件0.1284，对齐卡片低0.0331，区间[−0.0517, −0.0129]。这些结论限于当前截断/选页/7B配置；不能解释为所有结构化方法均无效。</p>')
 figures=[]
 for name,title in [('ramdocs_overview','RAMDocs完整分母比较'),('ramdocs_risk_coverage','系统声明完整回答的覆盖与风险'),('ramdocs_any_answer_risk','统一非空答案口径的覆盖与风险'),('confrag_representation','ConfRAG证据组织对照')]:
  if (ROOT/'analysis/figures'/(name+'.png')).exists():figures.append('<figure><img style="max-width:100%" src="../figures/'+name+'.png" alt="'+esc(title)+'"><figcaption>'+esc(title)+' · <a href="../figures/'+name+'.pdf">PDF</a></figcaption></figure>')
 if figures:add('结果图', ''.join(figures))
 p=ROOT/'planning/final_runtime_smoke.json'
 if p.exists():
  smoke=json.loads(p.read_text());add('最终新样例验证','<p>plain/full在一个新构造的字面事实样例上运行；输出数'+str(smoke['n_outputs'])+'，不同请求数'+str(smoke['request_count'])+'，字面答案匹配：'+esc(smoke['constructed_literal_answer_match'])+'，请求创建时间确认新生成：'+esc(smoke['all_requests_fresh_by_creation_time'])+'。综合检查passed='+esc(smoke['passed'])+'。本次plain答对、full失败：抽取quote前导空格不在原文导致丢卡，随后错误弃答。失败原样保留，不是已通过的功能release。它是新构造正控制，不是自然测试集或人工gold成绩；调用token另见planning/final_runtime_smoke.json。</p>')
 p=ROOT/'runs/output_budget_diagnostic_v1/analysis.json'
 if p.exists():
  diagnostic=json.loads(p.read_text());add('探索性生成预算诊断','<p>主实验结束后，从'+str(diagnostic['eligible_failed_JSON_requests'])+'条符合条件的失败JSON请求中，按固定哈希顺序选择'+str(diagnostic['n_selected'])+'条，只将输出上限加倍；其中'+str(diagnostic['complete_JSON_after_larger_cap'])+'条得到正常结束的完整JSON对象。新增比较所需prompt/output tokens：'+str(diagnostic['new_prompt_tokens'])+'/'+str(diagnostic['new_completion_tokens'])+'，另计于主运行台账之外。</p><p>这是已观察失败请求的探索性诊断，不是整体准确率提升。完整JSON不等于符合全部schema或语义正确；原始主实验失败、分数和分母均不变。批处理时序也可能不同，不能据此作严格单因素因果泛化。</p>')
 p=ROOT/'analysis/phase1/run_ledger.json'
 if p.exists():
  ledger=json.loads(p.read_text());add('调用成本与运行记录','<p>开发、历史失败与正式评估合计引用'+str(ledger['global_distinct_referenced_requests'])+'个不同缓存请求；去重prompt/output tokens：'+esc(ledger['global_tokens_without_double_count'])+'。各方法复用提取结果，因此不能把各run成本直接相加。模型、输入与解码设置固定，但各方法总调用预算不同；未另跑预算匹配版MADAM。</p><p><a href="run_ledger.csv">逐run成本和请求时间CSV</a> · <a href="run_ledger.json">完整台账与计费限制</a>。没有使用付费API；共享GPU的硬件费用未知。</p>')
 audits=[]
 for run in runs:
  p=ROOT/'runs'/run/'audit.json'
  if not p.exists():continue
  a=json.loads(p.read_text());audits.append([run,a['observed_outputs'],a['requested_outputs'],len(a['missing_cache']),len(a.get('error_outputs_without_trace',[])),len(a['bad_citations']),len(a['token_preflight_mismatches']),a['finish_reasons']])
 add('可追溯性审计',table(['运行','实有输出','应有输出','缺请求缓存','失败输出未附调用轨迹','错误精确引文','token预检偏差','停止原因'],audits)+'<p>输出完整不代表预测正确。model_output、parse_error、output_limit等失败均保留。原文ConfRAG适配器在解析失败前未写入request字段；通过重建完全相同的payload/hash从原缓存恢复链接，未重新调用模型，失败状态和分数保持不变。不同方法共享的提取请求只在全局成本中计一次；方法独立运行成本另行记录。共享GPU及批处理配置变化使实测时延不适合作为方法速度排名。</p>')
 for name,title in [('extraction_annotation_proxy','文档标注代理诊断'),('interval_natural_applicability','有界区间规则自然数据适用性')]:
  p=ROOT/'analysis'/(name+'.json')
  if p.exists():
   d=json.loads(p.read_text());d.pop('cases',None);add(title,'<pre style="white-space:pre-wrap">'+esc(json.dumps(d,ensure_ascii=False,indent=2))+'</pre>')
 add('裁决防护的实际边界','<p><a href="policy_diagnostics.json">逐条件防护与抽取日志诊断</a>：RAMDocs full有17题、CONFLICTS full有5题在非contradiction标签下接受答案且标记E1；这些不是经过独立验证的权威／修订裁决。两数据集full均没有接受答案且标记E2的案例，因此不能宣称集合约束在自然数据上已产生已验证收益。空对象抽取日志也不等同于抽取错误。</p>')
 add('逐题错误分析','<p><a href="casebook.html">固定规则抽样的成功／失败／弃答案例集</a>；<a href="error_taxonomy.json">全部500题自动诊断分类</a>。这是事后描述分析，自动标签不是人工确认的最早错误原因。</p>')
 add('复盘与下一步','<p><a href="qualitative_review.txt">26题agent复核、5例原文核对与下一轮改进顺序</a>；不作为人工gold。</p><p>第一轮发现并修复：数字答案解析、unknown覆盖统计、不完整结构化输出、失败调用追踪、部分回答与完整覆盖的区分。工程修复不算算法收益。字段证据范围采用同一文档内的独立精确片段，并保留限于答案引文的对照。MiniCheck阈值保持0.5；支持分数不代表世界真值。</p><p>E2裁决保留精确引文与条件规则，但当前是模型提出的论证加结构检查，不能称为形式证明。E1在预测为contradiction的分支会被拒绝；其他预测类别仍可能保留E1标签与答案，因此不是全局权威验证。自然数据人工评价、72B主模型、独立CONFLICTS回答评价是明确缺项；可选训练和第二模型未执行。最终报告与提交仍需后续核读。</p>')
 add('冻结与运行偏差','<p>v3的空对象提取兼容修复由合成压力样例触发，但旧版main-v2当时已短暂启动，因此不是严格的所有测试执行前冻结；旧结果和停止原因保留。最终方法没有根据测试预测修改提示、阈值或模型。ConfRAG卡片适配器的真实toy检查也晚于该适配器主运行启动，这一验证顺序偏差已记录。服务批容量依次为8序列/2048批token、16序列/4096批token、24序列/4096批token；全设备显存预算分别0.55/0.82/0.90；ConfRAG原文客户端并发从2调至8，已写出的结果逐个hash保留，最多2个未完成请求可能被原样重发。剩余主实验客户端从8调至24线程、MADAM从4调至8线程，已落盘输出逐个hash保留，最多12个未落盘调用可能原样重发。CONFLICTS结束后ConfRAG卡片客户端从8调至24线程，仅改变两个并发常量，已落盘输出哈希保留，最多8个未落盘请求可能重发。MADAM恢复时载入当前pipeline，AST核对确认只有未调用的extract分支不同。模型与解码设置不变，但不能保证不同批处理下逐token数值完全相同。</p>')
 add('复现入口','<p>已通过42项输入边界／评分／策略fixture；用匹配的归档源码对1000条baseline结果做缓存重放，科学输出字段一致。缓存重放没有新增模型推理，不等于独立重新生成。</p><p>代码：work/；固定版本：work/frozen/；协议：planning/protocols/；原始请求：runs/request_cache/v1/；每次运行含manifest、逐题JSON、progress，以及完成后生成的audit与analysis。<a href="reproduce.txt">完整复现命令</a>。所有失败保留；最终报告仍需人工核读。</p>')
 body='<!doctype html><html lang="zh"><meta charset="utf-8"><title>NLP576 实验阶段报告</title><style>body{max-width:1250px;margin:40px auto;padding:0 24px;font:16px/1.65 system-ui;color:#192d35}h1{font-size:30px}h2{margin-top:38px;font-size:22px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:8px;border:1px solid #ccd6da;text-align:left;vertical-align:top}th{background:#edf4f6}tr:nth-child(even){background:#fafcfc}</style><h1>NLP576 实验与复盘报告</h1>'+''.join(sections)+'</html>'
 (out/'report.html').write_text(body);write_json(out/'run_index.json',index);print(out/'report.html')
if __name__=='__main__':main()
