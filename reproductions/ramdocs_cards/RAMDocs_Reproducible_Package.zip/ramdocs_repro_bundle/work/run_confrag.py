import argparse,ast,hashlib,json,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from real_runtime import ROOT,Client,parse_json,write_json

def prompt(row,known):
 s=(ROOT/'materials/datasets/confrag/generateResult/TestPrompt.txt').read_text()
 if known:s=s.replace('[CLUSTERING NUMBER]',str(row['oracle_cluster_count']))
 else:
  s=s.replace('- A target number of clusters (clustering number)','- The number of distinct answers must be inferred from the supplied text.').replace('the required number of clusters','clusters').replace('You must create exactly [CLUSTERING NUMBER] clusters, no more, no fewer.','Infer the number of distinct supported answer clusters.').replace('// Continue until [CLUSTERING NUMBER] clusters are completed','// Continue until all indexes are grouped')
 return s+'\n## Question\n'+row['question']+'\n## Website Information\n'+json.dumps([{'index':d['index'],'website':d['text']} for d in row['documents']],ensure_ascii=False)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',required=True,type=Path);ap.add_argument('--limit',type=int);a=ap.parse_args();a.run.mkdir(parents=True,exist_ok=True)
 rows=[json.loads(l) for l in (ROOT/'materials/prepared/confrag_official_v1/inputs.jsonl').open()];rows=rows[:a.limit] if a.limit else rows
 c=Client();original_rows=rows;rows=[]
 for original in original_rows:
  r=dict(original);r['documents']=[];r['context_audit']=[]
  for d in original['documents']:
   tokens=c.tokenizer.encode(d['text'],add_special_tokens=False);kept=tokens[:4000]
   r['documents'].append(dict(d,text=c.tokenizer.decode(kept,skip_special_tokens=False) if len(tokens)>4000 else d['text']))
   r['context_audit'].append({'index':d['index'],'original_tokens':len(tokens),'retained_tokens':len(kept),'truncated':len(tokens)>4000})
  rows.append(r)
 contract={'ids':[r['question_id'] for r in rows],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'client_sha256':hashlib.sha256((ROOT/'work/real_runtime.py').read_bytes()).hexdigest(),'input_sha256':hashlib.sha256((ROOT/'materials/prepared/confrag_official_v1/inputs.jsonl').read_bytes()).hexdigest(),'methods':['oracle_K','unknown_K'],'max_output_tokens':1536,'workers':8,'document_token_cap':4000,'context_policy':'planning/protocols/confrag_context_policy_v2.json','model':'Qwen2.5-7B-Instruct-bf16'}
 if (a.run/'manifest.json').exists():assert json.loads((a.run/'manifest.json').read_text())==contract
 write_json(a.run/'manifest.json',contract)
 def one(r,known):
  method='oracle_K' if known else 'unknown_K';p=a.run/method/(r['question_id']+'.json')
  if p.exists():return json.loads(p.read_text())
  out={'question_id':r['question_id'],'method':method,'context_audit':r['context_audit']}
  try:
   raw=c.chat(prompt(r,known),1536,True);parsed=parse_json(raw['text'])
   assert isinstance(parsed.get('answers'),list)
   for g in parsed['answers']:assert isinstance(g['index'],list) and isinstance(g['answer'],str) and isinstance(g['reason'],list)
   out.update(status='ok' if raw['finish_reason']!='length' else 'output_limit',prediction=parsed,request={k:raw[k] for k in ('key','usage','latency_seconds','finish_reason')})
  except Exception as e:out.update(status='error',error=type(e).__name__+':'+str(e))
  write_json(p,out);return out
 n=0;errors=0;start=time.time()
 with ThreadPoolExecutor(8) as pool:
  futures=[pool.submit(one,r,k) for r in rows for k in (True,False)]
  for f in as_completed(futures):
   out=f.result();n+=1;errors+=out['status']!='ok'
   if n%20==0:print(n,len(futures),'errors',errors,'elapsed',time.time()-start,flush=True)
   write_json(a.run/'progress.json',{'completed':n,'total':len(futures),'errors':errors,'finished':n==len(futures),'elapsed':time.time()-start})
if __name__=='__main__':main()
