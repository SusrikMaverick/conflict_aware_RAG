"""Deterministic analysis; includes model failures in all denominators."""
import json,re,collections,hashlib,random,csv,html,time
from real_runtime import ROOT,write_json
from pipeline import LABELS,norm
from phase2.pipeline import repair_quote,validate_scope_audit
outdir=ROOT/'analysis/phase2';outdir.mkdir(parents=True,exist_ok=True)
allstats={};records=[];audit={'missing_cache':[],'invalid_citations':[],'invalid_repairs':[],'invalid_scope':[],'nonshared_extractions':[],'input_annotation_leakage':[]};cache={};variantkeys=collections.defaultdict(set)
for split in ['dev','check']:
 refs={r['question_id']:r for r in map(json.loads,(ROOT/f'materials/prepared/phase2_v2/{split}.eval.jsonl').read_text().splitlines())}
 inputs={r['question_id']:r for r in map(json.loads,(ROOT/f'materials/prepared/phase2_v2/{split}.inputs.jsonl').read_text().splitlines())}
 assert len(refs)==len(inputs)==36
 splitrecords=[]
 for q,row in inputs.items():
  if set(row)!={'question_id','question','documents'}:audit['input_annotation_leakage'].append(q)
  extractkeys={}
  for m in ['frozen','quote_fix','scope_guided']:
   p=ROOT/f'runs/phase2-v2-{split}/{m}/{q}.json';x=json.loads(p.read_text());ref=refs[q];docs={d['doc_id']:d['text'] for d in row['documents']};answers=x.get('accepted_answers',[]);text=' '.join(answers)
   found={a for a in ref['candidate_literals'] if re.search(r'(?<![A-Za-z0-9])'+re.escape(a)+r'(?![A-Za-z0-9])',text,re.I)}
   ok=x['status'] not in ['error','parse_error'];literal=ok and (found==set(ref['answers'])) and (bool(answers) if ref['answers'] else not answers and x['status']=='abstain')
   strict=ok and {norm(a) for a in answers}=={norm(a) for a in ref['answers']} and (bool(answers) if ref['answers'] else x['status']=='abstain')
   # Literal-compatible metric permits explanatory text; strict exact-set reported separately.
   for c in x.get('citations',[]):
    if c.get('doc_id') not in docs or not c.get('quote') or c['quote'] not in docs[c['doc_id']]:audit['invalid_citations'].append([q,m,c])
   for r in x.get('quote_repairs',[]):
    expected=repair_quote(r['raw_quote'],docs[r['doc_id']])
    if expected is None or any(r[k]!=v for k,v in expected.items()):audit['invalid_repairs'].append([q,m,r])
   sk=[];pt=ct=0
   for req in x.get('requests',[]):
    key=req['key'];variantkeys[(split,m)].add(key)
    if key not in cache:
     cp=ROOT/f'runs/request_cache/phase2_v2/{key}.json'
     if not cp.exists():audit['missing_cache'].append(key);continue
     cache[key]=json.loads(cp.read_text())
    raw=cache[key];prompt=raw['request']['messages'][0]['content']
    if prompt.startswith('Extract fact cards'):sk.append(key)
    pt+=req.get('usage',{}).get('prompt_tokens',0);ct+=req.get('usage',{}).get('completion_tokens',0)
   extractkeys[m]=sk
   scope=x.get('scope_audit',{});scopes=[]
   if scope.get('status')=='available':
    try:validate_scope_audit(scope['audit'],[c for c in x.get('cards',[]) if c['support_status']=='verified'],row['documents'])
    except Exception as e:audit['invalid_scope'].append([q,m,str(e)])
    scopes=[p['label'] for p in scope['audit']['pairs']]
   rec={'split':split,'variant':m,'question_id':q,'family':ref['family'],'status':x['status'],'error':x.get('error'),'literal_correct':int(literal),'strict_correct':int(strict),'any_accepted':int(bool(answers)),'wrong_candidate_accepted':int(bool(found-set(ref['answers']))),'relation_target':ref['relation'],'relation_prediction':x.get('relation'),'relation_correct':int(ok and ref['relation']==x.get('relation')) if ref['relation'] else None,'false_contradiction':int(x.get('relation')=='contradiction' and ref['relation'] not in ['contradiction',None]),'quote_repairs':len(x.get('quote_repairs',[])),'scope_available':int(scope.get('status')=='available'),'scope_correct_pairs':sum(t==ref['scope'] for t in scopes) if ref['scope'] else 0,'scope_scored_pairs':len(scopes) if ref['scope'] else 0,'verified_cards':sum(c['support_status']=='verified' for c in x.get('cards',[])),'uncertain_cards':sum(c['support_status']!='verified' for c in x.get('cards',[])),'extraction_issues':len(x.get('extraction_issues',[])),'requests':len(x.get('requests',[])),'prompt_tokens':pt,'completion_tokens':ct,'enforcement_reasons':x.get('enforcement_reasons',[]),'accepted_answers':answers}
   records.append(rec);splitrecords.append(rec)
  if not (extractkeys['frozen']==extractkeys['quote_fix']==extractkeys['scope_guided']):audit['nonshared_extractions'].append([q,extractkeys])
 stats={}
 for m in ['frozen','quote_fix','scope_guided']:
  rr=[r for r in splitrecords if r['variant']==m];f1=[];conf={}
  for label in LABELS:
   targets=[r for r in rr if r['relation_target'] is not None];tp=sum(r['relation_target']==label and r['relation_prediction']==label for r in targets);fp=sum(r['relation_target']!=label and r['relation_prediction']==label for r in targets);fn=sum(r['relation_target']==label and r['relation_prediction']!=label for r in targets);f1.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0);conf[label]={'tp':tp,'fp':fp,'fn':fn,'f1':f1[-1]}
  stats[m]={'n':len(rr),'literal_correct':sum(r['literal_correct'] for r in rr),'strict_correct':sum(r['strict_correct'] for r in rr),'relation_macro_f1':sum(f1)/len(f1),'relation_correct':sum(r['relation_correct'] or 0 for r in rr),'relation_n':sum(r['relation_target'] is not None for r in rr),'per_label':conf,'status':dict(collections.Counter(r['status'] for r in rr)),'errors':sum(r['status']=='error' for r in rr),'false_contradiction':sum(r['false_contradiction'] for r in rr),'wrong_candidate_accepted':sum(r['wrong_candidate_accepted'] for r in rr),'any_accepted':sum(r['any_accepted'] for r in rr),'quote_repairs':sum(r['quote_repairs'] for r in rr),'scope_available':sum(r['scope_available'] for r in rr),'scope_correct_pairs':sum(r['scope_correct_pairs'] for r in rr),'scope_scored_pairs':sum(r['scope_scored_pairs'] for r in rr),'total_prompt_tokens_logical':sum(r['prompt_tokens'] for r in rr),'total_completion_tokens_logical':sum(r['completion_tokens'] for r in rr),'logical_requests':sum(r['requests'] for r in rr),'unique_requests':len(variantkeys[(split,m)]),'family_correct':{f:sum(r['literal_correct'] for r in rr if r['family']==f) for f in sorted({r['family'] for r in rr})}}
 comparisons={};rng=random.Random(576)
 for a,b in [('quote_fix','frozen'),('scope_guided','quote_fix')]:
  ds=[]
  for family in sorted({r['family'] for r in splitrecords}):
   ar={r['question_id']:r for r in splitrecords if r['variant']==a and r['family']==family};br={r['question_id']:r for r in splitrecords if r['variant']==b and r['family']==family};ds.append(sum(ar[q]['literal_correct']-br[q]['literal_correct'] for q in ar)/len(ar))
  boot=sorted(sum(rng.choices(ds,k=len(ds)))/len(ds) for _ in range(5000))
  comparisons[a+'-minus-'+b]={'literal_accuracy_difference':sum(ds)/len(ds),'family_bootstrap_95_interval':[boot[124],boot[4874]],'n_family_groups':len(ds),'scope':'descriptive for constructed families, not natural population CI'}
 allstats[split]={'variants':stats,'paired_comparisons':comparisons}
assert len(records)==216
for name,h in json.loads((ROOT/'planning/protocols/phase2_v2.json').read_text())['hashes'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,name
unique_usage={k:sum(x.get('usage',{}).get(k,0) for x in cache.values()) for k in ['prompt_tokens','completion_tokens','total_tokens']}
audit.update(total_outputs=216,unique_requests=len(cache),actual_unique_usage=unique_usage,all_protocol_hashes_match=True,passed=not any(audit.values()))
write_json(outdir/'audit.json',audit);write_json(outdir/'summary.json',allstats);write_json(outdir/'per_question.json',records)
with (outdir/'per_question.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
check=allstats['check']['variants'];a=check['quote_fix'];b=check['frozen'];c=check['scope_guided']
decisions={'quote_fix':{'keep_as_engineering_repair':audit['passed'] and a['literal_correct']>=b['literal_correct'],'fresh_check_activations':a['quote_repairs'],'efficacy_demonstrated':a['quote_repairs']>0 and a['literal_correct']>b['literal_correct']},'scope_guided':{'passes_predeclared_gate':c['relation_macro_f1']>a['relation_macro_f1'] and c['literal_correct']>=a['literal_correct'] and c['false_contradiction']<=a['false_contradiction'] and c['errors']<=a['errors'],'natural_validation_required':True}}
write_json(outdir/'decisions.json',decisions)
print(json.dumps({'summary':allstats,'audit':audit,'decisions':decisions},indent=2))
