import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from audit_ramdocs import audit


def row(docs,gold=('10',),wrong=('20',)):
    return {'question':'synthetic audit question','documents':[{'text':'synthetic text','type':t,'answer':a} for t,a in docs],
            'gold_answers':list(gold),'wrong_answers':list(wrong),'disambig_entity':['entity'+str(i) for i in range(len(gold))]}


class AuditTests(unittest.TestCase):
    def test_candidate_votes_do_not_treat_two_wrong_candidates_as_one(self):
        r=audit([row([('correct','10'),('misinfo','20'),('misinfo','30')],wrong=('20','30'))])
        self.assertEqual(r['counts']['single_tie_candidates'],1)
        self.assertEqual(r['counts'].get('single_fake_ahead_candidates',0),0)

    def test_gold_wrong_overlap_is_not_wrong_only(self):
        r=audit([row([('correct','10'),('misinfo','10')],wrong=('10',))])
        self.assertEqual(r['per_question'][0]['wrong_only_normalized'],[])
        self.assertEqual(r['counts']['gold_wrong_overlap'],1)

    def test_missing_gold_not_in_positive_support_bound(self):
        r=audit([row([('misinfo','20')])])
        self.assertEqual(r['counts']['any_gold_not_ahead_including_missing'],1)
        self.assertEqual(r['counts'].get('any_positive_gold_not_ahead',0),0)
        self.assertEqual(r['counts'].get('single_with_fake_and_correct_doc',0),0)

    def test_multi_entity_candidates_remain_distinct(self):
        r=audit([row([('correct','10'),('correct','30'),('misinfo','20')],gold=('10','30'))])
        self.assertEqual(r['counts'].get('single_with_fake',0),0)
        self.assertEqual(len(r['per_question'][0]['gold_candidate_entity_annotations']),2)

    def test_unexpected_annotation_schema_rejected(self):
        r=row([('correct','10')]);r['documents'][0]['type']='unknown'
        with self.assertRaises(ValueError):audit([r])


if __name__=='__main__':unittest.main()
