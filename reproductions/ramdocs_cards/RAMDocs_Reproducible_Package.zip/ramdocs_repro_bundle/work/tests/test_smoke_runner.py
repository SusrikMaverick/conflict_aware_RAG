import sys
from pathlib import Path
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from run_smoke import run,validate_input

CONFIG={'backend':'mock','max_questions':2,'max_output_tokens':32,'max_requests':4,'max_attempts_per_question':2,'max_input_characters':2000}
ROW={'question_id':'unit-1','question':'Q','documents':[{'doc_id':'d1','text':'T','metadata':None}]}

class FailOnce:
    def __init__(self):self.calls=0
    def chat(self,messages,config):
        self.calls+=1
        if self.calls==1:raise TimeoutError('fake timeout')
        return {'text':'ok','usage':None,'is_model_inference':False}

class RunnerTests(unittest.TestCase):
    def test_resume_does_not_duplicate_success(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(run([ROW],CONFIG,d)['journal_attempts'],1)
            self.assertEqual(run([ROW],CONFIG,d)['journal_attempts'],1)

    def test_failure_retained_and_retry_succeeds(self):
        with tempfile.TemporaryDirectory() as d:
            b=FailOnce();first=run([ROW],CONFIG,d,b);second=run([ROW],CONFIG,d,b)
            self.assertEqual(first['errors'],1);self.assertEqual(second['ok'],1);self.assertEqual(second['journal_attempts'],2)

    def test_changed_config_refuses_resume(self):
        with tempfile.TemporaryDirectory() as d:
            run([ROW],CONFIG,d)
            with self.assertRaises(ValueError):run([ROW],{**CONFIG,'max_output_tokens':64},d)

    def test_benchmark_and_gold_input_rejected(self):
        with self.assertRaises(ValueError):validate_input({**ROW,'question_id':'ramdocs-0001'})
        with self.assertRaises(ValueError):validate_input({**ROW,'gold_answers':['secret']})

    def test_input_overflow_is_explicit_and_not_called(self):
        with tempfile.TemporaryDirectory() as d:
            r=run([ROW],{**CONFIG,'max_input_characters':1},d)
            self.assertEqual(r['errors'],1);self.assertEqual(r['requests_attempted'],0)

if __name__=='__main__':unittest.main()
