import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from prepare_data import adapt_ramdocs,adapt_conflicts,adapt_confrag,raw_example

class InputBoundaryTests(unittest.TestCase):
    def test_ramdocs_excludes_annotations_and_truth_tainted_ids(self):
        r={'question':'Q','documents':[{'text':'T','type':'misinfo','answer':'secret'}],'gold_answers':['secret'],'wrong_answers':['other'],'disambig_entity':['entity']}
        x=adapt_ramdocs(r,0)
        self.assertEqual(set(x['documents'][0]),{'doc_id','text','metadata'})
        self.assertNotIn('misinfo',x['documents'][0]['doc_id']);self.assertNotIn('gold_answers',x)

    def test_conflicts_uses_fixed_short_context(self):
        r={'question':'Q','search_results':[{'short_text':'visible','response_str':'full','url':'https://example.com','title':'T','date':'D'}],'conflict_type':'secret','correct_answer':'secret'}
        x=adapt_conflicts(r,0);self.assertEqual(x['documents'][0]['text'],'visible');self.assertNotIn('correct_answer',x)

    def test_confrag_drops_generated_trust_and_answer(self):
        r={'question':'Q','websites':[{'index':1,'content':'visible','website':'https://example.com','trust_score':10,'answer':'secret','reason':['secret']}],'answers':['secret']}
        x=adapt_confrag(r,0);self.assertEqual(x['documents'][0]['metadata'],{'url':'https://example.com'})

    def test_metadata_allowlist_rejects_truth_fields(self):
        with self.assertRaises(ValueError):raw_example('q','Q',[{'doc_id':'d','text':'T','metadata':{'trust_score':10}}])

if __name__=='__main__':unittest.main()
