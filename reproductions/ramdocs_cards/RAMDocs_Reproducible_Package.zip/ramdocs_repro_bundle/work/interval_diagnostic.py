"""Bounded symbolic E2 diagnostic: explicit alive-at-event requirement + stated lifespan.
This is a lexical applicability recognizer and integer checker, NOT general textual proof.
Only exact four-digit candidate years from verified cards are considered.
"""
import re

def interval_decision(row,cards):
    query=row['question'].lower()
    if not ('award' in query and ('in-person' in query or 'in person' in query)):return None
    candidates=[]
    for c in cards:
        if c.get('support_status')!='verified' or not re.fullmatch(r'\d{4}',c.get('answer','')):continue
        if not re.search(r'\b'+re.escape(c['answer'])+r'\b',c.get('quote','')):continue
        candidates.append(c)
    years={int(c['answer']) for c in candidates}
    if len(years)<2:return None
    rules=[];lifespans={}
    for d in row['documents']:
        t=d['text']
        if re.search(r'\b(?:award|ceremony)\b',t,re.I) and re.search(r'\b(?:must be alive|require\w*[^.;]{0,100}\balive)\b',t,re.I):
            if re.search(r'\b(?:not|never|no longer)\b',t,re.I):return {'status':'abstain','reason':'negated_or_conflicting_applicability','accepted_answers':[]}
            rules.append({'doc_id':d['doc_id'],'quote':t})
        for m in re.finditer(r"\b([A-Z][A-Za-z' -]{0,80}?) lived from (\d{4}) to (\d{4})",t):
            entity=m.group(1).strip();lo,hi=int(m.group(2)),int(m.group(3))
            if not re.search(r'\b'+re.escape(entity.lower())+r'\b',query):continue
            if not all(entity.lower() in (c.get('entity') or '').lower() for c in candidates):continue
            lifespans.setdefault(entity,[]).append((lo,hi,{'doc_id':d['doc_id'],'quote':m.group(0)}))
    if not rules or len(lifespans)!=1:return None
    entity,spans=next(iter(lifespans.items()));intervals={(lo,hi) for lo,hi,_ in spans}
    if len(intervals)!=1 or any(lo>hi for lo,hi in intervals):return {'status':'abstain','reason':'inconsistent_explicit_lifespans','accepted_answers':[]}
    lo,hi=next(iter(intervals));allowed={y for y in years if lo<=y<=hi};eliminated=years-allowed
    if len(allowed)!=1 or not eliminated:return {'status':'abstain','reason':'constraint_does_not_identify_unique_candidate','accepted_answers':[]}
    answer=str(next(iter(allowed)));support=next(c for c in candidates if c['answer']==answer)
    return {'status':'answered','relation':'contradiction','accepted_answers':[answer],'decision_basis':'E2_symbolic_interval','constraint':{'premises':rules+[x[2] for x in spans],'rule':f'Conditional on explicit alive-at-in-person-award rule: {lo} <= event_year <= {hi}','eliminated':list(map(str,sorted(eliminated))),'entity':entity,'closed_interval':[lo,hi]},'citations':[{'answer':answer,'doc_id':support['doc_id'],'quote':support['quote']}],'limitation':'conditional on lexical scope match and supplied premises; not world-truth certification'}
