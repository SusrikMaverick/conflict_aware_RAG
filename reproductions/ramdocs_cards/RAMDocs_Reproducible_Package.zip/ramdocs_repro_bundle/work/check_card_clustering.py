import json
from real_runtime import ROOT,Client,parse_json,write_json
from confrag_metrics import ns
c=Client();base=(ROOT/'materials/datasets/confrag/generateResult/TestPrompt.txt').read_text();cards=[{'doc_id':'web-'+str(i),'entity':'the fictional object','attribute':'color','answer':color,'quote':'The object is '+color+'.','support_status':'verified'} for i,color in enumerate(['blue','blue','red'])];out=[]
for mode in ('flat_K','aligned_K'):
 rep={'all_webpage_indices':[0,1,2]}
 if mode=='flat_K':rep['cards']=cards
 else:rep.update(evidence_map=[{'scope_key':['the fictional object','',''],'cards':cards}],uncertain_cards=[])
 text=base.replace('[CLUSTERING NUMBER]','2')+'\nThe webpage contents below are represented by fact cards. A doc_id web-N denotes webpage index N. A verified card is textually supported, not certified true. Uncertain cards cannot settle truth. Counts do not imply independent sources. Include all original webpage indexes, even when no useful card was extracted.\nQuestion: What color is the fictional object?\nEvidence: '+json.dumps(rep)
 r=c.chat(text,1536,True);pred=parse_json(r['text']);groups=[g['index'] for g in pred['answers']];out.append({'mode':mode,'request_key':r['key'],'prediction':pred,'partition':ns['bad_partition'](groups,[[0,1],[2]]),'NMI':ns['compute_soft_nmi']([[0,1],[2]],groups)})
write_json(ROOT/'planning/confrag_card_model_smoke.json',{'timing':'late adapter smoke after card benchmark execution began; does not inspect/use benchmark outputs','results':out});print(json.dumps(out));assert all(r['partition']=='Normal' for r in out)
