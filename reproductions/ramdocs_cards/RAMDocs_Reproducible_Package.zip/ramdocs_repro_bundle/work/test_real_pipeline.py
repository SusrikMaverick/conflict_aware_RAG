import unittest
from pipeline import Pipeline
from real_runtime import plain_parse
class RealContracts(unittest.TestCase):
    def setUp(self):
        self.p=Pipeline(None);self.row={'question_id':'toy','question':'year?','documents':[{'doc_id':'d1','text':'A occurred in 1901.'},{'doc_id':'d2','text':'A occurred in 2001.'}]}
    def answer(self):return {'relation':'contradiction','status':'answered','accepted_answers':['1901'],'citations':[{'answer':'1901','doc_id':'d1','quote':'A occurred in 1901.'}],'decision_basis':'majority'}
    def test_unresolved_cannot_win(self):self.assertEqual(self.p.validate(self.answer(),self.row)['accepted_answers'],[])
    def test_fabricated_quote_cannot_win(self):
        x=self.answer();x.update(relation='agreement',decision_basis='agreement');x['citations'][0]['quote']='invented';self.assertEqual(self.p.validate(x,self.row)['status'],'abstain')
    def test_uncertain_card_cannot_win(self):
        x=self.answer();x.update(relation='agreement',decision_basis='agreement');self.assertEqual(self.p.validate(x,self.row,[{'doc_id':'d1','support_status':'uncertain'}])['status'],'abstain')
    def test_e2_trace_required(self):
        x=self.answer();x['decision_basis']='E2';self.assertEqual(self.p.validate(x,self.row)['status'],'abstain')
    def test_disputed_not_scored(self):self.assertEqual(plain_parse('All Correct Answers: ["1901"]. Explanation: disputed 2001.'),['1901'])
    def test_format_failure_not_empty_answer(self):
        with self.assertRaises(ValueError):plain_parse('1901 maybe')
if __name__=='__main__':unittest.main()
