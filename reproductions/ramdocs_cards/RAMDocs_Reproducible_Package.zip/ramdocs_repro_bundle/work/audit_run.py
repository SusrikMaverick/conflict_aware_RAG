"""Read-only run integrity audit; every requested ID/method must be represented."""
import argparse,collections,hashlib,json
from pathlib import Path
from real_runtime import ROOT,write_json

def main():
 p=argparse.ArgumentParser();p.add_argument('run',type=Path);a=p.parse_args();m=json.loads((a.run/'manifest.json').read_text());ids=m.get('selected_ids',m.get('ids'));methods=m['methods'];missing=[];errors=[];request_keys=set();statuses=collections.Counter();trace_missing=[];citations=0;badcitations=[]
 input_path=ROOT/m['input'] if 'input' in m else ROOT/'materials/prepared/confrag_official_v1/inputs.jsonl'
 inputs={r['question_id']:r for r in map(json.loads,input_path.open())};outids=[]
 recovery_path=a.run/'recovered_request_links.json';recovered={};original_trace_missing=[]
 if recovery_path.exists():recovered={(r['method'],r['question_id']):r for r in json.loads(recovery_path.read_text())['links']}
 for method in methods:
  for q in ids:
   path=a.run/method/(q+'.json')
   if not path.exists():missing.append([method,q]);continue
   r=json.loads(path.read_text());assert r['question_id']==q and r['method']==method;outids.append((method,q));statuses[r['status']]+=1
   if r['status'] in ('error','parse_error','output_limit'):errors.append({'method':method,'id':q,'status':r['status'],'error':r.get('error')})
   calls=r.get('requests',[])
   if 'request' in r:calls=[r['request']]
   if not calls and r['status']=='error':original_trace_missing.append([method,q])
   if (method,q) in recovered:
    link=recovered[(method,q)];assert hashlib.sha256(path.read_bytes()).hexdigest()==link['output_sha256'];assert not calls
    calls=[link['request']]
   if not calls and r['status']=='error':trace_missing.append([method,q])
   for call in calls:request_keys.add(call['key'])
   docs={d.get('doc_id'):d['text'] for d in inputs[q]['documents']}
   for c in r.get('citations',[]):
    citations+=1
    if c['doc_id'] not in docs or not c.get('quote') or c['quote'] not in docs[c['doc_id']]:badcitations.append([method,q,c])
 token_counts=collections.Counter();finish=collections.Counter();missingcache=[];retries=0;tokenmismatch=[]
 for key in request_keys:
  p=ROOT/'runs/request_cache/v1'/(key+'.json')
  if not p.exists():missingcache.append(key);continue
  r=json.loads(p.read_text());token_counts.update({k:v for k,v in r['usage'].items() if k in ('prompt_tokens','completion_tokens','total_tokens')});finish[r['finish_reason']]+=1;retries+=r['attempts']-1
  if r['preflight_tokens']!=r['usage']['prompt_tokens']:tokenmismatch.append({'key':key,'preflight':r['preflight_tokens'],'actual':r['usage']['prompt_tokens']})
 out={'requested_outputs':len(ids)*len(methods),'observed_outputs':len(outids),'missing':missing,'duplicate_id_method':len(outids)-len(set(outids)),'statuses':dict(statuses),'errors':errors,'unique_referenced_model_requests':len(request_keys),'unique_request_tokens':dict(token_counts),'finish_reasons':dict(finish),'retries':retries,'missing_cache':missingcache,'error_outputs_without_trace':trace_missing,'exact_citations_checked':citations,'bad_citations':badcitations,'token_preflight_mismatches':tokenmismatch,'all_outputs_accounted':not missing and len(outids)==len(set(outids)),'note':'Cache requests shared across methods counted once here; method-level cost includes its required calls. Prefix-cache GPU compute saving not quantified. Errors stay in denominators.'}
 out.update(original_error_outputs_without_trace=original_trace_missing,recovered_exact_request_links=len(recovered),recovery_note='Exact cached request reconstruction only; original output statuses and scores unchanged.')
 write_json(a.run/'audit.json',out);print(json.dumps(out,indent=2))
if __name__=='__main__':main()
