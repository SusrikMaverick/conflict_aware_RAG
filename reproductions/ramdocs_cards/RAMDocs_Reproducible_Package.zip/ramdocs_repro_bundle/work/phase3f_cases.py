"""Retrospective case export; no prompt or frozen score changes."""
import collections,csv,json
from real_runtime import ROOT,write_json
p=json.loads((ROOT/'planning/phase3f/runtime2_freeze.json').read_text())
run=ROOT/p['run'];dataset='ramdocs'
inputs={r['question_id']:r for r in map(json.loads,(ROOT/p['datasets'][dataset]['input']).open())}
rows=list(csv.DictReader((run/dataset/'per_question_metrics.csv').open()))
scores={m:{r['question_id']:r for r in rows if r['method']==m} for m in p['methods']}
assert all(len(s)==500 for s in scores.values())
cases=[];counts=collections.Counter();bottlenecks=collections.Counter()
for q in sorted(inputs):
 outputs={m:json.loads((run/dataset/m/(q+'.json')).read_text()) for m in p['methods']}
 old,new=(int(scores[m][q]['official_compatible']) for m in ['F_C1','F_E'])
 change='gain' if new>old else 'loss' if new<old else 'tie';counts[change]+=1
 e=outputs['F_E'];verified=[c for c in e.get('cards',[]) if c['support_status']=='verified']
 if e.get('status')=='abstain':bottlenecks['abstain_with_verified_card' if verified else 'abstain_without_verified_card']+=1
 if change!='tie':
  cases.append({'question_id':q,'question':inputs[q]['question'],'change':change,'scores':{m:scores[m][q] for m in p['methods']},'outputs':outputs,'source_input':p['datasets'][dataset]['input']})
write_json(ROOT/'analysis/phase3f/ramdocs_changed_cases.json',{'role':'Exploratory retrospective, all changed cases; no human gold created','counts':dict(counts),'E_bottlenecks':dict(bottlenecks),'cases':cases})
print(dict(counts),dict(bottlenecks))
