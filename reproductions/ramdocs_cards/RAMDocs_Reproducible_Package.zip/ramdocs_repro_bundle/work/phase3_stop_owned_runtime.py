"""Stop only the verified project server and its recorded descendants, on host."""
import hashlib,json,os,signal,subprocess,time
from pathlib import Path
from real_runtime import ROOT,write_json
pid=int((ROOT/'logs/runtime/phase3f-server.pid').read_text());assert pid==1798205
def proc(p):
 try:
  base=Path('/proc')/str(p);s=(base/'stat').read_text().rsplit(')',1)[1].split()
  return {'pid':p,'state':s[0],'ppid':int(s[1]),'starttime':s[19],'uid':base.stat().st_uid}
 except (FileNotFoundError,ProcessLookupError):return None
root=proc(pid);assert root,'Expected host PID not visible; do not infer shutdown from sandbox namespace.'
cwd=(Path('/proc')/str(pid)/'cwd').resolve();args=(Path('/proc')/str(pid)/'cmdline').read_bytes().decode().split('\0')
assert cwd==ROOT and root['uid']==os.getuid()
assert 'vllm.entrypoints.openai.api_server' in args and str(ROOT/'models/Qwen2.5-7B-Instruct') in args
assert args[args.index('--port')+1]=='8576' and args[args.index('--served-model-name')+1]=='nlp576-qwen7b'
allproc={}
for d in Path('/proc').iterdir():
 if d.name.isdigit():
  try:r=proc(int(d.name))
  except PermissionError:continue
  if r:allproc[r['pid']]=r
owned={pid:root}
while True:
 new={p:r for p,r in allproc.items() if r['ppid'] in owned and p not in owned}
 if not new:break
 assert all(r['uid']==root['uid'] for r in new.values());owned.update(new)
def active(p):
 r=proc(p)
 return r is not None and r['starttime']==owned[p]['starttime'] and r['state'] not in ['Z','X']
def gpu():
 try:
  r=subprocess.run(['nvidia-smi','--query-gpu=index,memory.used','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=6)
  return {'returncode':r.returncode,'memory_csv':r.stdout.strip(),'error':r.stderr.strip()[:300]}
 except subprocess.TimeoutExpired:return {'error':'query_timeout'}
before=gpu();sent=[]
def send(p,sig):
 if active(p):os.kill(p,sig);sent.append([p,int(sig)])
send(pid,signal.SIGTERM)
deadline=time.monotonic()+15
while any(active(p) for p in owned) and time.monotonic()<deadline:time.sleep(.5)
for p in owned:send(p,signal.SIGTERM)
deadline=time.monotonic()+5
while any(active(p) for p in owned) and time.monotonic()<deadline:time.sleep(.5)
for p in owned:send(p,signal.SIGKILL)
time.sleep(2);remaining=[p for p in owned if active(p)]
out={'epoch':time.time(),'verified_server_pid':pid,'verified_cwd':str(cwd),'server_args_sha256':hashlib.sha256(json.dumps(args).encode()).hexdigest(),'recorded_owned_processes':list(owned.values()),'signals_sent':sent,'remaining_active_owned_pids':remaining,'passed':not remaining,'gpu_before':before,'gpu_after':gpu(),'scope':'Host identity and start-time guards; only own server and its recorded descendants signaled. Shared GPU totals are diagnostic.'}
write_json(ROOT/'planning/phase3_complete/runtime_release.json',out)
print(json.dumps(out,indent=2));assert out['passed']
