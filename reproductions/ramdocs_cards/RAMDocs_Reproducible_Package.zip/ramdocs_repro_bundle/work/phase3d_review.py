import json,hashlib
from real_runtime import ROOT,write_json
def main():
 p=ROOT/'analysis/phase3d/dev_v1';s=json.loads((p/'summary.json').read_text());v=s['variants'];b=v['quote_fix'];d=v['attributed_direct'];c=v['perdoc_C1'];g=v['graph_C1'];gates={}
 for m in ['perdoc_C0','perdoc_C1','graph_C1','attributed_direct']:
  a=v[m];gates[m]={'pair_f1_gain_ge10pp':a['pair_f1']-b['pair_f1']>=.1,'complete_gain_ge5pp':(a['complete']-b['complete'])/a['n']>=.05,'wrong_fraction_not_increased':a['wrong_prediction_fraction'] is not None and b['wrong_prediction_fraction'] is not None and a['wrong_prediction_fraction']<=b['wrong_prediction_fraction'],'errors_not_increased':a['errors']<=b['errors'],'source_audit':s['audit']['passed'],'strong_baseline_boundary':not(d['pair_f1']-a['pair_f1']>.05 and d['wrong_prediction_fraction']<=a['wrong_prediction_fraction'])}
 graphgate={'pair_f1_gain_ge3pp':g['pair_f1']-c['pair_f1']>=.03,'cost_le1point5x':g['tokens']<=1.5*c['tokens'],'wrong_fraction_not_increased':g['wrong_prediction_fraction']<=c['wrong_prediction_fraction']}
 gates['graph_C1'].update(graphgate)
 eligible=[m for m in gates if all(gates[m].values())];chosen=sorted(eligible,key=lambda m:(-v[m]['pair_f1'],-v[m]['complete'],v[m]['tokens']))[0] if eligible else None
 out={'gates':gates,'graph_gate':graphgate,'eligible':eligible,'selected':chosen,'new_method_claim':chosen not in [None,'attributed_direct'],'development_only':True}
 write_json(p/'decision.json',out);print(json.dumps(out,indent=2))
if __name__=='__main__':main()
