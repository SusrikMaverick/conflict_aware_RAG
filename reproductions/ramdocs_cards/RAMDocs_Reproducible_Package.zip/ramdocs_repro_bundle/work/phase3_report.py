"""Render reviewed development results; no model calls or result selection."""
import json,html,os
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'analysis/phase3'
s=json.loads((out/'dev_summary.json').read_text());a=json.loads((out/'audit.json').read_text());r=json.loads((out/'replay_audit.json').read_text())
assert a['passed'] and r['passed']
labels={'plain':'Plain RAG（原适配器）','quote_fix':'旧方法＋quote修复','context_envelope':'候选A：完整来源上下文'}
rows=[]
for m,v in s['variants'].items():
 vals=[labels[m],f"{v['exact_match_n']}/100",f"{v['answerable_em_n']}/50",f"{v['unanswerable_false_answers']}/50",f"{100*v['token_f1']:.2f}%",v['verified_cards'],v['errors'],f"{v['logical_prompt_tokens']+v['logical_completion_tokens']:,}"]
 rows.append('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in vals)+'</tr>')
body='''<!doctype html><html lang="zh"><meta charset="utf-8"><title>NLP576 阶段三 A 开发评估</title>
<style>body{max-width:1120px;margin:40px auto;padding:0 24px;font:17px/1.65 system-ui;color:#19212a}h1{font-size:30px}table{border-collapse:collapse;width:100%;font-size:15px}th,td{padding:10px;text-align:left;border-bottom:1px solid #ccd2d8}th{background:#edf2f6}.notice{padding:20px;background:#fff2d9;border-left:5px solid #9f6316}pre{white-space:pre-wrap;font:15px/1.7 system-ui}img{max-width:100%}a{color:#17569b}</style>
<h1>候选A开发轮：证据保留增加，回答效果未改善</h1>
<p>2026-11-03 America/Phoenix · 100个开发问题，3种方法，300条输出 · 未运行200个预留问题</p>
<div class="notice"><strong>结论：开发继续门槛未通过，A不进入独立确认、不替换默认方法。</strong><br>可答题仅多答对1题，不可答题净增加2次误答。完整阶段三、多文档冲突评测及最终提交仍未完成。</div>
<h2>数据与比较</h2><p>使用官方SQuAD 2.0训练集中的100个不同文章主题，每主题1题，50题可答、50题不可答。它是自然阅读理解/弃答组件研究，不是RAMDocs式多文档冲突测试。另留官方公开dev的200题（29主题），尚未运行。输入与评价标签分开，严格题目/段落/主题去重；语义别名和模型预训练接触未能排除。</p>
<p>A仅从原文恢复覆盖quote及字段证据的连续上下文，保持抽取请求、claim、验证阈值0.5和最终策略不变。25题的26张卡触发扩展。相同Qwen2.5-7B、种子和解码；两证据卡版本共享抽取请求。覆盖记录仅用于诊断，不影响回答。</p>
<h2>结果（含所有失败）</h2><table><thead><tr><th>方法</th><th>全体EM</th><th>可答EM</th><th>不可答误答↓</th><th>全体token F1</th><th>verified卡</th><th>错误</th><th>逻辑LLM tokens</th></tr></thead><tbody>'''+''.join(rows)+'''</tbody></table>
<p>A－旧方法：全体EM −1个百分点，开发集配对bootstrap 95%区间[−5,+3]个百分点；可答EM +2个百分点（要求≥5）；不可答误答 +4个百分点（要求≤2）。逻辑token +0.69%；每题仍2次生成请求。开发区间只描述本轮，不是独立确认。</p>
<p>Plain的9次解析失败全部计0，均正常停止而非长度截断。它与两证据卡方法的提示/预算不同，是参考基线。主因果对照是A与quote_fix。50/50采样下大量弃答可提高全体EM，因此必须同时看可答性能与不可答误答。</p>
<img src="metrics.png" alt="可答EM和不可答误答比较">
<h2>可复算性与证据边界</h2><p>300个输出已冻结hash；324个唯一生成请求与HTTP日志一致，共278,425实际生成请求tokens。75条上下文记录从原始响应精确重放，引用/offset/字段一致；18项接口与反例测试通过。旧9618主输出、3663检查点、217阶段二输出、源代码、同学快照和提交proposal保持不变。</p>
<p>第一次补充审计使用非唯一quote连接卡片，产生虚假告警；改为card_id后通过，初次记录保留。句子分割是启发式：Dell案例常规计4句、程序计3段。未改冻结实现；1600字符上限与精确连续原文成立，严格句数限制尚待新版本处理。</p>
<h2>完整复盘与下一步</h2><pre>'''+html.escape((out/'retrospective.txt').read_text())+'''</pre>
<h2>复现与材料</h2><ul><li><a href="dev_summary.json">指标和预注册门槛</a>；<a href="per_question.csv">逐题表</a>；<a href="casebook.json">100题原文、标注和输出</a></li><li><a href="audit.json">运行/来源审计</a>；<a href="replay_audit.json">原始响应重放审计</a></li><li><a href="../../planning/phase3/design.txt">设计与反例审查</a>；<a href="../../planning/phase3/component_protocol.txt">冻结开发协议</a>；<a href="../../planning/phase3/sample_size_limits.txt">样本量边界</a>；<a href="../../planning/phase3/next_iteration.txt">下一轮设计</a></li></ul>
<p>复算：在项目目录用 PYTHONPATH=work .venv/bin/python work/phase3_analyze.py，然后 phase3_audit.py；绘图/报告用 .analysis-venv/bin/python work/phase3_report.py。不要重跑phase3_run.py覆盖本轮；预留数据无推理输出。全文统计只用dev。</p>
<p>来源：<a href="https://rajpurkar.github.io/SQuAD-explorer/">SQuAD官方页面</a>；<a href="../../planning/phase3/related_work.txt">原文核读记录</a>。没有新增人工关系标注/IAA，没有建立原创性或完整冲突裁决有效性。</p></html>'''
(out/'report.html').write_text(body)
os.environ['MPLCONFIGDIR']=str(ROOT/'cache/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
names=['Plain','Quote fix','Context A'];colors=['#8197a8','#456a91','#b46c31']
for ax,key,title in zip(axes,['answerable_em_n','unanswerable_false_answers'],['Answerable exact match (higher is better)','Unanswerable false answer (lower is better)']):
 values=[s['variants'][m][key]*2 for m in labels]
 ax.bar(names,values,color=colors);ax.set_ylim(0,100);ax.set_ylabel('Percent (n = 50)');ax.set_title(title,fontsize=11)
 for i,v in enumerate(values):ax.text(i,v+2,f'{v:.0f}%',ha='center')
 ax.spines[['top','right']].set_visible(False)
fig.suptitle('SQuAD 2.0 component development: 100 questions / 300 outputs',fontsize=12)
fig.savefig(out/'metrics.png',dpi=180);fig.savefig(out/'metrics.svg');plt.close(fig)
print(out/'report.html')
