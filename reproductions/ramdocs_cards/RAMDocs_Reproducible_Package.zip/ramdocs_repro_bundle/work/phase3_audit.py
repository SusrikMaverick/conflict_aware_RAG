"""Post-run replay audit; no inference, threshold selection, or held-out outcomes."""
import json,hashlib,collections,copy,time
from real_runtime import ROOT,write_json,parse_json
from phase3.context import envelope
from phase2.pipeline import repair_quote

run=ROOT/'runs/phase3-grounding-dev-v1'
assert json.loads((run/'progress.json').read_text())['finished']
inputs={x['question_id']:x for x in map(json.loads,(ROOT/'materials/prepared/phase3_grounding_v1/dev.inputs.jsonl').read_text().splitlines())}
errors=[];checked=0;counts=collections.Counter();failures=[]
for q,row in inputs.items():
 docs={d['doc_id']:d['text'] for d in row['documents']}
 for method in ('plain','quote_fix','context_envelope'):
  x=json.loads((run/method/(q+'.json')).read_text())
  if x['status'] in ('error','parse_error'):
   failures.append({'question_id':q,'method':method,'status':x['status'],'error':x.get('error'),'request_keys':[r['key'] for r in x.get('requests',[])]})
  for r in x.get('context_records',[]):
   raw=json.loads((ROOT/f"runs/request_cache/phase3_dev_v1/{r['request_key']}.json").read_text())
   card=copy.deepcopy(parse_json(raw['text'])['cards'][r['card_index']])
   fixed=repair_quote(card.get('quote'),docs[r['doc_id']])
   if fixed:card['quote']=fixed['canonical_quote']
   expected=envelope(docs[r['doc_id']],card)
   actual={k:v for k,v in r.items() if k not in ('doc_id','card_index','request_key')}
   if actual!=expected:errors.append({'question_id':q,'record':r})
   counts[r['status']]+=1;checked+=1
   if r['status']=='expanded':
    counts['sentences_'+str(r['sentence_count'])]+=1
    # Accepted cards retain original semantic fields; only source quote can change.
    for c in x.get('cards',[]):
     if c['card_id']==f"{r['doc_id']}:c{r['card_index']}":
      if c['quote']!=r['quote']:errors.append({'question_id':q,'field':'quote'})
      for field in ('entity','sense_version','valid_time','attribute','answer','claim','field_evidence'):
       if c.get(field)!=card.get(field):errors.append({'question_id':q,'field':field})
hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(run.glob('*/*.json'))}
assert len(hashes)==300
write_json(ROOT/'planning/phase3/output_hashes.json',{'epoch':time.time(),'n_outputs':300,'sha256':hashes})
old=json.loads((ROOT/'planning/phase2_output_hashes.json').read_text())['sha256']
old_mismatch=[p for p,h in old.items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
freeze=json.loads((ROOT/'planning/protocols/phase2_v2.json').read_text())
code_mismatch=[p for p,h in freeze['hashes'].items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
out={'context_records_replayed':checked,'context_status_counts':dict(counts),'context_or_semantic_field_errors':errors,'phase2_outputs_checked':len(old),'phase2_output_mismatches':old_mismatch,'phase2_freeze_mismatches':code_mismatch,'model_failures':failures,'passed':not(errors or old_mismatch or code_mismatch)}
write_json(ROOT/'analysis/phase3/replay_audit.json',out);print(json.dumps(out,indent=2));assert out['passed']
