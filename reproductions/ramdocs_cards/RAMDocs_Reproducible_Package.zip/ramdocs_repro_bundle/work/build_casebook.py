"""Deterministic, post-evaluation casebook. Proxy flags are not human causal labels."""
import collections,hashlib,html,json
from pathlib import Path
from real_runtime import ROOT,write_json
from metrics import score,normalize
refs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/v1/ramdocs.evaluation.jsonl').open())}
inputs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/v1/ramdocs.inputs.jsonl').open())}
buckets=collections.defaultdict(list);flags_count=collections.Counter();records=[]
for p in sorted((ROOT/'runs/ramdocs-main-v3/full').glob('*.json')):
 r=json.loads(p.read_text());q=r['question_id'];ref=refs[q];m=score(r,ref['gold_answers'],ref['wrong_answers']);gold={normalize(a) for a in ref['gold_answers']};verified={normalize(c['answer']) for c in r.get('cards',[]) if c['support_status']=='verified'};allcards={normalize(c['answer']) for c in r.get('cards',[])}
 flags=[]
 if r['status']=='error':bucket='pipeline_error'
 elif m['official_compatible']:bucket='paper_compatible_correct'
 elif m['wrong_only_accepted']:bucket='accepted_wrong_only'
 elif r['status']=='answered':bucket='complete_but_metric_incorrect'
 elif r.get('accepted_answers'):bucket='partial_answer'
 elif verified&gold:bucket='abstention_with_exact_verified_gold'
 else:bucket='abstention_without_exact_verified_gold'
 if not gold<=allcards:flags.append('some_gold_not_exactly_extracted')
 if (gold&allcards)-verified:flags.append('some_exact_gold_card_unverified')
 if not r.get('accepted_answers') and verified&gold:flags.append('no_accepted_answer_despite_exact_verified_gold')
 if r.get('extraction_issues'):flags.append('extraction_issue_present')
 flags_count.update(flags)
 row={'question_id':q,'bucket':bucket,'flags':flags,'metrics':m,'status':r['status']};records.append(row);buckets[bucket].append(row)
selected=[]
for name,rs in sorted(buckets.items()):
 selected.extend(sorted(rs,key=lambda r:hashlib.sha256(('phase1-casebook-576|'+r['question_id']).encode()).hexdigest())[:4])
out=ROOT/'analysis/phase1';out.mkdir(exist_ok=True,parents=True)
write_json(out/'error_taxonomy.json',{'n':len(records),'bucket_counts':{k:len(v) for k,v in buckets.items()},'proxy_flag_counts':dict(flags_count),'selection':'Up to4 per disjoint bucket, SHA256 order with literal seed phase1-casebook-576; no cherry-picking','selected_ids':[r['question_id'] for r in selected],'limits':['Post-test descriptive analysis only; no changes to frozen method','Exact normalized answer matching misses aliases/units','Verified is source entailment, not world truth','Buckets and flags are automatic proxies, not human adjudicated earliest-error causes','extraction_issue_present includes logged empty-object normalization, which does not by itself establish a mistaken extraction'],'records':records})
parts=[]
for x in selected:
 q=x['question_id'];r=json.loads((ROOT/'runs/ramdocs-main-v3/full'/(q+'.json')).read_text());ref=refs[q];inp=inputs[q]
 payload={'question_id':q,'question':inp['question'],'bucket':x['bucket'],'automatic_flags':x['flags'],'gold_answers_evaluation_only':ref['gold_answers'],'wrong_answers_evaluation_only':ref['wrong_answers'],'prediction':{k:v for k,v in r.items() if k not in ('requests',)},'source_documents':inp['documents'],'raw_request_keys':[v['key'] for v in r.get('requests',[])]}
 parts.append('<h2>'+html.escape(q+' / '+x['bucket'])+'</h2><pre>'+html.escape(json.dumps(payload,ensure_ascii=False,indent=2))+'</pre>')
(out/'casebook.html').write_text('<!doctype html><meta charset="utf-8"><title>NLP576 deterministic casebook</title><style>body{max-width:1100px;margin:32px auto;font:15px/1.6 system-ui}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f7;padding:18px}h2{margin-top:45px}</style><h1>RAMDocs full：固定规则抽样案例集</h1><p>每类最多4题，SHA256固定排序。包括成功、错误、部分回答、弃答和接口失败；自动标记仅为诊断代理，未作人工因果编码。gold/wrong仅在事后评估显示。</p>'+''.join(parts))
print(json.dumps({'n':len(records),'buckets':{k:len(v) for k,v in buckets.items()},'selected':len(selected)}))
