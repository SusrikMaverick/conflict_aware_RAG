"""Offline metadata audit. Document answer/type annotations never enter model inputs.

Counts are annotation votes, not an entailment audit or estimated model errors.
Run from project root: .venv/bin/python work/audit_ramdocs.py
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import string

ROOT = Path(__file__).resolve().parents[1]
PUNCT = set(string.punctuation + '‘’“”–—')


def normalize(value):
    value = ''.join(ch for ch in value.lower() if ch not in PUNCT)
    return ' '.join(re.sub(r'\b(a|an|the)\b', ' ', value).split())


def question_id(index, row):
    return f'ramdocs-{index:04d}-' + hashlib.sha256(row['question'].encode()).hexdigest()[:12]


def audit(rows):
    counts, doc_types, fake_hist = Counter(), Counter(), Counter()
    strata, records = {}, []

    def record_stratum(key, flag, qid):
        strata.setdefault(key, [])
        if flag:
            counts[key] += 1
            strata[key].append(qid)

    for i, row in enumerate(rows):
        if set(row) != {'question', 'documents', 'gold_answers', 'wrong_answers', 'disambig_entity'}:
            raise ValueError(f'Unexpected row schema at {i}')
        if len(row['gold_answers']) != len(row['disambig_entity']):
            raise ValueError(f'Unaligned gold/entity annotation lists at {i}')
        docs = row['documents']
        for doc in docs:
            if set(doc) != {'text', 'type', 'answer'} or doc['type'] not in {'correct', 'noise', 'misinfo'}:
                raise ValueError(f'Unexpected document schema at {i}')
            if not all(isinstance(doc[k], str) for k in doc):
                raise ValueError(f'Unexpected document value type at {i}')
        qid = question_id(i, row)
        types = Counter(d['type'] for d in docs)
        doc_types.update(types)
        counts['questions'] += 1
        counts['documents'] += len(docs)
        has_fake = types['misinfo'] > 0
        single = len(row['gold_answers']) == 1
        correct = Counter(normalize(d['answer']) for d in docs if d['type'] == 'correct')
        fake = Counter(normalize(d['answer']) for d in docs if d['type'] == 'misinfo')
        votes = correct + fake
        gold = set(map(normalize, row['gold_answers']))
        wrong = set(map(normalize, row['wrong_answers'])) - gold
        max_wrong = max((votes[a] for a in wrong), default=0)
        minimum_gold = min((votes[a] for a in gold), default=0)
        if has_fake:
            fake_hist[str(types['misinfo'])] += 1
        record_stratum('has_fake', has_fake, qid)
        record_stratum('single_with_fake', has_fake and single, qid)
        record_stratum('single_with_fake_and_correct_doc', has_fake and single and types['correct'] > 0, qid)
        record_stratum('single_fake_no_correct_doc', has_fake and single and types['correct'] == 0, qid)
        eligible = has_fake and single and types['correct'] > 0
        record_stratum('single_tie_candidates', eligible and minimum_gold == max_wrong, qid)
        record_stratum('single_candidate_1_vs_1', eligible and minimum_gold == max_wrong == 1, qid)
        record_stratum('single_candidate_2_vs_2', eligible and minimum_gold == max_wrong == 2, qid)
        record_stratum('single_fake_ahead_candidates', eligible and minimum_gold < max_wrong, qid)
        record_stratum('single_raw_doc_1_vs_1', eligible and types['correct'] == types['misinfo'] == 1, qid)
        record_stratum('any_positive_gold_not_ahead', has_fake and any(0 < votes[a] <= max_wrong for a in gold), qid)
        record_stratum('any_gold_not_ahead_including_missing', has_fake and any(votes[a] <= max_wrong for a in gold), qid)
        record_stratum('all_gold_present_any_not_ahead', has_fake and all(votes[a] > 0 for a in gold) and any(votes[a] <= max_wrong for a in gold), qid)
        record_stratum('gold_wrong_overlap', bool(gold & set(map(normalize, row['wrong_answers']))), qid)
        record_stratum('more_than_two_fake_docs', types['misinfo'] > 2, qid)
        record_stratum('missing_gold_support', any(votes[a] == 0 for a in gold), qid)
        candidate_entities = {}
        for entity, answer in zip(row['disambig_entity'], row['gold_answers']):
            candidate_entities.setdefault(normalize(answer), []).append(entity)
        records.append({
            'question_id': qid, 'row_index': i, 'document_types': dict(types),
            'annotation_votes': dict(votes), 'correct_annotation_votes': dict(correct),
            'misinfo_annotation_votes': dict(fake), 'gold_normalized': sorted(gold),
            'wrong_only_normalized': sorted(wrong), 'max_wrong_only_votes': max_wrong,
            'gold_candidate_entity_annotations': candidate_entities,
            'entity_mapping_status': 'gold list positional association only; per-document entity not provided; wrong-only entity unknown',
            'entity_vote_warning': 'Global multi-entity candidate comparisons are diagnostics only, never adjudication evidence.',
        })
    comparisons = [
        {'reported':243,'metric':'has_fake','observed':counts['has_fake'],'interpretation':'matches'},
        {'reported':54,'metric':'single_with_fake_and_correct_doc','observed':counts['single_with_fake_and_correct_doc'],'interpretation':'matches only after excluding 2 questions with no correct-typed document; raw single+fake total is 56'},
        {'reported':24,'metric':'single_tie_candidates','observed':counts['single_tie_candidates'],'interpretation':'24 ties includes 19 candidate 1:1 and 5 candidate 2:2; raw doc 1:1 count is 17'},
        {'reported':2,'metric':'single_fake_ahead_candidates','observed':counts['single_fake_ahead_candidates'],'interpretation':'matches in the 54-question subset'},
        {'reported':159,'metric':'any_positive_gold_not_ahead','observed':counts['any_positive_gold_not_ahead'],'interpretation':'matches with positive-support restriction and strongest wrong-only candidate; cross-entity comparison is not an impossibility proof'},
    ]
    return {'counts':dict(counts),'document_type_counts':dict(doc_types),'fake_document_histogram':dict(fake_hist),
            'strata_question_ids':strata,'reported_comparisons':comparisons,
            'definitions':{
                'vote':'One document answer annotation after frozen normalization; noise excluded; not substring occurrences or semantic support verification.',
                'wrong_only':'normalized wrong_answers minus normalized gold_answers; prevents penalizing overlap as wrong-only',
                'any_positive_gold_not_ahead':'At least one gold candidate has >0 and <= max wrong-only annotation votes among documents, within questions containing misinfo.',
                'provenance':'No source/url/authority/revision metadata in provided document schema.',
                'entity_limit':'Per-document entity cannot be reconstructed from schema alone; wrong-only candidates cannot be assigned to entities without separate semantic annotation.',
                'benchmark_exposure':'Aggregate metadata audit only; no benchmark inference or prompt selection.'},
            'per_question':records}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data',type=Path,default=ROOT/'materials/datasets/ramdocs/RAMDocs_test.jsonl')
    p.add_argument('--out',type=Path,default=ROOT/'analysis/data_audit')
    args=p.parse_args();raw=args.data.read_bytes()
    rows=[json.loads(s) for s in raw.decode().splitlines() if s.strip()]
    result=audit(rows); args.out.mkdir(parents=True,exist_ok=True)
    records=result.pop('per_question')
    result['data_sha256']=hashlib.sha256(raw).hexdigest()
    result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['fixed_revision']='9c041bfd158c603b615883d9a931b00cbc141494'
    (args.out/'data_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    (args.out/'annotation_votes.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
    print(json.dumps({k:result[k] for k in ['counts','document_type_counts','fake_document_histogram','reported_comparisons']},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
