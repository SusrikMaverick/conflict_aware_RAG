"""Build actual-run records without confusing cached evaluations with new generations."""
import collections,csv,datetime,json
from pathlib import Path
from zoneinfo import ZoneInfo
from real_runtime import ROOT,write_json
names=['real-pilot20-v1','real-pilot20-v1_1','real-pilot20-v1_2','real-pilot20-v1_3','real-pilot20-v2','real-pilot20-v3','constructed-oracle20-v2','stress39-v2','stress39-v3','ramdocs-main-v2','ramdocs-baselines-v1','ramdocs-main-v3','ramdocs-madam-v1','conflicts-main-v3','confrag-bounded-v1','confrag-cards-v3']
rows=[];global_keys=set();cache=ROOT/'runs/request_cache/v1'
for name in names:
 d=ROOT/'runs'/name
 if not d.exists():continue
 outputs=[];keys=set();statuses=collections.Counter();times=[];tokens=collections.Counter()
 for p in d.glob('*/*.json'):
  r=json.loads(p.read_text())
  if 'question_id' not in r or 'method' not in r:continue
  outputs.append(r);statuses[r['status']]+=1
  requests=r.get('requests',[])
  if r.get('request'):requests=[r['request']]
  keys.update(x['key'] for x in requests)
 recovery=d/'recovered_request_links.json'
 if recovery.exists():keys.update(x['request']['key'] for x in json.loads(recovery.read_text())['links'])
 for key in keys:
  p=cache/(key+'.json')
  if not p.exists():continue
  r=json.loads(p.read_text());times.append(r['response']['created']);tokens.update({k:r['usage'].get(k,0) for k in ['prompt_tokens','completion_tokens']})
 global_keys.update(keys)
 progress=json.loads((d/'progress.json').read_text()) if (d/'progress.json').exists() else {}
 audit=json.loads((d/'audit.json').read_text()) if (d/'audit.json').exists() else {}
 state='已停止／排除主比较' if (d/'ABORTED.json').exists() else ('已完成（含失败）' if progress.get('finished') else '进行中')
 metric_path=(ROOT/'runs/ramdocs-combined-v3/analysis.json') if name in ['ramdocs-baselines-v1','ramdocs-main-v3','ramdocs-madam-v1'] else d/'analysis.json'
 metric_text=[]
 if metric_path.exists():
  data=json.loads(metric_path.read_text()).get('methods',{})
  for method in sorted({r['method'] for r in outputs}):
   v=data.get(method,{})
   vals={k:round(v[k],4) for k in ['official_compatible','NMI','answerScore','reasonScore','relation_accuracy','fixed8_macro_f1','answered'] if isinstance(v.get(k),(int,float))}
   if vals:metric_text.append(method+' n='+str(v.get('n'))+' '+json.dumps(vals))
 timerange='缓存请求创建America/Phoenix：'+(' → '.join(datetime.datetime.fromtimestamp(t,ZoneInfo('America/Phoenix')).isoformat() for t in [min(times),max(times)]) if times else '无可读请求时间')+'；复用请求可能早于本run'
 experiment=('DEV（构造oracle，非E05人工gold）' if 'oracle' in name else 'E11/E14（构造诊断）' if 'stress' in name else 'DEV' if 'pilot' in name else 'E12' if 'confrag' in name else 'E09' if 'madam' in name else 'E01/E10（closed-book）' if 'baselines' in name else 'E01/E02/E06' if 'conflicts' in name else 'E02/E03/E04/E06/E07')
 rows.append([experiment,name,name+' / seed576','固定Qwen2.5-7B BF16；该run manifest/source hash为准',str(len({r['question_id'] for r in outputs}))+'题 / '+str(len(outputs))+'输出',timerange,json.dumps(dict(statuses),ensure_ascii=False)+'\n'+'\n'.join(metric_text),'唯一引用请求'+str(len(keys))+'；prompt/output tokens '+str(tokens['prompt_tokens'])+'/'+str(tokens['completion_tokens'])+'；非独占GPU时延',str(d.relative_to(ROOT)),('输出/缓存/引文范围审计通过，trace缺项另见audit' if audit.get('all_outputs_accounted') and not audit.get('missing_cache') and not audit.get('bad_citations') else '见该run审计/历史偏差')+'；失败不删除；构造例非人工gold',state])
alltokens=collections.Counter();epochs=collections.Counter();transition=json.loads((ROOT/'planning/runtime_epoch_b.json').read_text())['healthy_epoch'];transition_c=json.loads((ROOT/'planning/runtime_epoch_c.json').read_text())['healthy_epoch']
for key in global_keys:
 p=cache/(key+'.json')
 if p.exists():
  r=json.loads(p.read_text());alltokens.update({k:r['usage'].get(k,0) for k in ['prompt_tokens','completion_tokens']});epochs['C' if r['response']['created']>=transition_c else ('B' if r['response']['created']>=transition else 'A')]+=1
out={'rows':rows,'global_distinct_referenced_requests':len(global_keys),'global_tokens_without_double_count':dict(alltokens),'serving_epoch_request_counts':dict(epochs),'limits':['Includes historical development and aborted-run evidence, not only final benchmark cost','Shared requests are counted once globally; method/run standalone costs overlap','Orphaned HTTP requests interrupted during concurrency transition may not be persisted; hardware utilization cost not estimated','No paid API used; electricity/hardware charge unknown, not claimed zero']}
write_json(ROOT/'analysis/phase1/run_ledger.json',out)
with (ROOT/'analysis/phase1/run_ledger.csv').open('w') as f:
 writer=csv.writer(f);writer.writerow(['experiment','description','run_and_seed','model_and_code','n','cached_request_creation_interval','statuses','cost','path','audit','state']);writer.writerows(rows)
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
