import json,hashlib,time
from real_runtime import ROOT,Client,write_json
from pipeline import Verifier
from phase3e.method_v2 import BoundQuestion
from phase3f_v2 import Transfer
p=json.loads((ROOT/'planning/phase3e/check_freeze_v2.json').read_text())
for f,h in p['hashes'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
c=Client();c.cache=ROOT/'runs/request_cache/phase3_smoke_v1';c.cache.mkdir(exist_ok=True);v=Verifier();v.cache=ROOT/'runs/verifier_cache/phase3_smoke_v1';v.cache.mkdir(exist_ok=True)
row=json.loads((ROOT/'materials/prepared/reproduction_smoke_v1.inputs.jsonl').read_text().splitlines()[0]);outputs={}
for m,pipe in [('E_component',BoundQuestion(c,v)),('F_E_collection',Transfer(c,v,True))]:
 try:out=pipe.run(row,'full' if m=='F_E_collection' else m)
 except Exception as e:out={'status':'error','error':str(e),'requests':getattr(pipe.local,'trace',[])}
 outputs[m]=out
write_json(ROOT/'runs/phase3-final-smoke/results.json',{'epoch':time.time(),'input':row,'expected':'WILLOW-731','outputs':outputs,'passed':{m:any('WILLOW-731' in s for s in out.get('accepted_answers',[])) for m,out in outputs.items()},'role':'known observed functional regression, not independent efficacy evidence'})
print({m:out.get('accepted_answers',out.get('error')) for m,out in outputs.items()})
