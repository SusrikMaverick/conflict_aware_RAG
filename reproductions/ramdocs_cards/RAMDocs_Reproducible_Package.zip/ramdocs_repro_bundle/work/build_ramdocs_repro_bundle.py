"""Assemble the self-contained saved-experiment replay bundle; no weights."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'deliverables/ramdocs_repro_bundle'
DEST.mkdir(parents=True, exist_ok=True)
paths = set()
def add(path):
    source = ROOT / path
    assert source.is_file(), source
    target = DEST / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)  # Dereference source symlinks, including baseline outputs.
    paths.add(str(path))

for name in ['experiments/ramdocs_cards/experiment.py', 'experiments/ramdocs_cards/README.txt',
             'materials/prepared/v1/ramdocs.inputs.jsonl', 'materials/prepared/v1/ramdocs.evaluation.jsonl',
             'analysis/plain_plus_cards_v1/summary.json', 'analysis/plain_plus_cards_v1/paired.json',
             'deliverables/Conflict_Aware_RAG_Simple_Report.pdf', 'models/Qwen2.5-7B-Instruct/download_manifest.json']:
    add(name)
protocol = json.loads((ROOT / 'planning/plain_plus_cards_v1/protocol.json').read_text())
for name in protocol['hashes']:
    add(name)
for folder, pattern in [('planning/plain_plus_cards_v1','*.json'), ('runs/plain_plus_cards_v1/outputs','*.json'),
                        ('runs/plain_plus_cards_v1/request_cache','*.json'), ('experiments/ramdocs_cards/results','*'),
                        ('work','*.py'), ('conflict_aware_RAG/src','*.py')]:
    for path in sorted((ROOT / folder).rglob(pattern)):
        if path.is_file() and '__pycache__' not in path.parts:
            add(path.relative_to(ROOT))
for name in ['README.md','config.json','generation_config.json','merges.txt','tokenizer.json','tokenizer_config.json','vocab.json']:
    add('models/Qwen2.5-7B-Instruct/' + name)
(DEST / 'requirements-replay.txt').write_text('numpy==2.2.6\n')
(DEST / 'requirements-inference.txt').write_text('numpy==2.2.6\nvllm==0.8.5.post1\ntransformers==4.51.3\nhuggingface-hub==0.30.2\ntokenizers==0.21.1\ntorch==2.6.0\n')
(DEST / 'start_model.sh').write_text('''#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export HF_HOME="$PWD/.cache/huggingface" XDG_CACHE_HOME="$PWD/.cache"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
exec .inference-venv/bin/python -m vllm.entrypoints.openai.api_server \\
  --model "$PWD/models/Qwen2.5-7B-Instruct" --served-model-name nlp576-qwen7b \\
  --host 127.0.0.1 --port 8576 --dtype bfloat16 --max-model-len 32768 \\
  --gpu-memory-utilization 0.65 --max-num-seqs 24 --max-num-batched-tokens 8192 \\
  --seed 576 --disable-log-requests
''')
(DEST / 'README.txt').write_text('''RAMDocs reproducibility bundle -- START HERE
===========================================

Included: all 500 questions and evaluation annotations, 1,908 saved evidence
cards in their source results, frozen prompts/protocol, both methods' 1,000
original outputs, 500 augmented raw request/response records, required source
files, tokenizer files, CSVs, and the English PDF report. Baseline symlinks
are converted to regular files. No original server paths are needed for replay.

A. REPLAY SAVED RESULTS (no GPU, no model weights)
------------------------------------------------
From this extracted folder, with Python 3.12 on Linux x86_64:
  python3.12 -m venv .replay-venv
  .replay-venv/bin/python -m pip install --no-index --find-links wheels -r requirements-replay.txt
  .replay-venv/bin/python experiments/ramdocs_cards/experiment.py verify
  .replay-venv/bin/python experiments/ramdocs_cards/experiment.py export

The included NumPy wheel supports CPython 3.12 / Linux x86_64 (glibc >= 2.17).
For other supported Python/platform combinations, replace the offline install
with an online pip install -r requirements-replay.txt in your new environment.
Expected: 500 identical prompts/parses; all metrics/bootstrap identical.
CSV: experiments/ramdocs_cards/results/summary.csv and per_question.csv.
Official score 76/500 -> 124/500; strict answer-set 65/500 -> 88/500.
Gold/fake annotations are scoring-only; they are not inserted into prompts.

B. NEW MODEL INFERENCE (optional; GPU + online downloads required)
----------------------------------------------------------------
Weights are about 15 GB and are NOT included. Linux, a compatible NVIDIA
driver/CUDA setup, and sufficient free GPU memory are required. Our original
run used a 46-GB GPU; the supplied launch arguments are not a minimum-VRAM claim.
Create a separate environment; do not install into an existing conda environment:
  python3.12 -m venv .inference-venv
  .inference-venv/bin/python -m pip install -r requirements-inference.txt
  .inference-venv/bin/python work/download_public_model.py --repo Qwen/Qwen2.5-7B-Instruct --revision a09a35458c702b33eeacc393d103063234e8bc28 --out models/Qwen2.5-7B-Instruct
  CUDA_VISIBLE_DEVICES=0 bash start_model.sh

In a second terminal, from this folder:
  .inference-venv/bin/python experiments/ramdocs_cards/experiment.py run --out runs/new_cards_run
This regenerates augmented answers from the frozen saved cards and compares
them with the bundled original Plain outputs. It does not re-extract cards.
Existing completed outputs are skipped; use a different output directory for
a new run. Raw responses and CSVs are saved under the chosen directory.

To regenerate BOTH Plain and augmented answers:
  .inference-venv/bin/python rerun_both.py --out runs/new_both_run

Inference settings match the recorded model/decoder configuration. New hardware,
batching, drivers or dependencies may change outputs. Installation and fresh
GPU inference have not been tested on another machine. Only isolated, offline
saved-result replay is verified in this delivery. The inference requirements
pin the core observed packages, not every transitive package/driver.

C. SCOPE AND FILES
------------------
The current method is original documents + ALL saved cards, without verification
filtering, relation decisions, voting or forced abstention. Twenty questions
have no saved cards (including four prior errors); all 500 remain included.
Original extraction code and its local Python dependencies are included for
inspection under work/. Regenerating extraction/older full pipelines is NOT
part of the two commands above; those older pipelines also need their own
verifier model/data. They are not required to reproduce this frozen comparison.
The single-source diagnostic is omitted from the report and current workflow.
Old research sources are preserved unchanged to satisfy frozen source hashes;
use ONLY the documented current entrypoint, not historical server scripts.

Report: deliverables/Conflict_Aware_RAG_Simple_Report.pdf
Provenance: planning/plain_plus_cards_v1/protocol.json and audit.json.
FILE_HASHES.json lists packaged scientific/code files; REPLAY_TEST.json records
the isolated replay check. Raw records and scoring functions preserve the
original metric limitations. No claim of semantic truth or reliable conflict
resolution is made from these exploratory scores.
''')
(DEST / 'rerun_both.py').write_text('''"""Optional new Plain + augmented generation; preserves bundled original results."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('experiment', ROOT/'experiments/ramdocs_cards/experiment.py')
e = importlib.util.module_from_spec(spec); spec.loader.exec_module(e)
p = argparse.ArgumentParser(); p.add_argument('--out', type=Path, required=True); args = p.parse_args()
e.verify()
plain = args.out/'plain'; cards = args.out/'outputs'
assert not plain.resolve().is_relative_to((ROOT/'runs/ramdocs-combined-v3').resolve())
assert not args.out.resolve().is_relative_to((ROOT/'runs/plain_plus_cards_v1').resolve())
c = e.Client(); c.cache = args.out/'plain_request_cache'; c.cache.mkdir(parents=True, exist_ok=True)
def one(row):
    q = row['question_id']; dest = plain/(q+'.json')
    if dest.exists(): return
    out = dict(question_id=q, method='plain', accepted_answers=[])
    try:
        docs = '\\n'.join(f"Document {i}: {d['text']}" for i,d in enumerate(row['documents'],1))
        r = c.chat(e.load_plain_prompt().format(question=row['question'],documents=docs),128,False,1.05)
        out.update(e.parsed(r['text']),raw_output=r['text'],finish_reason=r['finish_reason'],
                   requests=[{k:r[k] for k in ('key','usage','latency_seconds','finish_reason','cache_hit')}])
    except Exception as exc:
        out.update(status='error',error=str(exc),error_kind='context_overflow' if str(exc).startswith('context_overflow') else 'infrastructure')
    e.write_json(dest,out)
with ThreadPoolExecutor(max_workers=24) as pool: list(pool.map(one,e.inputs()))
e.generate(cards)
e.BASELINE = plain
e.export(cards,args.out/'results')
print(args.out/'results')
''')
all_files = sorted(p for p in DEST.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ['FILE_HASHES.json','REPLAY_TEST.json'])
hashes = {str(p.relative_to(DEST)):hashlib.sha256(p.read_bytes()).hexdigest() for p in all_files}
(DEST/'FILE_HASHES.json').write_text(json.dumps(hashes,indent=2)+'\n')
assert all((DEST/name).is_file() and hashlib.sha256((DEST/name).read_bytes()).hexdigest()==sha for name,sha in protocol['hashes'].items())
print(json.dumps({'folder':str(DEST),'files':len(hashes),'bytes':sum(p.stat().st_size for p in all_files)},indent=2))
