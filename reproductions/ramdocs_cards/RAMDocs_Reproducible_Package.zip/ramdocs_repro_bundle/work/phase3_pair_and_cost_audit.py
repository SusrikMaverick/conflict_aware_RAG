"""Check actual source-card equality and completed non-cache request accounting."""
import collections,json
from real_runtime import ROOT,write_json
FIELDS=['answer','entity','scope','claim','source_ids','quote','span_start','span_end','doc_id','card_id']
def signature(out):return [{k:c.get(k) for k in FIELDS} for c in out.get('cards',[])]
p=json.loads((ROOT/'planning/phase3f/runtime2_freeze.json').read_text());run=ROOT/p['run'];counts=collections.Counter();differences=[];fresh=collections.Counter();fresh_tokens=0;cached_calls=0;n=0
for d,info in p['datasets'].items():
 for row in map(json.loads,(ROOT/info['input']).open()):
  q=row['question_id'];a,b=[json.loads((run/d/m/(q+'.json')).read_text()) for m in ['F_C1','F_E']];n+=2
  counts[d+'/pairs']+=1
  if a['status']=='error' or b['status']=='error':counts[d+'/pair_has_error_no_card_comparison']+=1
  elif signature(a)==signature(b):counts[d+'/same_actual_source_cards']+=1
  else:counts[d+'/different_source_cards']+=1;differences.append([d,q])
  for out in [a,b]:
   for r in out.get('requests',[]):
    if r.get('cache_hit') is False:fresh[r['key']]+=1;fresh_tokens+=r.get('usage',{}).get('total_tokens',0)
    elif r.get('cache_hit') is True:cached_calls+=1
e_counts=collections.Counter();e_diff=[]
for case in json.loads((ROOT/'analysis/phase3e/check_v2/casebook.json').read_text()):
 for m in ['E_blind','E_seen','E_quote']:
  a,b=case['outputs']['C1'],case['outputs'][m];e_counts[m+'/pairs']+=1
  if a['status']=='error' or b['status']=='error':e_counts[m+'/pair_has_error']+=1
  elif signature(a)==signature(b):e_counts[m+'/same_actual_source_cards']+=1
  else:e_diff.append([m,case['input']['question_id']])
assert n==4038
write_json(ROOT/'analysis/phase3f/pair_and_cost_audit.json',{'n':n,'F_source_card_pairs':dict(counts),'F_differences':differences,'E_check_source_card_pairs':dict(e_counts),'E_check_differences':e_diff,'source_card_equality_passed':not differences and not e_diff,'completed_output_trace_noncache_calls':sum(fresh.values()),'completed_output_trace_noncache_tokens':fresh_tokens,'distinct_noncache_request_keys':len(fresh),'duplicate_noncache_completions_beyond_first_key':sum(v-1 for v in fresh.values()),'cached_logical_calls':cached_calls,'cost_scope':'Returned non-cache request traces associated with completed outputs; duplicate concurrent requests counted. Excludes interrupted requests absent from completed outputs, failed transport attempts, and MiniCheck computation; not all physical compute.','causal_scope':'Equal actual source cards checked where available; error outputs remain in all metrics. F_E additionally exposes binding metadata to collection generation, so this is not a pure filtering-only contrast.'})
print('Source-card differences:',len(differences)+len(e_diff),'; completed returned non-cache calls',sum(fresh.values()),'tokens',fresh_tokens,'duplicate completions',sum(v-1 for v in fresh.values()))
