"""Admit public human-authored QA only for a grounding/abstention component study."""
import json,re,hashlib,random,collections,urllib.parse,time
from pathlib import Path
from real_runtime import ROOT,write_json

def norm(s):return ' '.join(re.sub(r'[^\w\s]',' ',s.lower().replace('_',' ')).split())
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
oldq=set();olddoc=set();titles=set();files=[]
for p in (ROOT/'materials/prepared').rglob('*.inputs.jsonl'):
 if 'phase3' in str(p):continue
 files.append(str(p.relative_to(ROOT)))
 for l in p.open():
  r=json.loads(l);oldq.add(norm(r['question']))
  for d in r.get('documents',[]):olddoc.add(sha(norm(d['text'])))
for l in (ROOT/'materials/datasets/ramdocs/RAMDocs_test.jsonl').open():
 r=json.loads(l)
 for e in r['disambig_entity']:
  if isinstance(e,str):titles.add(norm(e))
for l in (ROOT/'materials/datasets/conflicts/conflicts.jsonl').open():
 r=json.loads(l)
 for d in r['search_results']:
  u=d.get('url','')
  if 'wikipedia.org/wiki/' in u:titles.add(norm(urllib.parse.unquote(u.split('/wiki/',1)[1].split('#')[0])))
  if d.get('title','').endswith(' - Wikipedia'):titles.add(norm(d['title'][:-12]))
# ConfRAG page metadata: count any explicitly present Wikipedia URL/title.
for l in (ROOT/'materials/datasets/confrag/ConfRAGsuggested.jsonl').open():
 r=json.loads(l)
 for d in r['websites']:
  for u in re.findall(r'https?://[^\s)\]]*wikipedia\.org/wiki/[^\s)\]]+',d.get('content','')):titles.add(norm(urllib.parse.unquote(u.split('/wiki/',1)[1].split('#')[0])))
base=ROOT/'materials/prepared/phase3_grounding_v1';base.mkdir(parents=True,exist_ok=True)
selected={};audit={};rng=random.Random(30576)
for split,source,n,maxper in [('dev','train',100,1),('reserved_check','dev',200,20)]:
 data=json.loads((ROOT/f'materials/datasets/squad2/{source}-v2.0.json').read_text());pool={False:[],True:[]};excluded=collections.Counter()
 for article in data['data']:
  title=norm(article['title'])
  if title in titles or (split=='reserved_check' and title in selected['dev']['titles']):excluded['prior_or_dev_title']+=1;continue
  for paragraph in article['paragraphs']:
   text=paragraph['context'];docsha=sha(norm(text));words=len(text.split())
   if not (30<=words<=350) or len(text)>2500:excluded['paragraph_size']+=1;continue
   if docsha in olddoc:excluded['prior_exact_context']+=1;continue
   for q in paragraph['qas']:
    if norm(q['question']) in oldq:excluded['prior_exact_question']+=1;continue
    if not q['is_impossible']:
     assert q['answers'] and all(text[a['answer_start']:a['answer_start']+len(a['text'])]==a['text'] for a in q['answers'])
    pool[q['is_impossible']].append((title,docsha,text,q))
 for values in pool.values():rng.shuffle(values)
 chosen=[];usedcontexts=set();usedquestions=set();titlecounts=collections.Counter()
 for label in [False,True]:
  part=[]
  for title,h,text,q in pool[label]:
   if h in usedcontexts or norm(q['question']) in usedquestions or titlecounts[title]>=maxper:continue
   part.append((title,h,text,q));usedcontexts.add(h);usedquestions.add(norm(q['question']));titlecounts[title]+=1
   if len(part)==n//2:break
  assert len(part)==n//2,(split,label,len(part));chosen+=part
 rng.shuffle(chosen);inputs=[];refs=[]
 for title,h,text,q in chosen:
  qid='sq2-'+q['id'];inputs.append({'question_id':qid,'question':q['question'],'documents':[{'doc_id':'d1','text':text}]})
  refs.append({'question_id':qid,'title_group':title,'context_sha256':h,'source_split':source,'is_impossible':q['is_impossible'],'answers':q['answers'],'reference_type':'published_SQuAD2_crowdworker_annotations','relation_gold':None})
 for suffix,rows in [('inputs',inputs),('eval',refs)]:
  p=base/f'{split}.{suffix}.jsonl';assert not p.exists();p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 selected[split]={'titles':set(titlecounts),'contexts':usedcontexts,'questions':usedquestions}
 audit[split]={'n':n,'answerable':n//2,'unanswerable':n//2,'title_groups':len(titlecounts),'unique_paragraphs':len(usedcontexts),'source_split':source,'candidates':{str(k):len(v) for k,v in pool.items()},'excluded':dict(excluded),'max_questions_per_title':max(titlecounts.values()),'test_generation_permitted_this_turn':False if split=='reserved_check' else True}
assert not selected['dev']['titles']&selected['reserved_check']['titles']
assert not selected['dev']['contexts']&selected['reserved_check']['contexts']
assert not selected['dev']['questions']&selected['reserved_check']['questions']
write_json(ROOT/'planning/phase3/data_admission.json',{'epoch':time.time(),'splits':audit,'old_prepared_input_files_checked':files,'prior_unique_questions':len(oldq),'prior_unique_documents':len(olddoc),'excluded_prior_title_keys':len(titles),'split_disjoint_in_title_context_question':True,'limits':['Metadata/exact-key checks do not certify semantic alias independence','Public benchmark pretraining exposure unknown','Grounding/abstention component only, not multi-document conflict','Balanced size-bounded sample is not full SQuAD distribution','Published answer annotations are not new project human relation gold'],'G17':'component_development_only; full_conflict_gate_pending'})
print(json.dumps(audit,indent=2))
