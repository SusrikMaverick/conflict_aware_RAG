"""Failure mechanism and full resource accounting, supplementary to frozen metrics."""
import json,collections,hashlib,time
from real_runtime import ROOT,write_json
outdir=ROOT/'analysis/phase2';stats={}
for split in ['dev','check']:
 for m in ['frozen','quote_fix','scope_guided']:
  xs=[json.loads(p.read_text()) for p in (ROOT/f'runs/phase2-v2-{split}/{m}').glob('*.json')]
  stats[split+'/'+m]={'n':len(xs),'enforcement_reasons':dict(collections.Counter(r for x in xs for r in x.get('enforcement_reasons',[]))),'extraction_issues':dict(collections.Counter(i['error'] for x in xs for i in x.get('extraction_issues',[]))),'unverified_cards':sum(c['support_status']!='verified' for x in xs for c in x.get('cards',[])),'accepted_with_E1':sum(bool(x.get('accepted_answers')) and x.get('decision_basis')=='E1' for x in xs),'accepted_with_E2':sum(bool(x.get('accepted_answers')) and x.get('decision_basis')=='E2' for x in xs),'scope_status':dict(collections.Counter(x.get('scope_audit',{}).get('status') for x in xs))}
write_json(outdir/'mechanism_counts.json',stats)
cost={}
for ns in ['phase2_v1','phase2_v2']:
 raw=[json.loads(p.read_text()) for p in (ROOT/f'runs/request_cache/{ns}').glob('*.json')]
 cost[ns]={'unique_raw_requests':len(raw),'tokens':{k:sum(x['usage'][k] for x in raw) for k in ['prompt_tokens','completion_tokens','total_tokens']},'scope':'all cached requests including any aborted unreferenced requests'}
r=json.loads((ROOT/'runs/phase2-known-regression-v1/review.json').read_text());new=[json.loads((ROOT/'runs/phase2-known-regression-v1/request_cache'/f'{k}.json').read_text()) for k in r['new_request_keys']]
cost['known_regression_new_only']={'unique_raw_requests':len(new),'tokens':{k:sum(x['usage'][k] for x in new) for k in ['prompt_tokens','completion_tokens','total_tokens']}}
write_json(outdir/'all_stage2_inference_cost.json',cost)
old=json.loads((ROOT/'runs/phase2-v1-dev/ABORTED_INVALID_DATA.json').read_text());assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in old['hashes'].items())
# Freeze final valid outputs plus new regression for future integrity checks.
paths=list(ROOT.glob('runs/phase2-v2-*/*/*.json'))+[ROOT/'runs/phase2-known-regression-v1/result.json']
write_json(ROOT/'planning/phase2_output_hashes.json',{'epoch':time.time(),'n_outputs':len(paths),'sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'invalid_v1_preserved':True})
print(json.dumps({'mechanisms':stats,'all_cost':cost},indent=2))
