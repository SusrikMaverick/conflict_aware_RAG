"""Consolidate completed analyses without changing frozen choices."""
import json
from real_runtime import ROOT,write_json
def read(path):return json.loads((ROOT/path).read_text())
f=read('analysis/phase3f/summary.json');audit=read('analysis/phase3f/audit.json');inventory=read('planning/phase3_complete/run_inventory.json')
diag=read('analysis/phase3f/confrag_diagnostics.json')['counts'];pair=read('analysis/phase3f/pair_and_cost_audit.json')
assert audit['passed'] and audit['n']==4038
ram=f['methods']['ramdocs'];conf=f['methods']['confrag']
text=f'''阶段三完整复盘：进展与采用决定分开
2026-11-03 America/Phoenix

本轮目标：根据前两阶段的负结果设计新方法，先做开发/反例/消融，再固定主候选做保留数据确认，最后检查迁移与回归。用户要求没有进展就继续提出并检验方案。实际经历A失败→B六条件过严→C来源卡改善覆盖但增加误答→E问题绑定出现独立确认收益；D多源图和D_E迁移失败也完整保留。

1. 明确有进展的范围
E_blind在原先封存SQuAD200题上134/200=67%，旧quote_fix115/200=57.5%；+9.5百分点，29文章主题配对bootstrap95%区间[+2.985,+16.111]百分点。可答100题47对26；不可答100题误答13对11。相对结构化direct同样多19题正确且误答13对38，但direct可答题正确53高于E47。
这不是完整采用成功：预设总EM点增益至少10pp未达到；不可答误答差的区间上界+7.609pp超过+5pp非劣界限。E_quote次要版本138/200，不能看完测试后换主候选。E200现在已经观察，后续改法需新开发/确认。
E逻辑LLM tokens156792对旧322140，节省51.3%；相对direct73305则约2.14倍。MiniCheck计算另需成本；不可把LLM tokens当完整推理成本。

2. 哪些方案没做好
B固定六项条件在缺乏明确范围元数据时过度拒答，主要候选可答0/50；不是安全成功。
C来源ID、短答案和精确跨度改善抽取，通用复核开发65/100对旧53/100，但不可答误答14/50对7/50；覆盖增长伴随错误接受。
D图在同名不同实体上误判contradiction，271边中195矛盾而different_entity仅11。无人工gold，数字只是输出分布。AmbigDocs图source-pair F1 .0402，直接基线.2507；D_E .2138对C1 .2297。所有开发方案未通过全部门槛，因此200多源保留组不运行。该数据问题由作者生成，评分是本地doc_id归属指标而非官方DF1。严格答案粒度不匹配不等于事实幻觉。
E仍会丢失方向/直接性、把错误问题前提写进假设、误信来源中的相似实体。未知代号WILLOW-731的正确source卡MiniCheck .949通过，绑定器却can_form=false，端到端回归仍失败。没有修改已知toy或重试到成功。

3. 全量旧基准迁移（探索性）
RAMDocs500每条件齐全：F_C1兼容正确率{ram['F_C1']['official_compatible']:.3%}，F_E{ram['F_E']['official_compatible']:.3%}；旧full3.6%，plain15.2%。E相对C1有4增益9退化，347次弃答仍有verified卡。多源集合策略仍是主要瓶颈；Freedom Suite的一个计分增益伴随不一致解释，不能当可靠真假裁决。详细案例见analysis/phase3f/ramdocs_retrospective.txt。
ConfRAG1061每条件齐全：F_C1 NMI{conf['F_C1']['NMI']:.4f}，答案分{conf['F_C1']['answerScore']:.4f}，理由分{conf['F_C1']['reasonScore']:.4f}；F_E NMI{conf['F_E']['NMI']:.4f}，答案分{conf['F_E']['answerScore']:.4f}，理由分{conf['F_E']['reasonScore']:.4f}。源组配对区间和旧基线见summary.json。仍使用gold辅助选页、oracle K与每页4000tokens上限；最终生成器未硬校验输出属于verified卡，不能声称严格证据保证。
ConfRAG的F_E中，{diag.get('F_E/zero_verified_with_nonempty_generated_answers',0)}题在零verified卡时仍生成非空答案；F_C1对应{diag.get('F_C1/zero_verified_with_nonempty_generated_answers',0)}题。这反映接口缺口，不是人工幻觉率。F_E还向集合模型暴露绑定假设/理由，所以对照是绑定模块及其可见元数据，不能称纯过滤效应。成功输出间的实际源卡一致性审计={pair['source_card_equality_passed']}，错误输出仍计入总评分。
CONFLICTS458每条件齐全；仅描述接受率/类别分布，没有新增人工正确性gold，不报告关系F1。
F的全篇绑定核验超过2048token上限会明确标uncertain_overflow，不能静默切局部。所有源跨度审计{audit['offsets']}条、唯一绑定请求{audit['unique_binding_requests']}条通过，但结构审计不能证明蕴含或实体判断正确。

4. 实验记录和可复现性
阶段三累计{inventory['output_records_total_including_copies']}个文件记录，其中1300是原样复用控制；实际新增8408个变体输出（含前一轮A300），不是8408个独立题。F4038全部保留，模型失败不剔除；58接口/评分测试通过。所有旧9618输出/3663检查点、phase2的217输出、A300及冻结科学源码、同学快照和proposal完整性另有审计。
F中途因吞吐调整服务并发，已保存787输出/3900缓存哈希保持一致；模型/输入/阈值/提示/解码不变。微批数值差异可能存在，不宣称重生成逐位一致。已保存唯一请求token不包括被中断且未返回的请求计算，墙钟也受共享GPU影响。
F已完成输出轨迹的非缓存返回调用{pair['completed_output_trace_noncache_calls']}次、tokens{pair['completed_output_trace_noncache_tokens']}；同key重复非缓存返回{pair['duplicate_noncache_completions_beyond_first_key']}次。该记账仍不含中断未归入完成输出的请求、传输失败尝试和MiniCheck计算。
报告、方法/结果TeX片段、PNG/PDF/SVG图、逐题输出、冻结协议、复现命令和本地归档可追溯。没有LaTeX编译器，TeX片段未编译成论文PDF；报告不是最终课程提交件。

5. 下一步如何改
H7先判身份/事件/时间是否可比较，再判值不相容，增加同名实体与同实体假文档成对反例。
H8绑定假设保持问题前提与方向，并将形式可填入与事实熟悉程度分开，防止陌生答案被先验拒绝；不能把LLM自评当真值。
H9预定义局部上下文核验/溢出策略，在新开发数据上评估；不能据E_quote已观察确认结果直接改默认。
先做真实人类核读：30条诊断包已准备，所有人工栏为空，human gold/IAA仍0。它是目的性案例包，不是代表性总体评估。72B、完整多关系/E1E2、预算匹配MADAM、正式报告/PPT/poster仍在worksheet中待完成；不宣称解决整个项目。
未知信息照实记入未知表，不中途追问。所有新代码留服务器，未写团队GitHub，未改现有conda；不提交课程平台、不联系同学。归档只在本地，未绕过此前整包Drive上传的审批限制。
'''
(ROOT/'analysis/phase3_complete/retrospective.txt').write_text(text)
write_json(ROOT/'planning/phase3_complete/checklist.json',{'scope':'Stage3 declared automatic research cycle completed; not full proposal or final submission','steps':[
 {'id':f'S3-{i:02d}','status':'done_with_scope_limits','evidence':e} for i,e in enumerate([
 'analysis/phase3/retrospective.txt; analysis/phase3b–f/',
 'planning/phase3b–f designs/protocols; optional bounded re-extraction deferred',
 'design review/counterexamples; logs/phase3-final-tests.log (58); agent review only',
 'Frozen grouped admission; E200/29 topics; AmbigDocs100dev/200sealed; human gold0',
 'B/C/D/E full development, negative versions retained',
 'E1400 independent outputs; F4038 exploratory outputs; D200 not opened per failed dev gates',
 'E primary complete adoption FAILED; D all failed; retrospective retains progress and limits',
 'analysis/phase3_complete/report.html, TeX drafts, figures, reproduce.txt; local archive and worksheet verification recorded separately'
 ],1)],'measurable_independent_progress':True,'default_adoption_passed':False,'functional_regression_passed':False,'human_gold':0,'ambig_test200_opened':False,'course_submission_complete':False,'pending':['Real human annotation/IAA','Full proposal scope and72B/budget-matched baseline','New-data H7/H8/H9 design iteration','Final report/PPT/poster and permitted submission'],'finalization_evidence':{'worksheet':'planning/phase3_complete/final_sheet_readback.json','runtime':'planning/phase3_complete/runtime_release.json','archive':'planning/phase3_complete/archive.json'}})
print('Wrote retrospective and scoped checklist')
