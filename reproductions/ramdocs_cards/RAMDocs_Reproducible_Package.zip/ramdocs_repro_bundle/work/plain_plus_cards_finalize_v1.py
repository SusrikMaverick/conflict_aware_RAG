"""Integrity audit and readable report for the fixed exploratory card appendix."""
import hashlib
import html
import json
from collections import Counter
from real_runtime import ROOT, load_plain_prompt, write_json
from plain_plus_cards_v1 import FIELDS, SUFFIX

name = 'plain_plus_cards_v1'
plan = ROOT/'planning'/name
analysis = ROOT/'analysis'/name
protocol = json.loads((plan/'protocol.json').read_text())
for f, sha in protocol['hashes'].items():
    assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest() == sha, f
inputs = {r['question_id']: r for r in json.loads((plan/'inputs.json').read_text())}
rows = [json.loads(s) for s in (ROOT/'materials/prepared/v1/ramdocs.inputs.jsonl').read_text().splitlines()]
checks = Counter()
outputs = {}
for row in rows:
    q = row['question_id']
    saved = inputs[q]
    source = json.loads((ROOT/saved['source']).read_text())
    mapping = {d['doc_id']: i for i, d in enumerate(row['documents'], 1)}
    expected_cards = [{**{k:c[k] for k in FIELDS if k in c}, 'original_document_number':mapping[c['doc_id']]} for c in source.get('cards',[])]
    assert expected_cards == saved['cards']
    docs = '\n'.join(f"Document {i}: {d['text']}" for i,d in enumerate(row['documents'],1))
    plain = load_plain_prompt().format(question=row['question'], documents=docs)
    assert saved['prompt'] == plain + SUFFIX + json.dumps(expected_cards,ensure_ascii=False)
    out = json.loads((ROOT/'runs'/name/'outputs'/f'{q}.json').read_text())
    outputs[q] = out
    assert out['question_id'] == q
    for request in out.get('requests',[]):
        raw = json.loads((ROOT/'runs'/name/'request_cache'/(request['key']+'.json')).read_text())
        assert raw['request']['messages'] == [{'role':'user','content':saved['prompt']}]
        assert raw['request']['max_tokens']==128
        assert raw['request']['temperature']==0
        assert raw['request']['repetition_penalty']==1.05
        assert raw['text'] == out['raw_output']
        checks['request_payloads'] += 1
    checks['questions']+=1
    checks['cards']+=len(expected_cards)
    checks['empty_cards']+=not expected_cards
assert checks['questions']==500
summary = json.loads((analysis/'summary.json').read_text())
paired = json.loads((analysis/'paired.json').read_text())
gold = {r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/v1/ramdocs.evaluation.jsonl').read_text().splitlines())}
examples=[]
for label, direction in [('gain',1),('loss',-1)]:
    changes=[p for p in paired if p['plus_cards']['official_compatible']-p['plain']['official_compatible']==direction]
    for p in changes[:3]:
        q=p['question_id'];old=json.loads((ROOT/'runs/ramdocs-combined-v3/plain'/f'{q}.json').read_text())
        examples.append({'change':label,'question_id':q,'question':next(r['question'] for r in rows if r['question_id']==q),
            'gold_answers':gold[q]['gold_answers'],'wrong_answers':gold[q]['wrong_answers'],
            'plain_output':old.get('raw_output'), 'plus_cards_output':outputs[q].get('raw_output'),
            'cards':inputs[q]['cards']})
write_json(analysis/'changed_examples.json',examples)
files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'runs'/name/'outputs').glob('*.json')}
write_json(plan/'audit.json',{'passed':True,'checks':dict(checks),'source_hashes_checked':len(protocol['hashes']),'output_hashes':files,
    'note':'Input provenance and request fidelity audit; no claim of extraction semantic correctness or independent test confirmation.'})
a,b=summary['plain'],summary['plus_cards'];d=summary['paired']
lines=['用户指定实验：原文档 + 提取证据，直接交给模型回答',
'设计：[已完成] 冻结单变量方案与来源哈希；[已完成] 500题生成；[已完成] 配对评分；[已完成] 输入与请求审计。',
'Plain RAG在本实验直接使用每题自带文档，没有新检索步骤。新方法仅在原提示后追加证据，不调用关系分类、裁决或强制弃答。',
f"Plain: {round(a['official_compatible']*500)}/500 ({a['official_compatible']:.1%}); plus cards: {round(b['official_compatible']*500)}/500 ({b['official_compatible']:.1%}).",
f"变化: {d['delta']*100:+.1f}个百分点; gains={d['gains']}, losses={d['losses']}; 问题级bootstrap95%区间={d['question_bootstrap_95CI']} (比例单位)。",
f"严格答案集合匹配: {a['strict_set_exact']:.1%} -> {b['strict_set_exact']:.1%}。",
f"接受标注错误答案题数: {round(a['wrong_only_accepted']*500)} -> {round(b['wrong_only_accepted']*500)}。",
f"状态: plain={a['statuses']}; plus_cards={b['statuses']}; 输出达到128token上限 {a['output_limit']} -> {b['output_limit']}。",
f"最终生成逻辑token: {a['logical_tokens']} -> {b['logical_tokens']}；提取阶段复用历史产物，未含提取成本，因此不是端到端等预算比较。",
'使用C1保存的全部1908张卡，不按验证分数筛选；20题为空（含4题上轮错误无保存卡），保留全部500题。',
'限制：RAMDocs已观察，仅探索性；7B BF16非同学72B；对照复用历史输出，运行批次可能不同；新增输入也含证据提示说明，因此对比的是整个追加证据输入方案；不能据此独立归因于结构化格式。',
'限制：128输出token与旧Plain相同，不能将可能的截断解释为无截断模型能力；区间按题重采样，未解决同实体/文档相关性。',
'案例核查：Pilzno题新增正确人口但仍混有其他地区人口；Miura题将错误sumo wrestling改写为sumo，官方字符串指标未识别错误，实际仍选了错误候选。Soccer Bowl题恢复正确队伍。Dallas法院、Doak运动、Louis Alexandre死亡日期题则因纳入假证据从正确变错。上述是按题序抽取的3增益/3退步示例，不是完整人工错误率。',
'因此24.8%是官方兼容字符串指标，不等于每道得分题语义完全正确；更严格的答案集合匹配仍由13.0%升至17.6%，提高4.6个百分点。',
'结论：'+('本轮追加证据提高了观察到的主指标，需要独立数据确认。' if d['delta']>0 else '本轮追加证据没有提高主指标；保留负结果，不据此默认采用。'),
'下一步：先检查增益/退步与截断案例；若继续，单独预注册统一更大输出预算的两个条件及验证分数消融；不要重写本轮结果。',
'原始输出 runs/plain_plus_cards_v1/outputs/；冻结协议 planning/plain_plus_cards_v1/protocol.json；完整指标 analysis/plain_plus_cards_v1/summary.json。']
(analysis/'report.txt').write_text('\n\n'.join(lines)+'\n')
(analysis/'report.html').write_text('<!doctype html><meta charset="utf-8"><title>原文与提取证据对照</title><style>body{max-width:1000px;margin:40px auto;font:17px/1.7 sans-serif;padding:16px}pre{white-space:pre-wrap}</style><h1>原文与提取证据对照</h1><pre>'+html.escape('\n\n'.join(lines))+'</pre>')
write_json(plan/'checklist.json',{'design':'complete','generation':'complete','scoring':'complete','audit':'complete','report':'complete','worksheet':'pending','runtime_release':'pending'})
print((analysis/'report.txt').read_text())
