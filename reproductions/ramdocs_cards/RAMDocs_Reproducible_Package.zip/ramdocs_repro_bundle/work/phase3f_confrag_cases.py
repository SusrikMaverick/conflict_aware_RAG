"""Post-hoc ConfRAG transfer diagnostics; no claim of human correctness gold."""
import collections,json
from real_runtime import ROOT,write_json
run=ROOT/'runs/phase3f-transfer-v3/confrag'
rows=list(map(json.loads,(run/'scored.jsonl').open()))
scores={m:{r['question_id']:r for r in rows if r['method']==m} for m in ['F_C1','F_E']}
assert all(len(x)==1061 for x in scores.values())
inputs={r['question_id']:r for r in map(json.loads,(ROOT/'materials/prepared/confrag_official_v1/inputs.jsonl').open())}
counts=collections.Counter();diagnostics={};cases=[]
for q in sorted(inputs):
 out={m:json.loads((run/m/(q+'.json')).read_text()) for m in scores}
 for m,x in out.items():
  counts[m+'/n']+=1
  if x['status']=='error':counts[m+'/error']+=1;continue
  verified=sum(c.get('support_status')=='verified' for c in x.get('cards',[]))
  answer_rows=x.get('prediction',{}).get('answers',[])
  nonempty=any(str(r.get('answer','')).strip() for r in answer_rows)
  if not verified:
   counts[m+'/zero_verified_cards']+=1
   if nonempty:counts[m+'/zero_verified_with_nonempty_generated_answers']+=1
  if m=='F_E' and not verified and nonempty:diagnostics[q]={'question':inputs[q]['question'],'prediction':x['prediction'],'cards':x.get('cards',[]),'status':x['status']}
 changes={k:float(scores['F_E'][q][k])-float(scores['F_C1'][q][k]) for k in ['NMI','answerScore','reasonScore']}
 cases.append({'question_id':q,'question':inputs[q]['question'],'changes':changes,'scores':{m:scores[m][q] for m in scores},'outputs':out})
 selected=[]
 for direction in [-1,1]:
  selected.extend(sorted(cases,key=lambda c:(direction*c['changes']['answerScore'],c['question_id']))[:6])
write_json(ROOT/'analysis/phase3f/confrag_diagnostics.json',{'counts':dict(counts),'zero_verified_examples':dict(list(diagnostics.items())[:10]),'interpretation':'Nonempty final generated answers with zero verified cards reveal lack of deterministic membership enforcement; this count is not a hallucination/correctness rate. The frozen adapter also supplies uncertain cards and asks for all indexes.'})
write_json(ROOT/'analysis/phase3f/confrag_changed_cases.json',{'sampling':'Post-hoc six largest and six smallest paired answerScore differences; these may include zero or same-sign changes. Ties broken by question ID. Not representative human evaluation.','cases':selected})
print(dict(counts))
