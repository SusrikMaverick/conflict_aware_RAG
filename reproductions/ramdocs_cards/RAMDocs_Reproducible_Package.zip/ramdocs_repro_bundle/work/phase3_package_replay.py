"""Re-score an extracted review archive using the existing isolated interpreter."""
import hashlib,json,os,subprocess,zipfile
from pathlib import Path
from real_runtime import ROOT,write_json
archive=ROOT/'deliverables/phase3_review_bundle.zip';dest=ROOT/'caches/phase3_package_replay'
assert not dest.exists(),'Use a fresh extraction directory; do not overwrite a previous replay.'
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():
  assert not Path(name).is_absolute() and '..' not in Path(name).parts
 z.extractall(dest)
manifest=json.loads((dest/'planning/phase3_complete/bundle_file_manifest.json').read_text())
protocol=json.loads((dest/'planning/phase3f/runtime2_freeze.json').read_text())
assert all(not Path(k).is_absolute() and '..' not in Path(k).parts for k in protocol['hashes'])
assert all(not Path(v[k]).is_absolute() for v in protocol['datasets'].values() for k in ['input','eval'])
critical={k:v['sha256'] for k,v in manifest.items() if k.startswith(('work/','materials/','models/','runs/','analysis/')) or ('freeze' in k and k.endswith('.json'))}
env=dict(os.environ,PYTHONPATH=str(dest/'work'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HOME=str(dest/'caches/huggingface'))
commands=[('ramdocs',['work/analyze_benchmark.py','runs/phase3f-transfer-v3/ramdocs','--dataset','ramdocs']),('conflicts',['work/analyze_benchmark.py','runs/phase3f-transfer-v3/conflicts','--dataset','conflicts']),('confrag',['work/analyze_confrag.py','runs/phase3f-transfer-v3/confrag']),('paired',['work/phase3f_review.py']),('audit',['work/phase3f_audit_v3.py'])]
for name,args in commands:
 with (ROOT/'logs'/f'phase3-package-replay-{name}.log').open('w') as log:
  subprocess.run([str(ROOT/'.venv/bin/python'),*args],cwd=dest,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Replayed',name,flush=True)
checks={}
for d in ['ramdocs','conflicts','confrag']:
 path=Path('runs/phase3f-transfer-v3')/d/'analysis.json'
 checks[d]=json.loads((ROOT/path).read_text())['methods']==json.loads((dest/path).read_text())['methods']
checks['paired_contrasts']=json.loads((ROOT/'analysis/phase3f/summary.json').read_text())['paired']==json.loads((dest/'analysis/phase3f/summary.json').read_text())['paired']
a=json.loads((dest/'analysis/phase3f/audit.json').read_text());checks['source_request_frozen_hash_audit']=a['passed'] and a['n']==4038
write_json(ROOT/'planning/phase3_complete/package_replay.json',{'passed':all(checks.values()),'checks':checks,'initial_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scientific_payload_files':len(critical),'scientific_payload_fingerprint':hashlib.sha256(json.dumps(critical,sort_keys=True).encode()).hexdigest(),'scope':'Isolated archive extraction, same-machine existing .venv; no model inference, GPU or network. Not an independent machine/environment reproduction. Final archive builder must verify unchanged scientific payload fingerprint.'})
assert all(checks.values()),checks
print('All re-scoring and source audits matched.')
