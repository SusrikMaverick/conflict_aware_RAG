"""Prepare bounded changed-cell edits; live read/compare happens separately."""
import json
from real_runtime import ROOT,write_json
w=json.loads((ROOT/'planning/worksheet_data.json').read_text());tabs={t['title']:t for t in w['tabs']};edits=[]
f=json.loads((ROOT/'analysis/phase3f/summary.json').read_text());a=json.loads((ROOT/'analysis/phase3f/audit.json').read_text());assert a['passed'] and a['n']==4038
def add(tab,row,col,values):
 title=next(t for t in tabs if t.startswith(tab+'_'));t=tabs[title];allrows=[t['headers']]+t['rows']
 before=[[allrows[row+i][col+j] if col+j<len(allrows[row+i]) else '' for j in range(len(r))] for i,r in enumerate(values)]
 edits.append({'sheetId':846003474 if tab=='00' else 57600+int(tab),'tab':title,'row':row,'col':col,'values':values,'expected_before':before,'expected_row_ids':[allrows[row+i][0] for i in range(len(values))],'expected_headers':t['headers']})
def idrow(tab,id):
 title=next(t for t in tabs if t.startswith(tab+'_'));return 1+next(i for i,r in enumerate(tabs[title]['rows']) if r[0]==id)
add('00',2,1,[['阶段三限定实验流程完成：E独立200题EM134/200对旧115/200（+9.5pp），有进展但未通过完整采用门槛。','F旧2019题×2=4038输出全完成；RAMDocs E6.2%对C1 7.2%、plain15.2%；组件收益未稳定迁移。D200组仍封存，功能回归失败。','2026-11-03 America/Phoenix；analysis/phase3_complete/report.html；完整proposal/人工标注/72B/正式提交仍未完成']])
add('01',48,10,[['已完成（限定评测）','E独立1400输出与F4038全部完成；D开发门槛失败，按协议不启动200组确认；完整自然关系验证仍缺人审。'],['已完成','E独立+9.5pp CI[+2.985,+16.111]，但收益点值/误答非劣两门槛失败；D不采用；F迁移不支持整体提升；所有负结果保留。'],['已完成（本地研究审阅版）','完整HTML/TeX片段/图表/复现说明/本地ZIP、worksheet回读与释放GPU；功能回归仍失败，P34未成为可发布默认方案。']])
add('01',idrow('01','P34'),10,[['部分完成（阶段三证据归档）','58接口/评分测试通过；ZIP隔离副本重评分三基准/配对CI/来源审计一致；同机器同环境，无新模型推理。已知WILLOW-731仍错误弃答，尚非功能发布。']])
add('01',idrow('01','P35'),10,[['部分完成（方法/组件结果素材）','analysis/phase3_complete/method_section.tex、results_component_section.tex与可导出图完成；ACL8–10页完整稿/编译PDF尚未完成。']])
add('02',21,10,[['本轮完成：E独立200×7、F旧2019×2全量与审计齐全；D200组按失败门槛保持封存；不将单源收益外推完整冲突裁决。']])
c=f['methods']['confrag'];fc=c['F_C1'];fe=c['F_E']
add('05',49,4,[['2019题×2=4038完成','2026-11-03 America/Phoenix',f"RAMDocs C1/E=7.2%/6.2%；ConfRAG NMI={fc['NMI']:.4f}/{fe['NMI']:.4f}",'全部失败计入；旧数据探索性；CONFLICTS无人工准确性gold','analysis/phase3f/summary.json；audit.json；runtime2_freeze.json','787输出/3900缓存哈希保留后仅并发调整；未返回请求计算成本未知','已完成（迁移限制已记录）']])
add('06',idrow('06','R08'),3,[['旧phase2及A记录保留各归档；本轮B700/C700/D500+D_E100/E两版各300新增/E确认1400/F4038均完成。','固定主候选Eblind；独立正增益与完整采用失败分别报告；D不采用、不启200测试。','E134对115/200；RAMDocs E31对C1 36/500；已知代号回归仍失败。','planning/phase3_complete/next_iteration.txt：身份可比、问题方向/前提/陌生答案、长文核验；E200不可再调参。','已完成（阶段三完整复盘）']])
add('06',idrow('06','R09'),3,[['analysis/phase3_complete/retrospective.txt、teammate_comparison.txt、方法/结果草稿。','分别陈述来源可追溯、单源收益、多源失败和采用门槛；不宣称原创或完整解决冲突。','新增证据为E独立单源进展及D/F迁移边界；旧集合策略仍有E2/范围一致性缺口。','真实人审、72B、完整图、预算匹配MADAM和最终报告仍待完成。','已完成（阶段三声明核对）']])
title=next(t for t in tabs if t.startswith('07_'));old=tabs[title]['rows'][18]
add('07',19,0,[[old[0],'F全量迁移：同来源卡C1与E问题绑定','RAMDocs500/CONFLICTS458/ConfRAG1061×2全部完成',f"RAMDocs E6.2%低于C1 7.2%；ConfRAG NMI C1/E {fc['NMI']:.4f}/{fe['NMI']:.4f}",'旧数据探索性；无CONFLICTS人工gold；金选页/K/截断限制','保留诊断；不据此更换E独立确认主候选','已完成；不宣称整体成功']])
for id,evidence,status in [
 ('S03','phase3_complete/method_section.tex与方法偏离；组件方法明确，完整8类/E1E2仍缺','部分完成（组件方法及边界）'),
 ('S04','E独立200/29主题CI、D100多源、F4038全量；旧阶段证据保留；人工gold/72B仍缺','部分完成（阶段三统计齐全）'),
 ('S05','analysis/phase3_complete/retrospective.txt；B/C/D失败、E独立进展但门槛失败、F迁移边界','已完成（阶段三复盘）'),
 ('S06','方法与组件结果TeX片段/图已备齐；无LaTeX编译器，完整ACL报告及PDF未完成','素材已准备；完整稿未完成'),
 ('S12','reproduce.txt及package_replay.json；ZIP隔离副本三基准/配对CI/来源审计一致；同机器同环境；跨机器未验证','部分完成（重评分复现已验证）'),
 ('S13','deliverables/phase3_review_bundle.zip及archive.json SHA/CRC；仅本地；模型/完整环境另存','部分完成（阶段三本地归档）'),
 ('S14','阶段三9708含1300复用；8408新增变体输出；逐题hash/缓存/失败全保留；不是独立题数','已完成（阶段三预测归档）'),
 ('S15','planning/phase3_complete/ai_assistance.txt记录实际agent工作；课程许可范围/团队终审未知','部分完成（实际使用记录）')]:add('09',idrow('09',id),6,[[evidence,status]])
add('10',25,2,[[f"全F4038审计完成；整篇核验>2048tokens标uncertain_overflow；分布见analysis/phase3f/audit.json",'不静默截断或按测试切局部验证','H9先用新开发集冻结范围/溢出规则；保持完整核验成本','下一阶段设计前','我们；限制长文适用性','已确认并披露']])
add('10',idrow('10','U09'),2,[['ConfRAG1061×2全量迁移完成；仍为gold辅助选页/oracleK/4000token每页；最终生成可能在零verified卡时输出答案。','分数不等于核验保证；零verified生成诊断见analysis/phase3f/confrag_diagnostics.json','下一轮单独设计最终证据成员约束，并固定可见schema；不可在旧测试追分','下轮设计及最终报告前','我们；限制ConfRAG因果归因与证据保证','本轮完成；接口限制已披露']])
add('11',135,2,[['runtime2_freeze / 4038完整输出与审计','2026-11-03 America/Phoenix','RAMDocs500+CONFLICTS458+ConfRAG1061×2','完整全量、评分、配对CI、跨度/hash审计完成','','analysis/phase3f/；runs/phase3f-transfer-v3/','探索性；并发更改完整记录；不外推独立确认']])
add('11',136,1,[['阶段三完整报告与本地复现包','report.html / TeX / figures / phase3_review_bundle.zip','2026-11-03 America/Phoenix','方法/结果/失败案例/统计/复现/下一轮设计','HTML及图表完成；ZIP本地SHA/CRC核验；未上传','','analysis/phase3_complete/；deliverables/phase3_review_bundle.zip','TeX未编译；功能回归仍失败；非最终提交版']])
# Native tables use a finite status dropdown. Keep details in cell notes/evidence.
allowed={'未开始','进行中','待检查','已完成','返工','跳过','待核验','已记录','暂定执行','已确认'}
status_columns={57601:10,57602:10,57603:6,57605:10,57606:7,57609:7,57610:7}
for row in [45,46]:add('01',row,10,[['已完成']])
for row,value in [(18,'已完成'),(19,'进行中'),(20,'跳过')]:add('02',row,10,[[value]])
for row,value in [(16,'已完成'),(17,'进行中')]:add('03',row,6,[[value]])
for row in range(17,49):
 value='跳过' if row in [17,27,39] else '已完成'
 add('05',row,10,[[value]])
for row,value in [(20,'已确认'),(21,'已记录'),(22,'待核验')]:add('10',row,7,[[value]])
for e in edits:
 column=status_columns.get(e['sheetId']);notes=[]
 if column is not None and e['col']<=column<e['col']+len(e['values'][0]):
  j=column-e['col']
  for i,row in enumerate(e['values']):
   original=row[j];old=e['expected_before'][i][j]
   if original not in allowed:
    if e['sheetId']==57610:new='已确认'
    elif e['sheetId']==57602:new='已完成'
    elif original.startswith(('部分完成','素材已准备')):new='进行中'
    elif original.startswith('已完成'):new='已完成'
    else:raise ValueError((e['tab'],e['row']+i,original))
    row[j]=new
   detail=[]
   if original not in allowed:detail.append('本轮说明：'+original)
   if old not in allowed and old!=original:detail.append('更新前完整状态：'+old)
   if detail:notes.append({'row':e['row']+i,'col':column,'text':'\n'.join(detail)})
 e['notes']=notes
write_json(ROOT/'planning/phase3_complete/final_sheet_edits.json',edits)
print(len(edits),'bounded blocks,',sum(sum(len(r) for r in e['values']) for e in edits),'cells')
