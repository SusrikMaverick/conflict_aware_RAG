import unittest
from phase3c.method import segments,source_span,SourceCards
class SpanTests(unittest.TestCase):
 def test_quotes_boundary(self):
  text='A said "No." Later B agreed. The date was 1981.';ps=segments(text);self.assertEqual(len(ps),3)
  self.assertEqual(ps[0]['text'],'A said "No."')
 def test_offsets(self):
  text='  One. Two?\nThree!';ps=segments(text)
  for s in ps:self.assertEqual(text[s['start']:s['end']],s['text'])
 def test_middle_retained(self):
  t='A opened. A closed. B opened.';s=source_span(['s0','s2'],segments(t),t);self.assertEqual(s['quote'],t)
 def test_missing_id(self):
  with self.assertRaises(ValueError):source_span(['s5'],segments('One.'),'One.')
 def test_empty(self):
  with self.assertRaises(ValueError):source_span([],segments('One.'),'One.')
 def test_duplicate(self):
  with self.assertRaises(ValueError):source_span(['s0','s0'],segments('One.'),'One.')
 def test_cross_paragraph(self):
  t='One.\n\nTwo.'
  with self.assertRaises(ValueError):source_span(['s0','s1'],segments(t),t)
 def test_cap(self):
  t='x'*2501
  with self.assertRaises(ValueError):source_span(['s0'],segments(t),t)
 def test_polarity_preserved(self):
  t='The gate did not open.';self.assertEqual(source_span(['s0'],segments(t),t)['quote'],t)
 def test_input_labels_rejected(self):
  with self.assertRaises(ValueError):SourceCards(None).run({'question':'q','documents':[{'doc_id':'d','text':'a'}],'gold':'x'})
 def test_multidoc_rejected(self):
  with self.assertRaises(ValueError):SourceCards(None).run({'documents':[{},{}]})
