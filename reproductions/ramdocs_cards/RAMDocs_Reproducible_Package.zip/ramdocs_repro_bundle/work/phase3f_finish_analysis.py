"""Wait for immutable output counts, then run analysis only. No inference/retries."""
import json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
run=ROOT/'runs/phase3f-transfer-v3';done=set()
def execute(args,log):
 with (ROOT/'logs'/log).open('w') as out:
  subprocess.run([str(ROOT/'.venv/bin/python'),*args],cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=True)
while len(done)<3:
 for d,n in [('ramdocs',500),('conflicts',458),('confrag',1061)]:
  if d in done:continue
  counts=[len(list((run/d/m).glob('*.json'))) for m in ['F_C1','F_E']]
  if counts==[n,n]:
   args=['work/analyze_confrag.py',str(run/d)] if d=='confrag' else ['work/analyze_benchmark.py',str(run/d),'--dataset',d]
   execute(args,f'phase3f-{d}-analysis.log');done.add(d);print('Analyzed',d,counts,flush=True)
 if len(done)<3:time.sleep(30)
for script in ['phase3f_review.py','phase3f_audit_v3.py','phase3f_cases.py','phase3_inventory.py','phase3_audit_all.py']:
 execute(['work/'+script],script.replace('.py','.log'));print('Completed',script,flush=True)
print('All frozen transfer analyses and integrity audits finished.',flush=True)
