RAMDocs reproducibility bundle -- START HERE
===========================================

Included: all 500 questions and evaluation annotations, 1,908 saved evidence
cards in their source results, frozen prompts/protocol, both methods' 1,000
original outputs, 500 augmented raw request/response records, required source
files, tokenizer files, CSVs, and the English PDF report. Baseline symlinks
are converted to regular files. No original server paths are needed for replay.

A. REPLAY SAVED RESULTS (no GPU, no model weights)
------------------------------------------------
From this extracted folder, with Python 3.12 on Linux x86_64:
  python3.12 -m venv .replay-venv
  .replay-venv/bin/python -m pip install --no-index --find-links wheels -r requirements-replay.txt
  .replay-venv/bin/python experiments/ramdocs_cards/experiment.py verify
  .replay-venv/bin/python experiments/ramdocs_cards/experiment.py export

The included NumPy wheel supports CPython 3.12 / Linux x86_64 (glibc >= 2.17).
For other supported Python/platform combinations, replace the offline install
with an online pip install -r requirements-replay.txt in your new environment.
Expected: 500 identical prompts/parses; all metrics/bootstrap identical.
CSV: experiments/ramdocs_cards/results/summary.csv and per_question.csv.
Official score 76/500 -> 124/500; strict answer-set 65/500 -> 88/500.
Gold/fake annotations are scoring-only; they are not inserted into prompts.

B. NEW MODEL INFERENCE (optional; GPU + online downloads required)
----------------------------------------------------------------
Weights are about 15 GB and are NOT included. Linux, a compatible NVIDIA
driver/CUDA setup, and sufficient free GPU memory are required. Our original
run used a 46-GB GPU; the supplied launch arguments are not a minimum-VRAM claim.
Create a separate environment; do not install into an existing conda environment:
  python3.12 -m venv .inference-venv
  .inference-venv/bin/python -m pip install -r requirements-inference.txt
  .inference-venv/bin/python work/download_public_model.py --repo Qwen/Qwen2.5-7B-Instruct --revision a09a35458c702b33eeacc393d103063234e8bc28 --out models/Qwen2.5-7B-Instruct
  CUDA_VISIBLE_DEVICES=0 bash start_model.sh

In a second terminal, from this folder:
  .inference-venv/bin/python experiments/ramdocs_cards/experiment.py run --out runs/new_cards_run
This regenerates augmented answers from the frozen saved cards and compares
them with the bundled original Plain outputs. It does not re-extract cards.
Existing completed outputs are skipped; use a different output directory for
a new run. Raw responses and CSVs are saved under the chosen directory.

To regenerate BOTH Plain and augmented answers:
  .inference-venv/bin/python rerun_both.py --out runs/new_both_run

Inference settings match the recorded model/decoder configuration. New hardware,
batching, drivers or dependencies may change outputs. Installation and fresh
GPU inference have not been tested on another machine. Only isolated, offline
saved-result replay is verified in this delivery. The inference requirements
pin the core observed packages, not every transitive package/driver.

C. SCOPE AND FILES
------------------
The current method is original documents + ALL saved cards, without verification
filtering, relation decisions, voting or forced abstention. Twenty questions
have no saved cards (including four prior errors); all 500 remain included.
Original extraction code and its local Python dependencies are included for
inspection under work/. Regenerating extraction/older full pipelines is NOT
part of the two commands above; those older pipelines also need their own
verifier model/data. They are not required to reproduce this frozen comparison.
The single-source diagnostic is omitted from the report and current workflow.
Old research sources are preserved unchanged to satisfy frozen source hashes;
use ONLY the documented current entrypoint, not historical server scripts.

Report: deliverables/Conflict_Aware_RAG_Simple_Report.pdf
Provenance: planning/plain_plus_cards_v1/protocol.json and audit.json.
FILE_HASHES.json lists packaged scientific/code files; REPLAY_TEST.json records
the isolated replay check. Raw records and scoring functions preserve the
original metric limitations. No claim of semantic truth or reliable conflict
resolution is made from these exploratory scores.
