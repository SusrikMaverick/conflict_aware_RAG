#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export HF_HOME="$PWD/.cache/huggingface" XDG_CACHE_HOME="$PWD/.cache"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
exec .inference-venv/bin/python -m vllm.entrypoints.openai.api_server \
  --model "$PWD/models/Qwen2.5-7B-Instruct" --served-model-name nlp576-qwen7b \
  --host 127.0.0.1 --port 8576 --dtype bfloat16 --max-model-len 32768 \
  --gpu-memory-utilization 0.65 --max-num-seqs 24 --max-num-batched-tokens 8192 \
  --seed 576 --disable-log-requests
