"""Optional new Plain + augmented generation; preserves bundled original results."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('experiment', ROOT/'experiments/ramdocs_cards/experiment.py')
e = importlib.util.module_from_spec(spec); spec.loader.exec_module(e)
p = argparse.ArgumentParser(); p.add_argument('--out', type=Path, required=True); args = p.parse_args()
e.verify()
plain = args.out/'plain'; cards = args.out/'outputs'
assert not plain.resolve().is_relative_to((ROOT/'runs/ramdocs-combined-v3').resolve())
assert not args.out.resolve().is_relative_to((ROOT/'runs/plain_plus_cards_v1').resolve())
c = e.Client(); c.cache = args.out/'plain_request_cache'; c.cache.mkdir(parents=True, exist_ok=True)
def one(row):
    q = row['question_id']; dest = plain/(q+'.json')
    if dest.exists(): return
    out = dict(question_id=q, method='plain', accepted_answers=[])
    try:
        docs = '\n'.join(f"Document {i}: {d['text']}" for i,d in enumerate(row['documents'],1))
        r = c.chat(e.load_plain_prompt().format(question=row['question'],documents=docs),128,False,1.05)
        out.update(e.parsed(r['text']),raw_output=r['text'],finish_reason=r['finish_reason'],
                   requests=[{k:r[k] for k in ('key','usage','latency_seconds','finish_reason','cache_hit')}])
    except Exception as exc:
        out.update(status='error',error=str(exc),error_kind='context_overflow' if str(exc).startswith('context_overflow') else 'infrastructure')
    e.write_json(dest,out)
with ThreadPoolExecutor(max_workers=24) as pool: list(pool.map(one,e.inputs()))
e.generate(cards)
e.BASELINE = plain
e.export(cards,args.out/'results')
print(args.out/'results')
