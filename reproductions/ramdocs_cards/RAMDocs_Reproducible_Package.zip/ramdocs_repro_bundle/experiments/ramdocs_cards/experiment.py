"""Plain RAG vs. original documents + extracted cards: run, export, verify."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work'))
from real_runtime import Client, load_plain_prompt, plain_parse, write_json
from metrics import score

HERE = Path(__file__).resolve().parent
PLAN = ROOT / 'planning/plain_plus_cards_v1'
BASELINE = ROOT / 'runs/ramdocs-combined-v3/plain'
ORIGINAL = ROOT / 'runs/plain_plus_cards_v1/outputs'
FIELDS = ('doc_id', 'card_id', 'entity', 'scope', 'claim', 'answer', 'quote')
SUFFIX = ('\n\nAdditional extracted evidence from the SAME documents (not independent '
          'sources and not guaranteed true). Use alongside the original documents above.\n')

def read(path):
    return json.loads(path.read_text())

def inputs():
    return [json.loads(line) for line in (ROOT / 'materials/prepared/v1/ramdocs.inputs.jsonl').read_text().splitlines()]

def prompt(row, extracted):
    """Reconstruct the exact frozen prompt, without evaluation annotations."""
    numbers = {d['doc_id']: i for i, d in enumerate(row['documents'], 1)}
    cards = [{**{k: c[k] for k in FIELDS if k in c},
              'original_document_number': numbers[c['doc_id']]}
             for c in extracted.get('cards', [])]
    docs = '\n'.join(f"Document {i}: {d['text']}" for i, d in enumerate(row['documents'], 1))
    return load_plain_prompt().format(question=row['question'], documents=docs) + SUFFIX + json.dumps(cards, ensure_ascii=False)

def parsed(text):
    try:
        answers = plain_parse(text)
        return {'status': 'answered' if answers else 'abstain', 'accepted_answers': answers}
    except (ValueError, SyntaxError):
        return {'status': 'parse_error', 'accepted_answers': []}

def limited(out):
    return out.get('finish_reason') == 'length' or any(r.get('finish_reason') == 'length' for r in out.get('requests', []))

def tokens(out):
    return sum(r.get('usage', {}).get('total_tokens', 0) for r in out.get('requests', []))

def evaluate(outputs):
    """Use the original scorer and bootstrap; no model calls or old-file writes."""
    import numpy as np
    gold = [json.loads(s) for s in (ROOT / 'materials/prepared/v1/ramdocs.evaluation.jsonl').read_text().splitlines()]
    paired, records = [], {'plain': [], 'plus_cards': []}
    for row in gold:
        q = row['question_id']
        pair = {'question_id': q}
        for method, folder in [('plain', BASELINE), ('plus_cards', outputs)]:
            out = read(folder / f'{q}.json')
            pair[method] = score(out, row['gold_answers'], row['wrong_answers'])
            records[method].append(out)
        paired.append(pair)
    summary = {}
    for method, outs in records.items():
        ms = [p[method] for p in paired]
        summary[method] = {k: sum(m[k] for m in ms) / len(ms) for k in ms[0]}
        summary[method].update(n=len(ms), statuses=dict(collections.Counter(o['status'] for o in outs)),
                               output_limit=sum(limited(o) for o in outs), logical_tokens=sum(tokens(o) for o in outs))
    delta = np.array([p['plus_cards']['official_compatible'] - p['plain']['official_compatible'] for p in paired])
    boots = delta[np.random.default_rng(576).integers(0, 500, size=(10000, 500))].mean(axis=1)
    summary['paired'] = dict(gains=int(sum(delta > 0)), losses=int(sum(delta < 0)), delta=float(delta.mean()),
                            question_bootstrap_95CI=np.quantile(boots, [.025, .975]).tolist(),
                            caveat='Question bootstrap assumes independence; dataset may share entities/documents.')
    return summary, paired, records, gold

def csv_file(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def export(outputs, destination):
    summary, paired, records, gold = evaluate(outputs)
    destination.mkdir(parents=True, exist_ok=True)
    write_json(destination / 'summary.json', summary)
    overview = []
    for method in records:
        s = summary[method]
        overview.append(dict(method=method, questions=s['n'], correct=round(s['official_compatible'] * s['n']),
            official_accuracy=s['official_compatible'], strict_correct=round(s['strict_set_exact'] * s['n']),
            strict_accuracy=s['strict_set_exact'], wrong_answer_questions=round(s['wrong_only_accepted'] * s['n']),
            parse_errors=s['statuses'].get('parse_error', 0), output_limit_hits=s['output_limit'],
            logical_generation_tokens=s['logical_tokens']))
    csv_file(destination / 'summary.csv', overview)
    questions = {r['question_id']: r for r in inputs()}
    frozen = {r['question_id']: r for r in read(PLAN / 'inputs.json')}
    details = []
    for i, pair in enumerate(paired):
        q = pair['question_id']
        row = dict(question_id=q, question=questions[q]['question'], document_count=len(questions[q]['documents']),
                   card_count=len(frozen[q]['cards']), extraction_source_status=frozen[q]['source_status'],
                   gold_answers=json.dumps(gold[i]['gold_answers'], ensure_ascii=False),
                   labeled_wrong_answers=json.dumps(gold[i]['wrong_answers'], ensure_ascii=False))
        for method in records:
            out = records[method][i]
            row.update({f'{method}_{key}': value for key, value in pair[method].items()})
            row.update({f'{method}_status': out['status'], f'{method}_answers': json.dumps(out.get('accepted_answers', []), ensure_ascii=False),
                        f'{method}_raw_output': out.get('raw_output', ''), f'{method}_output_limit': int(limited(out)),
                        f'{method}_logical_tokens': tokens(out)})
        row['official_change'] = pair['plus_cards']['official_compatible'] - pair['plain']['official_compatible']
        details.append(row)
    csv_file(destination / 'per_question.csv', details)
    return summary

def verify():
    protocol = read(PLAN / 'protocol.json')
    for name, expected in protocol['hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    frozen = {r['question_id']: r for r in read(PLAN / 'inputs.json')}
    for row in inputs():
        q = row['question_id']; saved = frozen[q]
        assert prompt(row, read(ROOT / saved['source'])) == saved['prompt'], q
        out = read(ORIGINAL / f'{q}.json')
        assert parsed(out['raw_output']) == {k: out[k] for k in ('status', 'accepted_answers')}, q
        raw = read(ROOT / 'runs/plain_plus_cards_v1/request_cache' / (out['requests'][0]['key'] + '.json'))
        assert raw['request']['messages'] == [{'role': 'user', 'content': saved['prompt']}]
        assert (raw['request']['max_tokens'], raw['request']['temperature'], raw['request']['repetition_penalty']) == (128, 0, 1.05)
    summary, paired, _, _ = evaluate(ORIGINAL)
    assert summary == read(ROOT / 'analysis/plain_plus_cards_v1/summary.json')
    assert paired == read(ROOT / 'analysis/plain_plus_cards_v1/paired.json')
    return {'passed': True, 'questions': 500, 'identical_prompts': 500, 'identical_parses': 500,
            'all_metrics_and_bootstrap_identical': True, 'frozen_source_hashes_checked': len(protocol['hashes'])}

def generate(destination):
    """Optional new inference; requires the existing local server on port 8576."""
    verify()
    client = Client(); client.cache = destination.parent / 'request_cache'
    client.cache.mkdir(parents=True, exist_ok=True)
    def one(row):
        start = time.time()
        out = dict(question_id=row['question_id'], method='plain_plus_cards_v1', card_count=len(row['cards']),
                   source_status=row['source_status'], accepted_answers=[])
        try:
            response = client.chat(row['prompt'], 128, False, 1.05)
            out.update(parsed(response['text']), raw_output=response['text'], finish_reason=response['finish_reason'],
                       requests=[{k: response[k] for k in ('key', 'usage', 'latency_seconds', 'finish_reason', 'cache_hit')}])
        except Exception as exc:
            out.update(status='error', error=str(exc), error_kind='context_overflow' if str(exc).startswith('context_overflow') else 'infrastructure', traceback=traceback.format_exc())
        out['wall_seconds'] = time.time() - start
        write_json(destination / (row['question_id'] + '.json'), out)
    jobs = [r for r in read(PLAN / 'inputs.json') if not (destination / (r['question_id'] + '.json')).exists()]
    with ThreadPoolExecutor(max_workers=24) as pool:
        for i, future in enumerate(as_completed([pool.submit(one, r) for r in jobs]), 1):
            future.result()
            if i % 25 == 0: print(f'{i}/{len(jobs)}', flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['export', 'verify', 'run'], nargs='?', default='export')
    parser.add_argument('--out', type=Path, help='New run directory (required only for run).')
    args = parser.parse_args()
    if args.command == 'verify':
        proof = verify(); write_json(HERE / 'results/verification.json', proof); print(json.dumps(proof, indent=2))
    elif args.command == 'run':
        if args.out is None: parser.error('run requires --out pointing to a new directory')
        if args.out.resolve() == ORIGINAL.parent.resolve(): parser.error('Use a new directory; preserve the original experiment.')
        generate(args.out / 'outputs'); export(args.out / 'outputs', args.out / 'results')
    else:
        export(ORIGINAL, HERE / 'results'); print(HERE / 'results')
