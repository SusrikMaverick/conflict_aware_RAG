RAMDocs 500-question comparison: start here
=========================================

Scope
  Plain RAG versus original documents + extracted evidence cards.
  The single-source diagnostic is excluded from this entrypoint.
  This is a local project view, not a standalone distribution.

Files to read
  experiment.py              Main entrypoint (173 lines).
  results/summary.csv         2 methods, 1 row per method (257 bytes).
  results/per_question.csv    500 questions, paired results (about 645 KiB).
  results/verification.json   Functional-equivalence verification.

Method
  Plain: question + all documents supplied for that question.
  Plus cards: identical Plain prompt + all saved C1 extracted cards.
  Cards include answer, claim, entity/scope, quote, and document reference.
  The generator does not apply verification filtering, voting, or forced abstention.
  1,908 saved cards; 20 empty-card questions retained in the 500-question total.
  Qwen2.5-7B-Instruct BF16; greedy; seed 576; output cap 128; penalty 1.05.

Results
                         Plain        Plus cards
  Official-compatible    76/500       124/500
  Strict answer set      65/500        88/500
  Wrong answer accepted  91/500       134/500
  Accuracy columns in CSV are fractions: 0.248 means 24.8%.
  Wrong-answer acceptance is a separate diagnostic, not a hallucination rate.
  These are exploratory results on previously observed RAMDocs data.

CSV guide
  summary.csv: counts, accuracy, parsing failures, output-limit hits, tokens.
  per_question.csv: question, document/card counts, gold/wrong answer lists,
    both methods' answers, raw responses, scores, status, and token counts.
  official_change: +1 = gain, -1 = loss, 0 = unchanged.
  Answer-list cells are JSON strings; standard CSV quoting preserves newlines.
  Both CSV files use UTF-8 with BOM for spreadsheet compatibility.

Commands (from /mnt/disk11/user/xiaoyih1/course_projects/nlp576)
  .venv/bin/python experiments/ramdocs_cards/experiment.py export
    Rebuild CSVs from saved results. No model calls; no GPU needed.
  .venv/bin/python experiments/ramdocs_cards/experiment.py verify
    Verify all 500 prompts/parses, frozen sources, metrics and bootstrap.
  .venv/bin/python experiments/ramdocs_cards/experiment.py run --out runs/NEW_NAME
    Optional inference into a new directory; requires the existing model server
    on 127.0.0.1:8576. Does not start/install the server or modify conda.

Shared code (reused without changes)
  work/real_runtime.py        Model client, tokenizer checks, cache, parser.
  work/metrics.py             Official-compatible and strict scoring.
  work/phase3c/method.py      Original source-card extraction implementation;
                              see SourceCards, segments, source_span, EXTRACT.
  work/phase3f_v2.py          Applies that extractor to each document.
  conflict_aware_RAG/src/eval.py  Teammate snapshot containing the Plain prompt.
  The simplified runner reuses saved extraction; it does not re-extract cards.

Preserved provenance
  planning/plain_plus_cards_v1/{protocol.json,inputs.json,audit.json}
  runs/plain_plus_cards_v1/outputs/          500 original augmented outputs.
  runs/plain_plus_cards_v1/request_cache/    500 raw requests/responses.
  runs/ramdocs-combined-v3/plain/             500 original Plain outputs.
  work/plain_plus_cards_v1.py               Frozen original runner.
  work/plain_plus_cards_finalize_v1.py      Original audit/report generator.
  Frozen code and results have not been moved or rewritten.
  Prompt construction, parsing, scoring and bootstrap reproduce the original
  exactly. File organization, CLI and CSV export are new conveniences.
  No fresh GPU inference was used to verify this refactor.

English report
  deliverables/Conflict_Aware_RAG_Simple_Report.pdf
